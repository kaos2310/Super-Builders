# ZeroMount Guard6.13 · ReSukiSU 35187 / SUSFS 2.3.0 / BRENE 68–69

Version `2.0.216-dev.guard6.13.brene69.susfs230-r2`, ARM64, 29.09.2026.
Auf Basis des gelieferten Guard6.12-Moduls, nicht einer älteren Neuimplementierung.
Lokal kompiliert und geprüft. Kein Installations-, Boot- oder Funktionstest auf dem Telefon.

## Passender Kernel

- Ausgangsrun: https://github.com/kaos2310/Super-Builders/actions/runs/36514881342
- Neuer Run: https://github.com/kaos2310/Super-Builders/actions/runs/36606929441
- Builder-Commit: `42b581b837cbb3090fa3b6f648654aaa2c8a3fb9`
- Branch: `agent/resukisu-35187-brene69-zzi4`
- ReSukiSU 35187: `94dd3c93c2053a84fd752df6eb85db99b7d70ab8`
- SUSFS v2.3.0: `24743360ea08d98f6ad72b856851abed8de5854f`
- Ziel bleibt S928BXXU6ZZI4 / EUX; OPEN_REDIRECT wurde aktiviert.
- UID-Gated Hiding und Gunyah aus dem Referenzrun bleiben erhalten.

Auf ausdrücklichen Wunsch wurde das Live-Monitoring des neuen Runs beendet.
Ein terminaler CI-Erfolg oder fertiges Kernel-Artefakt wird hier nicht behauptet.
Die Modul-ABI wird zur Laufzeit geprüft; ein Versionsstring beweist nicht den
exakten Kernel-Commit. Die älteren README-Dateien dokumentieren frühere Builds
und deren damalige Gerätebeobachtungen, nicht den aktuellen Gerätestand.

## Neue Funktionen gegenüber dem gelieferten ZIP

In ZeroMount öffnet „SUSFS & BRENE“ die neue Regelverwaltung. Von dort bleibt
die vorhandene BRENE-68/69-Seite erreichbar. Der bestehende kompilierte
Guard6.10-Hauptteil der Oberfläche bleibt erhalten.

| Funktion | Umsetzung |
|---|---|
| Eigene Pfade verbergen | Persistente SUS_PATH-Regeln und offizielle SUS_PATH_LOOP-Variante |
| Eigene Maps-Einträge | Persistente SUS_MAP-Regeln für ausdrücklich angegebene Dateien |
| Statische Metadaten | Alle zwölf Stat-Felder bearbeitbar; leere Felder übernehmen Werte bei Anwendung |
| Referenzdatei klonen | Alle zwölf Metadatenfelder einer Referenz werden für den Zielpfad registriert |
| Enhanced KSTAT-Redirect | Zwei Pfade, vollständig ausgefüllte Referenzwerte; nur bei exakt gemeldetem Kernel-Feature |
| Vollständiger Klon nach einem Mount | CLI `kstat register` vor dem Mount und `kstat full-clone` danach; persistierter Snapshot desselben Boots |
| Vorschau | Prüft Schema, Features, ABI und vorhandene Pfade ohne Schreiben |
| Verlässliches Speichern | Revisionsprüfung gegen veraltete Editoren, exklusive Sperre, atomare Dateien, root-eigene Ablage |
| Boot-Anwendung | Nach dem Mounten, dann erneut bei Boot-Abschluss für noch nicht bereitstehende Pfade |
| Status je Regel | Ausstehend, vom Kernel bestätigt, fehlgeschlagen, bereits angewandt oder Neustart erforderlich |
| Konfliktprüfung | IDs, normalisierte und aufgelöste Pfade; KSTAT-Redirect reserviert beide beteiligten Pfade |
| Unterbrochene Vorgänge | Absicht wird vor dem Kernel-Aufruf dauerhaft gespeichert; unklare Vorgänge werden nicht blind wiederholt |

KSTAT-Redirect ändert Metadaten, nicht Dateiinhalte. Die vorhandene separate
OPEN_REDIRECT-Verwaltung bleibt für Inhaltsumleitungen zuständig. Referenzwerte
werden bei der Registrierung gelesen; Änderungen der Referenzdatei werden
nicht fortlaufend gespiegelt. Die Konfliktprüfung umfasst diese neue Verwaltung,
nicht beliebige Regeln anderer Root-Module.

Die neuen Regeln sind standardmäßig leer. Speichern alleine sendet keine
SUSFS-Schreibbefehle an den Kernel. Deaktivieren/Entfernen verhindert die nächste
Boot-Anwendung; bereits aktive Kernel-Regeln bleiben bis zum Neustart bestehen.
Es wird kein automatischer Neustart ausgelöst. Die maximal 64 Regeln und alle
Pfade werden geprüft; zu große Ganzzahlen werden im Browser abgewiesen, damit
die JavaScript-Zahlendarstellung keine Stat-Werte unbemerkt rundet. Die CLI
unterstützt die vollständigen Rust-/LP64-Ganzzahlbereiche.

## Vollständiges KSTAT-Klonen auf diesem Kernel

Der gepinnte SUSFS-Kernel übernimmt beim UPDATE nicht die vom offiziellen
Userspace mitgelieferten Flags und aktualisiert `spoofed_size`. Ein bloßes
Senden von `KSTAT_AUTO_SPOOF_FULL_CLONE` würde daher nicht den vollständigen
Klon bewirken. ZeroMount verwendet für diesen Befehl einen vor dem Mount
gespeicherten Snapshot und registriert ihn anschließend statisch mit allen
zwölf Flags, einschließlich Dateigröße und Linkanzahl. Ohne bestätigten
Snapshot aus demselben Boot wird der Befehl abgewiesen.

Beispiel für einen manuell verwalteten Mount-Ablauf, nicht ausgeführt:

```sh
zm kstat register /absoluter/zielpfad
# Hier den eigenen Mount durchführen.
zm kstat full-clone /absoluter/zielpfad
```

`zm kstat update /absoluter/zielpfad` bleibt als normales SUSFS-Update verfügbar.
Die Regelverwaltung verwendet diesen zweistufigen Mount-Ablauf nicht automatisch.

## Bereits enthaltene portable BRENE-/SUSFS-Funktionen

| Bereich | Status |
|---|---|
| BRENE 67 Fingerprint, UTC, Build-Datum | Getrennte Schalter und bestehender nativer Property-Writer erhalten |
| BRENE 68 System-/Vendor-Patchdatum | Separate Opt-in-Schalter; aktuelle Monatswerte |
| BRENE 69 Monatsfehler / 1970 | Plausibilitätsprüfung, frischer gemeinsamer Monatswert |
| BRENE 69 zusätzliche Lock-Properties | Vorhandene Properties, getrennte Aktivierung und Readback |
| Mount-/Modul-/Kernel-Diagnose | Beibehalten, genaue Featureanzahl und Fehler statt falscher Nullwerte |
| Erweiterte SD-Karten-Pfade | Vorhandene Whitelist und Opt-in-Einstellung erhalten |
| Uname, AVC, Logging, Mount-Hiding | Bestehende native Befehle/Schalter erhalten |
| Cmdline/Bootconfig | Bestehender einzelner Writer und exakte Peer-Adapter erhalten |
| OPEN_REDIRECT | Bestehende persistente Verwaltung erhalten; passender Kernel-Build aktiviert Feature |
| Unicode-/Hidden-Name- und UID-Gates | Kernel-Verhalten; keine erfundenen globalen Laufzeit-Schalter |
| Droidspaces, Emoji, LKMs, resetprop | Unverändert übernommen |

BRENE-68-entfernte Standalone-Skripte, automatische Deaktivierung anderer Module
und ein zweiter konkurrierender Property-Writer werden nicht importiert.
Patchdatum-/Lock-Property-Anpassungen ändern nur gemeldete Werte; sie installieren
keine Sicherheitsupdates und ändern keinen Hardware-Attestierungszustand.

## CLI und Datenspeicher

```sh
zm susfs-rules status
zm susfs-rules preview '{"schema":1,"revision":0,"rules":[]}'
zm susfs-rules save '{"schema":1,"revision":0,"rules":[]}' --expected-revision 0
zm susfs-rules apply
zm susfs-compat
zm brene-status
zm integrity
```

`save` verlangt die aktuelle Revision aus `status`; die Beispiele gelten nur für
einen leeren Erststand. Regeln, Boot-Belege und KSTAT-Snapshots liegen unter
`/data/adb/zeromount/susfs-rules/`. Boot-Protokolle:
`.susfs-rules-post-mount.log` und `.susfs-rules-late.log` im ZeroMount-Datenordner.

## Verifikation und Rebuild

115 Host-Tests, 18 neue WebUI-Logiktests plus 12 erhaltene BRENE-Tests;
Android-Testkompilierung und ARM64-Release mit `--locked --offline`.
Offizielle ARM64-C-ABI-Prüfung: 33 Größen-/Offset-Prüfungen und vier verworfene
Negativkontrollen. Exakte Resultate, Datei-Hashes und Paketprüfung stehen in
`validation.json`. Die Browser-Bridge wurde simuliert, kein echter Android-WebView
und kein Telefon verwendet.

```sh
python rebuild.py --ndk /pfad/android-ndk --output neuer-ausgabeordner
node test-susfs-rules.mjs
node test-brene69.mjs
cd source/host-tests
cargo test --locked --offline
```

Gesperrte und vendorte Abhängigkeiten bleiben erhalten. Nur die Version des
eigenen Cargo-Pakets wurde im Lockfile angepasst. `guard6.13-changes.patch`
dokumentiert die Änderungen gegenüber dem gelieferten Guard6.12-Quellpaket.

## UIDGate1 boot-values Normalisierung (r3)

Bei `CONFIG_KSU_SUSFS_UID_GATED_HIDING` ist Root-UID 0 absichtlich vom
Visibility-Spoofing ausgenommen. Der native Guard6.13-Core kann deshalb nach
einem erfolgreichen SUSFS-Bootconfig-Write beim Root-Readback
`SUSFS proc readback differs` melden, obwohl die für Apps sichtbaren Boot-
Properties bereits korrekt sind.

Der r3-Front-Wrapper normalisiert ausschließlich diesen exakt erkannten Fall.
Er verlangt gleichzeitig UID_GATED_HIDING, SPOOF_CMDLINE_OR_BOOTCONFIG, den
nativen Fehlerstatus und die fünf erwarteten Boot-Property-Readbacks
(green/locked/1/enforcing/0). Andere Fehler bleiben unverändert fehlschlagend.
Der native ARM64-Core bleibt byteidentisch zu r2.


## r3.1.uidgate2 boot-path fix
`boot-completed.sh` routes only `boot-values` through the UIDGate-aware `bin/zm` front wrapper. Other boot tasks continue to use the native ABI binary. This prevents the expected root `/proc/bootconfig` readback under UID-gated hiding from being persisted as a false boot failure. The native Guard6.13 core remains byte-identical.
