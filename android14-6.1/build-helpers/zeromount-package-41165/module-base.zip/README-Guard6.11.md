# ZeroMount Guard6.11 / SUSFS v2.3.0

ARM64-Testkandidat, Stand 28.09.2026. Nicht auf einem Telefon installiert oder getestet.

## Basis und Ergebnis

Basis: das vom Benutzer gelieferte Guard6.10/BRENE67/stable-ui-graph1-ZIP
(SHA256 `487ae903a3d3ec399ead2b440a37d5074a1d8de8829f22d066e751e5edd47cf5`).
Der native Kern wurde aus dem vorhandenen Guard5/BRENE67-Quellarchiv weiterentwickelt,
auf dessen Kern Guard6.10 laut Manifest und identischem Binärhash aufbaut.
Die Guard6.10-WebUI-Assets, der Droidspaces-Manager, die persistenten OPEN_REDIRECT-Regeln
und die geprüften Peer-Adapter bleiben erhalten. Der alte 3-KB-Dispatcher wird durch
denselben neu gebauten Kern wie die anderen nativen Einstiegspunkte ersetzt.

Offizielles SUSFS für Android 14 / Linux 6.1:
https://gitlab.com/simonpunk/susfs4ksu/-/tree/24743360ea08d98f6ad72b856851abed8de5854f
Der Versionsstring lautet weiterhin **v2.3.0**. Der neuere Commit ersetzt nicht den
Kernel auf dem Telefon: Dieses ZIP enthält keine Kernel-/Firmware-Aktualisierung.

## Behobene Fehler

| Bereich | Bisher | Guard6.11 |
|---|---|---|
| SUS_PATH | altes 272-Byte-Layout mit inode/UID | offizielles 260-Byte-Layout, Fehleroffset 256 |
| KSTAT | Zeitfelder in alter Reihenfolge, keine Flags, Fehleroffset 368 | Zeitpaare korrekt, Flags bei 368, Fehler bei 372 |
| KSTAT-Masken | nicht gesetzt | offizielles AUTO-Muster bei add/update, alle Felder bei statischer Momentaufnahme |
| Feature-Erkennung | Teilstring genügte, selbst `_REDIRECT`/`=n` konnte passen | exakte aktivierte Tokens |
| Custom-KSTAT-Probe | unsupported konnte als Support gelten | 126/EOPNOTSUPP/ENOSYS/Sentinel abgewiesen |
| Pfade und C-Strings | stille Abschneidung möglich | Überlänge und eingebettetes NUL werden abgewiesen |
| OPEN_REDIRECT | separater ungeprüfter Schreibpfad | neuer Kern mit Versions-/Featureprüfung, UID 0..4 und Pfadlängenprüfung |
| JSON-Wrapper | `{}` konnte mit führendem Komma ergänzt werden | leere Objekte korrekt ergänzt |

## Neue Funktionen

Nach späterer, ausdrücklich gewünschter Installation über den Root-Manager:

```sh
su -c '/data/adb/modules/meta-zeromount/bin/zm susfs-compat'
su -c '/data/adb/modules/meta-zeromount/bin/zm susfs-compat --check'
su -c '/data/adb/modules/meta-zeromount/bin/zm integrity'
```

`susfs-compat` fragt ausschließlich Version und Features ab, erzeugt einen JSON-Bericht
und startet weder Logger noch Konfigurationsinitialisierung. `--check` liefert bei
fehlendem/unbekanntem ABI einen Fehlercode. `doctor` erhält zusätzlich das Feld
`susfs_compatibility`; die bisherige WebUI-JSON-Struktur wird nicht ersetzt.
Die älteren zusätzlichen Manager-Abfragen des `doctor`-Wrappers sind unverändert;
für die strikt lesende SUSFS-Abfrage gezielt `susfs-compat` verwenden.

`integrity` prüft unveränderliche Binärdateien, Skripte und WebUI-Assets. Laufzeitdateien
wie Konfiguration, Cache und veränderliche module.prop-Beschreibung sind ausgenommen.
Prüfsummen erkennen Beschädigungen, sind aber keine kryptografische Herausgebersignatur.
Der Installer prüft Paketintegrität und ABI vor Änderungen an persistenten Einstellungen
oder Peer-Skripten. Bei anderen SUSFS-Versionen wird die Installation abgebrochen.

## Wartung statt unkontrolliertem Auto-Update

Auf dem PC, mit Python und Git, aus dem Quellpaket:

```sh
python maintain.py --check-upstream
```

Exit 0: offizieller Branch noch beim geprüften Commit. Exit 2: neuer Commit, erneute
Prüfung erforderlich. Andere Fehler, etwa Netzwerkfehler, bedeuten nicht „aktuell“.
Es gibt keine Downloads/Installationen auf dem Gerät, keinen Hintergrunddienst und
keinen vorgetäuschten automatischen Update-Feed für diesen privaten Sonderbuild.
Der Check wird manuell gestartet, nicht automatisch zeitgesteuert.

Bei einem Update: neuen Quellstand prüfen, `maintain.py --susfs-source PFAD --clang
NDK_CLANG --negative-controls` ausführen, Rust-ABI-Tests und ARM64-Testkompilierung
ausführen, Versions-/Commit-Pins bewusst aktualisieren und Paket neu bauen.

## Rebuild und Prüfgrenzen

Das Quellpaket enthält den geänderten Rust-Kern, seine festen Abhängigkeiten und Locks,
Host-Tests, das exakte Modul-Template samt bestehenden WebUI-Assets, die Referenzheader
und Wartungs-/Rebuild-Skripte. Abhängigkeiten wurden nicht aktualisiert; im Root-Lock
wurde nur die eigene Paketversion angehoben. Die alten Guard5-WebUI-Quellen sind nicht
als Quelle der späteren Guard6.10-Assets ausgegeben und nicht Teil dieses Rebuilds.

```sh
python rebuild.py --ndk /pfad/android-ndk --output neuer-leerer-ausgabeordner
cd source/host-tests
cargo test --locked --offline
```

Voraussetzungen: Rust mit `aarch64-linux-android`-Standardbibliothek und Android NDK.
Geprüft: Rust 1.98.0, NDK 29.0.14206865 / Clang 21, Android API 26, Windows GNU Host.
Das lokale Build-Skript mit den vorgefundenen Windows-Toolchain-Pfaden liegt separat bei.
Ein anderer Compiler/Host kann andere Binärhashes erzeugen. Der portable Rebuild-Runner
ist nicht separat auf einem zweiten Host ausgeführt worden.

85 Host-Tests erfolgreich; ARM64-Release gebaut; Android-Testquellen kompiliert (nicht
auf ARM64 ausgeführt); 33 C-ABI-Assertions gegen den unveränderten offiziellen Header
erfolgreich; vier absichtlich fehlerhafte ABI-Varianten abgewiesen.
Kein Laufzeit-, Boot-, Mount- oder WebView-Erfolg auf einem echten Gerät behauptet.

Die Versionserkennung schützt vor **anderen** Versionsstrings. Ein Kernel-Fork oder
späterer Commit kann unter demselben String trotzdem das ABI ändern. Der JSON-Bericht
weist deshalb `kernel_commit_verified: false` aus. Ein Modulpaket kann die neuen
SUSFS-Kernelfixes (z.B. CTIME-Maske) nicht nachträglich in einen alten Kernel einbauen.
Die optionale private KSTAT_REDIRECT-Erweiterung bleibt getrennt vom offiziellen ABI.
Unbekannte Peer-Skript-Versionen werden weiterhin nicht automatisch umgeschrieben.
Geerbte LKM-/Emoji-/resetprop-Dateien wurden nicht neu gebaut. Lizenzen bleiben erhalten.
