#!/system/bin/sh
MODDIR="${0%/*}"

. "$MODDIR/common.sh"

# Synchronize the native BRENE stage with both user-controlled master switches.
"$MODDIR/bin/zm-susfs-owner" prepare || { echo "ZeroMount SuSFS profile validation failed" >&2; exit 1; }
[ -z "$ABI" ] && exit 0
[ -x "$BIN" ] || exit 0

if command -v getevent >/dev/null 2>&1; then
    _keys=$(timeout 3 getevent -lq 2>/dev/null || true)
    if echo "$_keys" | grep -q 'KEY_VOLUMEDOWN.*DOWN' && \
       echo "$_keys" | grep -q 'KEY_VOLUMEUP.*DOWN'; then
        echo "zeromount: vol-up+down safe mode triggered, running guard recovery" > /dev/kmsg 2>/dev/null
        "$BIN" guard recover 2>/dev/null
    fi
fi

# Repair known peer updates before late boot writers run. Unknown versions remain untouched.
if ! "$BIN" writer-adapters --apply > /data/adb/zeromount/.writer-adapters.log 2>&1; then
    echo "zeromount: boot-value adapters need review; see Runtime Doctor" > /dev/kmsg 2>/dev/null
fi

"$BIN" detect

# Guard6.3: replay persistent OPEN_REDIRECT rules before zygote/app startup.
# Rules whose paths are not available yet remain pending for boot-completed.
if [ -x "$MODDIR/bin/zm-open-redirect" ]; then
    "$MODDIR/bin/zm-susfs-owner" run susfs open-redirect-early "$MODDIR/bin/zm-open-redirect" apply early > /data/adb/zeromount/.open-redirect-early.log 2>&1 || \
        echo "zeromount: early OPEN_REDIRECT replay had failures; see .open-redirect-early.log" > /dev/kmsg 2>/dev/null
fi

mkdir -p /data/adb/zeromount/flags

# Magisk has no metamount.sh â€” run mount pipeline here
if [ -z "$KSU" ] && [ -z "$APATCH" ]; then
    if [ ! -f "/dev/zeromount_metamount_lock" ]; then
        touch "/dev/zeromount_metamount_lock"
        EXTERNAL=$(cat /data/adb/zeromount/flags/external_susfs 2>/dev/null || echo none)
        [ "$EXTERNAL" != "none" ] && "$BIN" bridge reconcile "$EXTERNAL" 2>/dev/null
        timeout 60 "$MODDIR/bin/zm-bootguard" mount
        _mount_rc=$?

# Guard6.13: explicit user rules; empty by default, acknowledged rules deduplicated per boot.
if ! "$MODDIR/bin/zm-susfs-owner" run susfs guard-rules "$BIN" susfs-rules apply > /data/adb/zeromount/.susfs-rules-post-mount.log 2>&1; then
    echo "zeromount: SUSFS user rules pending/failed; inspect SUSFS Rules" > /dev/kmsg 2>/dev/null
fi

        echo "zeromount: magisk mount pipeline exited (rc=$_mount_rc)" > /dev/kmsg 2>/dev/null
        if [ -x "$MODDIR/bin/zm-droidspaces-vfs" ]; then
            "$MODDIR/bin/zm-droidspaces-vfs" apply early > /data/adb/zeromount/.droidspaces-vfs-early.log 2>&1 || \
                echo "zeromount: early Droidspaces VFS bridge pending/failed; see .droidspaces-vfs-early.log" > /dev/kmsg 2>/dev/null
        fi
    fi
fi

# Axon PID-1 injection is intentionally unavailable in this enforcing build.
# ReSukiSU native ADB root is controlled exclusively by its manager.
