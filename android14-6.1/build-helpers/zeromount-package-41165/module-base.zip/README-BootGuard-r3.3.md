# ZeroMount Guard6.13 r3.3 BootGuard2

The supplied r3.2 ZIP was installed on the S24 Ultra: the bugreport's module
list reports r3.2 and the kernel log records a successful mount with 49 rules
and 2 modules. On the following boot, native Guard6.13 logged “bootloop detected
(1 consecutive failures)” and wrote the module disable marker. KernelSU then
skipped its post-mount and boot-completed hooks. This is a boot failure check,
not an archive installation error.

This adapter records a successful native mount and allows **one** additional
boot if the native counter is still pending. An incomplete second boot reaches
the original native lockout. Duplicate mounts in one boot are still deduplicated.
A completed Android boot clears the counter and markers. Reinstallation clears
stale markers and the module disable flag. The native core is byte-for-byte
unchanged (SHA256 `1a0b25246a54746ebe89fb210ffbc8217f6227d9f5a04e964630e50228bea036`).

BakaSU 35205 reports `BAKASU=true` to module scripts; the installer accepts
that marker for the SUSFS status label. Android/device boot success still needs
validation after installing the ZIP. Keep a recovery path available and inspect
`/data/adb/zeromount/activity.log` if the second retry is locked out.
