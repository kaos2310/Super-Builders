# ZeroMount Guard6.12 – BRENE 0.0.68 + 0.0.69 / SUSFS 2.3.0

ARM64-Testkandidat, 28.09.2026. Nicht installiert, nicht auf dem Telefon ausgeführt.
Die SUSFS-ABI-Reparaturen aus Guard6.11 bleiben erhalten; README-Guard6.11.md
dokumentiert die vorherige Ausbaustufe, nicht die aktuelle Testanzahl/Version.

## Übernommene Änderungen

| BRENE | Integration in ZeroMount |
|---|---|
| 68: System-/Vendor-Sicherheitspatchdatum | Zwei getrennte native Schalter; aktueller Monat, Tag 01 bzw. 05; CLI, Konfiguration, BRENE-Bridge und WebUI |
| 69: Monatsverwaltung | Ein frischer Zeit-Snapshot je Anwendung für beide Werte; keine veralteten CURRENT_YEAR/MONTH-Variablen aus einem vorherigen Boot; unplausible Werte werden ausgelassen |
| 69: ro.secureboot.devicelock / ro.oem_unlock_supported | Separater opt-in Schalter; nur vorhandene Properties ändern; Readback wird geprüft |
| 68: Kernelversion und konkurrierende Module | `zm brene-status` und zusätzliche WebUI-Seite; enabled/disabled/pending_removal/not_installed/unknown getrennt |
| 68/69: Auffällige Mounts / leere Ausgabe | BRENE-Mountinfo-Heuristik, leere erfolgreiche Abfrage zeigt 0; Lesefehler bleibt Fehler, kein automatisches Unmount |
| 69: Featureanzahl und UI-Aufräumen | Tatsächlich gemeldete, eindeutige aktivierte Features zählen; keine falsche feste Grenze 9; getrennte Status-/Konfigurationsbereiche |

Neue Optionen sind standardmäßig **false**. Bestehende Benutzerkonfiguration wird
nicht neu vorbelegt. Die Eigenschaften stellen nur gemeldete Werte um: Sie installieren
keine Sicherheitskorrekturen und ändern weder Bootloader-Sperre noch Hardware-Attestierung.
Die Uhr wird nicht gestellt. Monatsprüfung 2020..2099 / 01..12 ist nur eine
Plausibilitätsprüfung, keine Bestätigung korrekter oder authentifizierter Zeit.

```sh
zm brene-status
zm config set brene.spoof_os_security_patch_level_property true
zm config set brene.spoof_vendor_security_patch_level_property true
zm config set brene.extended_lock_properties true
```

Diese Schreibbefehle sind Beispiele, nicht ausgeführt. Aktivierung über die neue Seite
verlangt Bestätigung, speichert nur den jeweiligen Schlüssel und liest ihn zurück.
Anwendung beim nächsten Boot über den vorhandenen Property-Writer. Ausschalten
verhindert weitere Änderungen; es restauriert keine Properties im aktuellen Boot.
Der Minuten-Worker bleibt auf die bisherigen allgemeinen Properties begrenzt.
Ein erkannter externer SUSFS-Owner hat weiterhin Vorrang.

## Bewusste Anpassungen gegenüber dem Standalone-BRENE-ZIP

- Keine fremden Bootskripte oder SUSFS-Binärdateien werden parallel installiert.
  Die ZeroMount-Service-/Mount-/Property-Owner bleiben zuständig.
- BRENE 68 entfernt seine automatische Mount-/Injection-Behandlung und tote
  Shell-Stubs. Diese Skripte werden nicht importiert. Bereits vorhandene eigenständige
  ZeroMount-Funktionen und vom Benutzer gesetzte Werte werden nicht gelöscht.
- BRENE 69 aktiviert breiteres SD-Karten-Hiding standardmäßig. ZeroMount erhält
  seine bisherigen Samsung-schonenden opt-in Defaults und Whitelist.
- Standalone-Installer-Selbstkopien, automatische Deaktivierung anderer Module
  und eine zweite Oberfläche als Ersatz für ZeroMount werden nicht übernommen.
- Die 52 vorhandenen Webroot-Dateien außer index.html bleiben bytegleich.
  index.html erhält genau einen Link; die kompilierte Anwendung bleibt unangetastet.
  BRENE-68/69-Seite und ihr lesbares JavaScript liegen zusätzlich bei.
- `CURRENT_YEAR`/`CURRENT_MONTH` und unbekannte BRENE-Config-Einträge bleiben beim
  Bridge-Export erhalten, steuern jedoch nicht die neue native Datumsberechnung.

## CONFIG_KSU_SUSFS_UID_GATED_HIDING

Am 28.09.2026 fehlen das Symbol und sein =y-Eintrag sowohl in `/proc/config.gz`
des SM-S928B als auch in BUILD-CONFIG.txt aus Run 36463712058. Das passende Image
enthält die live gelesene GNU-Build-ID e29f611f2dbf0ab62d008fb9ae812ee33c17eea2;
das Paketmanifest pinnt SUSFS auf 24743360ea08d98f6ad72b856851abed8de5854f.
Das ist ein Build-ID-/Manifest-Abgleich, kein vollständiger Hashvergleich der
geflashten Partition und kein Laufzeitbeweis aller Kernel-Funktionen.
Zusätzlich entspricht `/proc/config.gz` bytegenau der im Image eingebetteten
IKCONFIG (SHA256 72db859dd3ff16e6ec224177b7c5326752b1237690feddcdc5b20009c5b18bef).
Die separate BUILD-CONFIG.txt weicht in einer Zeile ab: IP6_NF_NAT=y, während
Image und laufender Kernel IP6_NF_NAT=n enthalten. Diese Sidecar-Abweichung ist
dokumentiert; das UID_GATED_HIDING-Symbol fehlt in allen drei Ansichten.

Im überprüften Super-Builders-Quellstand 8c379ba853e084a42d70633e1a9b29b00793bd7e
kommt das exakte Symbol nur im Konfigurationsreport vor, nicht als Kconfig-/Hook-
Implementierung. Auch der gepinnte offizielle SUSFS-Quellstand definiert es nicht.
Bestehende Funktionen wie `susfs_is_current_app_uid()` und
`susfs_is_current_proc_umounted_app()` sind UID-bezogen, aber keine Bestätigung
dieser zusätzlichen Kconfig-Option.

Die neue Diagnose unterscheidet enabled, disabled, not_listed und unavailable.
Es wird kein Laufzeit-Schalter erfunden und keine Kerneländerung behauptet.
Eine zusätzliche Implementierung erfordert den zugehörigen Patch/Fork samt
Definition der betroffenen Hooks, danach einen separaten Kernel-Build mit Tests.

Quellen: vom Benutzer gelieferte BRENE-67/68/69-Archive (vollständiger Hash-/Diff-
Nachweis in brene-input-audit.json und brene-upstream-changes.diff im Quellpaket),
[passender Kernel-Build](https://github.com/kaos2310/Super-Builders/actions/runs/36463712058),
[geprüftes SUSFS](https://gitlab.com/simonpunk/susfs4ksu/-/tree/24743360ea08d98f6ad72b856851abed8de5854f).
BRENE-Autoren laut Eingabepaket: rrr333nnn333, simonpunk, KOWX712.

## Verifikation und Rebuild

Aktuelle Zahlen und SHA256 stehen in validation.json / SHA256SUMS.txt.
Rust-Hosttests einschließlich der neuen Planungs-, Bridge- und Diagnosefälle;
ARM64-Release und Android-Testkompilierung; WebUI-Tests mit simulierter KernelSU-
Bridge; offizielle C-ABI-Prüfung mit Negativkontrollen; ZIP-/Integritätsprüfung.
Kein echter Android-WebView-, Boot- oder Mount-Test dieses Pakets.
Ein zusätzlicher isolierter PC-Browsertest konnte nicht starten (spawn EPERM).
Die 12 JavaScript-/DOM-/Bridge-Logiktests bestanden; eine visuelle Darstellung
im echten Browser wird damit ausdrücklich nicht als geprüft ausgegeben.

```sh
python rebuild.py --ndk /pfad/android-ndk --output neuer-ausgabeordner
node test-brene69.mjs
cd source/host-tests
cargo test --locked --offline
```

Feste Cargo-Locks und vendorte Abhängigkeiten bleiben erhalten. Das Quellpaket enthält
die zusätzliche UI direkt, ohne den alten Guard6.10-JavaScript-Build nachzuahmen.
Guard6.11 bleibt als separates älteres Ausgabepaket auf dem PC erhalten.
Auf dem Gerät wurde für diese Arbeit nur gelesen: keine Installation, kein
Dateitransfer, keine Property-Änderung, kein Modulwechsel und kein Neustart.
