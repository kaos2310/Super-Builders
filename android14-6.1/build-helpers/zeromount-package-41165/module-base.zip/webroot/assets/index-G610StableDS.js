import { readLiveRequirementState } from './brene-requirements.mjs';
const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./ModulesTab-DL2hno7T.js","./Input-BCVrpK5n.js","./Input-p9zls47c.css","./Badge-2OSksFSs.js","./ModulesTab-DvrWEnaS.css","./ConfigTab-D00TD33F.js","./ConfigTab-BbhAfgN-.css","./SettingsTab-BXf6CWXi.js","./SettingsTab-CDkKbO71.css"])))=>i.map(i=>d[i]);
true              &&(function polyfill() {
	const relList = document.createElement("link").relList;
	if (relList && relList.supports && relList.supports("modulepreload")) return;
	for (const link of document.querySelectorAll("link[rel=\"modulepreload\"]")) processPreload(link);
	new MutationObserver((mutations) => {
		for (const mutation of mutations) {
			if (mutation.type !== "childList") continue;
			for (const node of mutation.addedNodes) if (node.tagName === "LINK" && node.rel === "modulepreload") processPreload(node);
		}
	}).observe(document, {
		childList: true,
		subtree: true
	});
	function getFetchOpts(link) {
		const fetchOpts = {};
		if (link.integrity) fetchOpts.integrity = link.integrity;
		if (link.referrerPolicy) fetchOpts.referrerPolicy = link.referrerPolicy;
		if (link.crossOrigin === "use-credentials") fetchOpts.credentials = "include";
		else if (link.crossOrigin === "anonymous") fetchOpts.credentials = "omit";
		else fetchOpts.credentials = "same-origin";
		return fetchOpts;
	}
	function processPreload(link) {
		if (link.ep) return;
		link.ep = true;
		const fetchOpts = getFetchOpts(link);
		fetch(link.href, fetchOpts);
	}
}());

const sharedConfig = {
  context: undefined,
  registry: undefined,
  effects: undefined,
  done: false,
  getContextId() {
    return getContextId(this.context.count);
  },
  getNextContextId() {
    return getContextId(this.context.count++);
  }
};
function getContextId(count) {
  const num = String(count),
    len = num.length - 1;
  return sharedConfig.context.id + (len ? String.fromCharCode(96 + len) : "") + num;
}
function setHydrateContext(context) {
  sharedConfig.context = context;
}

const IS_DEV = false;
const equalFn = (a, b) => a === b;
const $PROXY = Symbol("solid-proxy");
const SUPPORTS_PROXY = typeof Proxy === "function";
const $TRACK = Symbol("solid-track");
const signalOptions = {
  equals: equalFn
};
let runEffects = runQueue;
const STALE = 1;
const PENDING = 2;
const UNOWNED = {
  owned: null,
  cleanups: null,
  context: null,
  owner: null
};
const NO_INIT = {};
var Owner = null;
let Transition = null;
let ExternalSourceConfig = null;
let Listener = null;
let Updates = null;
let Effects = null;
let ExecCount = 0;
function createRoot(fn, detachedOwner) {
  const listener = Listener,
    owner = Owner,
    unowned = fn.length === 0,
    current = detachedOwner === undefined ? owner : detachedOwner,
    root = unowned ? UNOWNED : {
      owned: null,
      cleanups: null,
      context: current ? current.context : null,
      owner: current
    },
    updateFn = unowned ? fn : () => fn(() => untrack(() => cleanNode(root)));
  Owner = root;
  Listener = null;
  try {
    return runUpdates(updateFn, true);
  } finally {
    Listener = listener;
    Owner = owner;
  }
}
function createSignal(value, options) {
  options = options ? Object.assign({}, signalOptions, options) : signalOptions;
  const s = {
    value,
    observers: null,
    observerSlots: null,
    comparator: options.equals || undefined
  };
  const setter = value => {
    if (typeof value === "function") {
      value = value(s.value);
    }
    return writeSignal(s, value);
  };
  return [readSignal.bind(s), setter];
}
function createComputed(fn, value, options) {
  const c = createComputation(fn, value, true, STALE);
  updateComputation(c);
}
function createRenderEffect(fn, value, options) {
  const c = createComputation(fn, value, false, STALE);
  updateComputation(c);
}
function createEffect(fn, value, options) {
  runEffects = runUserEffects;
  const c = createComputation(fn, value, false, STALE),
    s = SuspenseContext && useContext(SuspenseContext);
  if (s) c.suspense = s;
  if (!options || !options.render) c.user = true;
  Effects ? Effects.push(c) : updateComputation(c);
}
function createMemo(fn, value, options) {
  options = options ? Object.assign({}, signalOptions, options) : signalOptions;
  const c = createComputation(fn, value, true, 0);
  c.observers = null;
  c.observerSlots = null;
  c.comparator = options.equals || undefined;
  updateComputation(c);
  return readSignal.bind(c);
}
function isPromise(v) {
  return v && typeof v === "object" && "then" in v;
}
function createResource(pSource, pFetcher, pOptions) {
  let source;
  let fetcher;
  let options;
  {
    source = true;
    fetcher = pSource;
    options = {};
  }
  let pr = null,
    initP = NO_INIT,
    id = null,
    scheduled = false,
    resolved = "initialValue" in options,
    dynamic = typeof source === "function" && createMemo(source);
  const contexts = new Set(),
    [value, setValue] = (options.storage || createSignal)(options.initialValue),
    [error, setError] = createSignal(undefined),
    [track, trigger] = createSignal(undefined, {
      equals: false
    }),
    [state, setState] = createSignal(resolved ? "ready" : "unresolved");
  if (Owner) onCleanup(() => {
    for (const c of contexts.keys()) c.decrement();
    contexts.clear();
    pr = null;
  });
  if (sharedConfig.context) {
    id = sharedConfig.getNextContextId();
    if (options.ssrLoadFrom === "initial") initP = options.initialValue;else if (sharedConfig.load && sharedConfig.has(id)) initP = sharedConfig.load(id);
  }
  function loadEnd(p, v, error, key) {
    if (pr === p) {
      pr = null;
      key !== undefined && (resolved = true);
      if ((p === initP || v === initP) && options.onHydrated) queueMicrotask(() => options.onHydrated(key, {
        value: v
      }));
      initP = NO_INIT;
      completeLoad(v, error);
    }
    return v;
  }
  function completeLoad(v, err) {
    runUpdates(() => {
      if (err === undefined) setValue(() => v);
      setState(err !== undefined ? "errored" : resolved ? "ready" : "unresolved");
      setError(err);
      for (const c of contexts.keys()) c.decrement();
      contexts.clear();
    }, false);
  }
  function read() {
    const c = SuspenseContext && useContext(SuspenseContext),
      v = value(),
      err = error();
    if (err !== undefined && !pr) throw err;
    if (Listener && !Listener.user && c) {
      createComputed(() => {
        track();
        if (pr) {
          if (c.resolved && Transition) ;else if (!contexts.has(c)) {
            c.increment();
            contexts.add(c);
          }
        }
      });
    }
    return v;
  }
  function load(refetching = true) {
    if (refetching !== false && scheduled) return;
    scheduled = false;
    const lookup = dynamic ? dynamic() : source;
    if (lookup == null || lookup === false) {
      loadEnd(pr, untrack(value));
      return;
    }
    let error;
    const p = initP !== NO_INIT ? initP : untrack(() => {
      try {
        return fetcher(lookup, {
          value: value(),
          refetching
        });
      } catch (fetcherError) {
        error = fetcherError;
      }
    });
    if (error !== undefined) {
      loadEnd(pr, undefined, castError(error), lookup);
      return;
    } else if (!isPromise(p)) {
      loadEnd(pr, p, undefined, lookup);
      return p;
    }
    pr = p;
    if ("v" in p) {
      if (p.s === 1) loadEnd(pr, p.v, undefined, lookup);else loadEnd(pr, undefined, castError(p.v), lookup);
      return p;
    }
    scheduled = true;
    queueMicrotask(() => scheduled = false);
    runUpdates(() => {
      setState(resolved ? "refreshing" : "pending");
      trigger();
    }, false);
    return p.then(v => loadEnd(p, v, undefined, lookup), e => loadEnd(p, undefined, castError(e), lookup));
  }
  Object.defineProperties(read, {
    state: {
      get: () => state()
    },
    error: {
      get: () => error()
    },
    loading: {
      get() {
        const s = state();
        return s === "pending" || s === "refreshing";
      }
    },
    latest: {
      get() {
        if (!resolved) return read();
        const err = error();
        if (err && !pr) throw err;
        return value();
      }
    }
  });
  let owner = Owner;
  if (dynamic) createComputed(() => (owner = Owner, load(false)));else load(false);
  return [read, {
    refetch: info => runWithOwner(owner, () => load(info)),
    mutate: setValue
  }];
}
function batch(fn) {
  return runUpdates(fn, false);
}
function untrack(fn) {
  if (Listener === null) return fn();
  const listener = Listener;
  Listener = null;
  try {
    if (ExternalSourceConfig) ;
    return fn();
  } finally {
    Listener = listener;
  }
}
function onMount(fn) {
  createEffect(() => untrack(fn));
}
function onCleanup(fn) {
  if (Owner === null) ;else if (Owner.cleanups === null) Owner.cleanups = [fn];else Owner.cleanups.push(fn);
  return fn;
}
function getListener() {
  return Listener;
}
function getOwner() {
  return Owner;
}
function runWithOwner(o, fn) {
  const prev = Owner;
  const prevListener = Listener;
  Owner = o;
  Listener = null;
  try {
    return runUpdates(fn, true);
  } catch (err) {
    handleError(err);
  } finally {
    Owner = prev;
    Listener = prevListener;
  }
}
const [transPending, setTransPending] = /*@__PURE__*/createSignal(false);
function resumeEffects(e) {
  Effects.push.apply(Effects, e);
  e.length = 0;
}
function createContext(defaultValue, options) {
  const id = Symbol("context");
  return {
    id,
    Provider: createProvider(id),
    defaultValue
  };
}
function useContext(context) {
  let value;
  return Owner && Owner.context && (value = Owner.context[context.id]) !== undefined ? value : context.defaultValue;
}
function children(fn) {
  const children = createMemo(fn);
  const memo = createMemo(() => resolveChildren(children()));
  memo.toArray = () => {
    const c = memo();
    return Array.isArray(c) ? c : c != null ? [c] : [];
  };
  return memo;
}
let SuspenseContext;
function getSuspenseContext() {
  return SuspenseContext || (SuspenseContext = createContext());
}
function readSignal() {
  if (this.sources && (this.state)) {
    if ((this.state) === STALE) updateComputation(this);else {
      const updates = Updates;
      Updates = null;
      runUpdates(() => lookUpstream(this), false);
      Updates = updates;
    }
  }
  if (Listener) {
    const observers = this.observers;
    if (!observers || observers[observers.length - 1] !== Listener) {
      const sSlot = observers ? observers.length : 0;
      if (!Listener.sources) {
        Listener.sources = [this];
        Listener.sourceSlots = [sSlot];
      } else {
        Listener.sources.push(this);
        Listener.sourceSlots.push(sSlot);
      }
      if (!observers) {
        this.observers = [Listener];
        this.observerSlots = [Listener.sources.length - 1];
      } else {
        observers.push(Listener);
        this.observerSlots.push(Listener.sources.length - 1);
      }
    }
  }
  return this.value;
}
function writeSignal(node, value, isComp) {
  let current = node.value;
  if (!node.comparator || !node.comparator(current, value)) {
    node.value = value;
    if (node.observers && node.observers.length) {
      runUpdates(() => {
        for (let i = 0; i < node.observers.length; i += 1) {
          const o = node.observers[i];
          const TransitionRunning = Transition && Transition.running;
          if (TransitionRunning && Transition.disposed.has(o)) ;
          if (TransitionRunning ? !o.tState : !o.state) {
            if (o.pure) Updates.push(o);else Effects.push(o);
            if (o.observers) markDownstream(o);
          }
          if (!TransitionRunning) o.state = STALE;
        }
        if (Updates.length > 10e5) {
          Updates = [];
          if (IS_DEV) ;
          throw new Error();
        }
      }, false);
    }
  }
  return value;
}
function updateComputation(node) {
  if (!node.fn) return;
  cleanNode(node);
  const time = ExecCount;
  runComputation(node, node.value, time);
}
function runComputation(node, value, time) {
  let nextValue;
  const owner = Owner,
    listener = Listener;
  Listener = Owner = node;
  try {
    nextValue = node.fn(value);
  } catch (err) {
    if (node.pure) {
      {
        node.state = STALE;
        node.owned && node.owned.forEach(cleanNode);
        node.owned = null;
      }
    }
    node.updatedAt = time + 1;
    return handleError(err);
  } finally {
    Listener = listener;
    Owner = owner;
  }
  if (!node.updatedAt || node.updatedAt <= time) {
    if (node.updatedAt != null && "observers" in node) {
      writeSignal(node, nextValue);
    } else node.value = nextValue;
    node.updatedAt = time;
  }
}
function createComputation(fn, init, pure, state = STALE, options) {
  const c = {
    fn,
    state: state,
    updatedAt: null,
    owned: null,
    sources: null,
    sourceSlots: null,
    cleanups: null,
    value: init,
    owner: Owner,
    context: Owner ? Owner.context : null,
    pure
  };
  if (Owner === null) ;else if (Owner !== UNOWNED) {
    {
      if (!Owner.owned) Owner.owned = [c];else Owner.owned.push(c);
    }
  }
  return c;
}
function runTop(node) {
  if ((node.state) === 0) return;
  if ((node.state) === PENDING) return lookUpstream(node);
  if (node.suspense && untrack(node.suspense.inFallback)) return node.suspense.effects.push(node);
  const ancestors = [node];
  while ((node = node.owner) && (!node.updatedAt || node.updatedAt < ExecCount)) {
    if (node.state) ancestors.push(node);
  }
  for (let i = ancestors.length - 1; i >= 0; i--) {
    node = ancestors[i];
    if ((node.state) === STALE) {
      updateComputation(node);
    } else if ((node.state) === PENDING) {
      const updates = Updates;
      Updates = null;
      runUpdates(() => lookUpstream(node, ancestors[0]), false);
      Updates = updates;
    }
  }
}
function runUpdates(fn, init) {
  if (Updates) return fn();
  let wait = false;
  if (!init) Updates = [];
  if (Effects) wait = true;else Effects = [];
  ExecCount++;
  try {
    const res = fn();
    completeUpdates(wait);
    return res;
  } catch (err) {
    if (!wait) Effects = null;
    Updates = null;
    handleError(err);
  }
}
function completeUpdates(wait) {
  if (Updates) {
    runQueue(Updates);
    Updates = null;
  }
  if (wait) return;
  const e = Effects;
  Effects = null;
  if (e.length) runUpdates(() => runEffects(e), false);
}
function runQueue(queue) {
  for (let i = 0; i < queue.length; i++) runTop(queue[i]);
}
function runUserEffects(queue) {
  let i,
    userLength = 0;
  for (i = 0; i < queue.length; i++) {
    const e = queue[i];
    if (!e.user) runTop(e);else queue[userLength++] = e;
  }
  if (sharedConfig.context) {
    if (sharedConfig.count) {
      sharedConfig.effects || (sharedConfig.effects = []);
      sharedConfig.effects.push(...queue.slice(0, userLength));
      return;
    }
    setHydrateContext();
  }
  if (sharedConfig.effects && (sharedConfig.done || !sharedConfig.count)) {
    queue = [...sharedConfig.effects, ...queue];
    userLength += sharedConfig.effects.length;
    delete sharedConfig.effects;
  }
  for (i = 0; i < userLength; i++) runTop(queue[i]);
}
function lookUpstream(node, ignore) {
  node.state = 0;
  for (let i = 0; i < node.sources.length; i += 1) {
    const source = node.sources[i];
    if (source.sources) {
      const state = source.state;
      if (state === STALE) {
        if (source !== ignore && (!source.updatedAt || source.updatedAt < ExecCount)) runTop(source);
      } else if (state === PENDING) lookUpstream(source, ignore);
    }
  }
}
function markDownstream(node) {
  for (let i = 0; i < node.observers.length; i += 1) {
    const o = node.observers[i];
    if (!o.state) {
      o.state = PENDING;
      if (o.pure) Updates.push(o);else Effects.push(o);
      o.observers && markDownstream(o);
    }
  }
}
function cleanNode(node) {
  let i;
  if (node.sources) {
    while (node.sources.length) {
      const source = node.sources.pop(),
        index = node.sourceSlots.pop(),
        obs = source.observers;
      if (obs && obs.length) {
        const n = obs.pop(),
          s = source.observerSlots.pop();
        if (index < obs.length) {
          n.sourceSlots[s] = index;
          obs[index] = n;
          source.observerSlots[index] = s;
        }
      }
    }
  }
  if (node.tOwned) {
    for (i = node.tOwned.length - 1; i >= 0; i--) cleanNode(node.tOwned[i]);
    delete node.tOwned;
  }
  if (node.owned) {
    for (i = node.owned.length - 1; i >= 0; i--) cleanNode(node.owned[i]);
    node.owned = null;
  }
  if (node.cleanups) {
    for (i = node.cleanups.length - 1; i >= 0; i--) node.cleanups[i]();
    node.cleanups = null;
  }
  node.state = 0;
}
function castError(err) {
  if (err instanceof Error) return err;
  return new Error(typeof err === "string" ? err : "Unknown error", {
    cause: err
  });
}
function handleError(err, owner = Owner) {
  const error = castError(err);
  throw error;
}
function resolveChildren(children) {
  if (typeof children === "function" && !children.length) return resolveChildren(children());
  if (Array.isArray(children)) {
    const results = [];
    for (let i = 0; i < children.length; i++) {
      const result = resolveChildren(children[i]);
      if (Array.isArray(result)) {
        if (result.length < 32768) results.push.apply(results, result);else for (let j = 0; j < result.length; j++) results.push(result[j]);
      } else {
        results.push(result);
      }
    }
    return results;
  }
  return children;
}
function createProvider(id, options) {
  return function provider(props) {
    let res;
    createRenderEffect(() => res = untrack(() => {
      Owner.context = {
        ...Owner.context,
        [id]: props.value
      };
      return children(() => props.children);
    }), undefined);
    return res;
  };
}

const FALLBACK = Symbol("fallback");
function dispose(d) {
  for (let i = 0; i < d.length; i++) d[i]();
}
function mapArray(list, mapFn, options = {}) {
  let items = [],
    mapped = [],
    disposers = [],
    len = 0,
    indexes = mapFn.length > 1 ? [] : null;
  onCleanup(() => dispose(disposers));
  return () => {
    let newItems = list() || [],
      newLen = newItems.length,
      i,
      j;
    newItems[$TRACK];
    return untrack(() => {
      let newIndices, newIndicesNext, temp, tempdisposers, tempIndexes, start, end, newEnd, item;
      if (newLen === 0) {
        if (len !== 0) {
          dispose(disposers);
          disposers = [];
          items = [];
          mapped = [];
          len = 0;
          indexes && (indexes = []);
        }
        if (options.fallback) {
          items = [FALLBACK];
          mapped[0] = createRoot(disposer => {
            disposers[0] = disposer;
            return options.fallback();
          });
          len = 1;
        }
      }
      else if (len === 0) {
        mapped = new Array(newLen);
        for (j = 0; j < newLen; j++) {
          items[j] = newItems[j];
          mapped[j] = createRoot(mapper);
        }
        len = newLen;
      } else {
        temp = new Array(newLen);
        tempdisposers = new Array(newLen);
        indexes && (tempIndexes = new Array(newLen));
        for (start = 0, end = Math.min(len, newLen); start < end && items[start] === newItems[start]; start++);
        for (end = len - 1, newEnd = newLen - 1; end >= start && newEnd >= start && items[end] === newItems[newEnd]; end--, newEnd--) {
          temp[newEnd] = mapped[end];
          tempdisposers[newEnd] = disposers[end];
          indexes && (tempIndexes[newEnd] = indexes[end]);
        }
        newIndices = new Map();
        newIndicesNext = new Array(newEnd + 1);
        for (j = newEnd; j >= start; j--) {
          item = newItems[j];
          i = newIndices.get(item);
          newIndicesNext[j] = i === undefined ? -1 : i;
          newIndices.set(item, j);
        }
        for (i = start; i <= end; i++) {
          item = items[i];
          j = newIndices.get(item);
          if (j !== undefined && j !== -1) {
            temp[j] = mapped[i];
            tempdisposers[j] = disposers[i];
            indexes && (tempIndexes[j] = indexes[i]);
            j = newIndicesNext[j];
            newIndices.set(item, j);
          } else disposers[i]();
        }
        for (j = start; j < newLen; j++) {
          if (j in temp) {
            mapped[j] = temp[j];
            disposers[j] = tempdisposers[j];
            if (indexes) {
              indexes[j] = tempIndexes[j];
              indexes[j](j);
            }
          } else mapped[j] = createRoot(mapper);
        }
        mapped = mapped.slice(0, len = newLen);
        items = newItems.slice(0);
      }
      return mapped;
    });
    function mapper(disposer) {
      disposers[j] = disposer;
      if (indexes) {
        const [s, set] = createSignal(j);
        indexes[j] = set;
        return mapFn(newItems[j], s);
      }
      return mapFn(newItems[j]);
    }
  };
}
function createComponent(Comp, props) {
  return untrack(() => Comp(props || {}));
}
function trueFn() {
  return true;
}
const propTraps = {
  get(_, property, receiver) {
    if (property === $PROXY) return receiver;
    return _.get(property);
  },
  has(_, property) {
    if (property === $PROXY) return true;
    return _.has(property);
  },
  set: trueFn,
  deleteProperty: trueFn,
  getOwnPropertyDescriptor(_, property) {
    return {
      configurable: true,
      enumerable: true,
      get() {
        return _.get(property);
      },
      set: trueFn,
      deleteProperty: trueFn
    };
  },
  ownKeys(_) {
    return _.keys();
  }
};
function splitProps(props, ...keys) {
  const len = keys.length;
  if (SUPPORTS_PROXY && $PROXY in props) {
    const blocked = len > 1 ? keys.flat() : keys[0];
    const claimed = new Set();
    const res = keys.map(k => {
      const owned = k.filter(property => !claimed.has(property) && (claimed.add(property), true));
      return new Proxy({
        get(property) {
          return owned.includes(property) ? props[property] : undefined;
        },
        has(property) {
          return owned.includes(property) && property in props;
        },
        keys() {
          return owned.filter(property => property in props);
        }
      }, propTraps);
    });
    res.push(new Proxy({
      get(property) {
        return blocked.includes(property) ? undefined : props[property];
      },
      has(property) {
        return blocked.includes(property) ? false : property in props;
      },
      keys() {
        return Object.keys(props).filter(k => !blocked.includes(k));
      }
    }, propTraps));
    return res;
  }
  const objects = [];
  for (let i = 0; i <= len; i++) {
    objects[i] = {};
  }
  for (const propName of Object.getOwnPropertyNames(props)) {
    let keyIndex = len;
    for (let i = 0; i < keys.length; i++) {
      if (keys[i].includes(propName)) {
        keyIndex = i;
        break;
      }
    }
    const desc = Object.getOwnPropertyDescriptor(props, propName);
    const isDefaultDesc = !desc.get && !desc.set && desc.enumerable && desc.writable && desc.configurable;
    isDefaultDesc ? objects[keyIndex][propName] = desc.value : Object.defineProperty(objects[keyIndex], propName, desc);
  }
  return objects;
}
function lazy(fn) {
  let comp;
  let p;
  const load = () => {
    if (!p) {
      const cur = p = fn();
      cur.then(mod => {
        comp = () => mod.default;
      }, () => {
        if (p === cur) p = undefined;
      });
    }
    return p;
  };
  const wrap = props => {
    const ctx = sharedConfig.context;
    if (ctx) {
      const [s, set] = createSignal();
      sharedConfig.count || (sharedConfig.count = 0);
      sharedConfig.count++;
      load().then(mod => {
        !sharedConfig.done && setHydrateContext(ctx);
        sharedConfig.count--;
        set(() => mod.default);
        setHydrateContext();
      }, err => {
        !sharedConfig.done && setHydrateContext(ctx);
        sharedConfig.count--;
        set(() => () => {
          throw err;
        });
        setHydrateContext();
      });
      comp = s;
    } else if (!comp) {
      const [s] = createResource(() => load().then(mod => mod.default));
      comp = s;
      onCleanup(() => comp = undefined);
    }
    let Comp;
    return createMemo(() => (Comp = comp?.()) ? untrack(() => {
      if (IS_DEV) ;
      if (!ctx || sharedConfig.done) return Comp(props);
      const c = sharedConfig.context;
      setHydrateContext(ctx);
      const r = Comp(props);
      setHydrateContext(c);
      return r;
    }) : "");
  };
  wrap.preload = () => load();
  return wrap;
}

const narrowedError = name => `Stale read from <${name}>.`;
function For(props) {
  const fallback = "fallback" in props && {
    fallback: () => props.fallback
  };
  return createMemo(mapArray(() => props.each, props.children, fallback || undefined));
}
function Show(props) {
  const keyed = props.keyed;
  const conditionValue = createMemo(() => props.when, undefined, undefined);
  const condition = keyed ? conditionValue : createMemo(conditionValue, undefined, {
    equals: (a, b) => !a === !b
  });
  return createMemo(() => {
    const c = condition();
    if (c) {
      const child = props.children;
      const fn = typeof child === "function" && child.length > 0;
      return fn ? untrack(() => child(keyed ? c : () => {
        if (!untrack(condition)) throw narrowedError("Show");
        return conditionValue();
      })) : child;
    }
    return props.fallback;
  }, undefined, undefined);
}
function Switch(props) {
  const chs = children(() => props.children);
  const switchFunc = createMemo(() => {
    const ch = chs();
    const mps = Array.isArray(ch) ? ch : [ch];
    let func = () => undefined;
    for (let i = 0; i < mps.length; i++) {
      const index = i;
      const mp = mps[i];
      const prevFunc = func;
      const conditionValue = createMemo(() => prevFunc() ? undefined : mp.when, undefined, undefined);
      const condition = mp.keyed ? conditionValue : createMemo(conditionValue, undefined, {
        equals: (a, b) => !a === !b
      });
      func = () => prevFunc() || (condition() ? [index, conditionValue, mp] : undefined);
    }
    return func;
  });
  return createMemo(() => {
    const sel = switchFunc()();
    if (!sel) return props.fallback;
    const [index, conditionValue, mp] = sel;
    const child = mp.children;
    const fn = typeof child === "function" && child.length > 0;
    return fn ? untrack(() => child(mp.keyed ? conditionValue() : () => {
      if (untrack(switchFunc)()?.[0] !== index) throw narrowedError("Match");
      return conditionValue();
    })) : child;
  }, undefined, undefined);
}
function Match(props) {
  return props;
}
const SuspenseListContext = /* #__PURE__ */createContext();
function Suspense(props) {
  let counter = 0,
    show,
    ctx,
    p,
    flicker,
    error;
  const [inFallback, setFallback] = createSignal(false),
    SuspenseContext = getSuspenseContext(),
    store = {
      increment: () => {
        if (++counter === 1) setFallback(true);
      },
      decrement: () => {
        if (--counter === 0) setFallback(false);
      },
      inFallback,
      effects: [],
      resolved: false
    },
    owner = getOwner();
  if (sharedConfig.context && sharedConfig.load) {
    const key = sharedConfig.getContextId();
    let ref = sharedConfig.load(key);
    if (ref) {
      if (typeof ref !== "object" || ref.s !== 1) p = ref;else sharedConfig.gather(key);
    }
    if (p && p !== "$$f") {
      const [s, set] = createSignal(undefined, {
        equals: false
      });
      flicker = s;
      p.then(() => {
        if (sharedConfig.done) return set();
        sharedConfig.gather(key);
        setHydrateContext(ctx);
        set();
        setHydrateContext();
      }, err => {
        error = err;
        set();
      });
    }
  }
  const listContext = useContext(SuspenseListContext);
  if (listContext) show = listContext.register(store.inFallback);
  let dispose;
  onCleanup(() => dispose && dispose());
  return createComponent(SuspenseContext.Provider, {
    value: store,
    get children() {
      return createMemo(() => {
        if (error) throw error;
        ctx = sharedConfig.context;
        if (flicker) {
          flicker();
          return flicker = undefined;
        }
        if (ctx && p === "$$f") setHydrateContext();
        const rendered = createMemo(() => props.children);
        return createMemo(prev => {
          const inFallback = store.inFallback(),
            {
              showContent = true,
              showFallback = true
            } = show ? show() : {};
          if ((!inFallback || p && p !== "$$f") && showContent) {
            store.resolved = true;
            dispose && dispose();
            dispose = ctx = p = undefined;
            resumeEffects(store.effects);
            return rendered();
          }
          if (!showFallback) return;
          if (dispose) return prev;
          return createRoot(disposer => {
            dispose = disposer;
            if (ctx) {
              setHydrateContext({
                id: ctx.id + "F",
                count: 0
              });
              ctx = undefined;
            }
            return props.fallback;
          }, owner);
        });
      });
    }
  });
}

const memo = fn => createMemo(() => fn());

function reconcileArrays(parentNode, a, b) {
  let bLength = b.length,
    aEnd = a.length,
    bEnd = bLength,
    aStart = 0,
    bStart = 0,
    after = a[aEnd - 1].nextSibling,
    map = null;
  while (aStart < aEnd || bStart < bEnd) {
    if (a[aStart] === b[bStart]) {
      aStart++;
      bStart++;
      continue;
    }
    while (a[aEnd - 1] === b[bEnd - 1]) {
      aEnd--;
      bEnd--;
    }
    if (aEnd === aStart) {
      const node = bEnd < bLength ? bStart ? b[bStart - 1].nextSibling : b[bEnd - bStart] : after;
      while (bStart < bEnd) parentNode.insertBefore(b[bStart++], node);
    } else if (bEnd === bStart) {
      while (aStart < aEnd) {
        if (!map || !map.has(a[aStart])) a[aStart].remove();
        aStart++;
      }
    } else if (a[aStart] === b[bEnd - 1] && b[bStart] === a[aEnd - 1]) {
      const node = a[--aEnd].nextSibling;
      parentNode.insertBefore(b[bStart++], a[aStart++].nextSibling);
      parentNode.insertBefore(b[--bEnd], node);
      a[aEnd] = b[bEnd];
    } else {
      if (!map) {
        map = new Map();
        let i = bStart;
        while (i < bEnd) map.set(b[i], i++);
      }
      const index = map.get(a[aStart]);
      if (index != null) {
        if (bStart < index && index < bEnd) {
          let i = aStart,
            sequence = 1,
            t;
          while (++i < aEnd && i < bEnd) {
            if ((t = map.get(a[i])) == null || t !== index + sequence) break;
            sequence++;
          }
          if (sequence > index - bStart) {
            const node = a[aStart];
            while (bStart < index) parentNode.insertBefore(b[bStart++], node);
          } else parentNode.replaceChild(b[bStart++], a[aStart++]);
        } else aStart++;
      } else a[aStart++].remove();
    }
  }
}

const $$EVENTS = "_$DX_DELEGATE";
function render(code, element, init, options = {}) {
  let disposer;
  createRoot(dispose => {
    disposer = dispose;
    element === document ? code() : insert(element, code(), element.firstChild ? null : undefined, init);
  }, options.owner);
  return () => {
    disposer();
    element.textContent = "";
  };
}
function template(html, isImportNode, isSVG, isMathML) {
  let node;
  const create = () => {
    const t = document.createElement("template");
    t.innerHTML = html;
    return t.content.firstChild;
  };
  const fn = () => (node || (node = create())).cloneNode(true);
  fn.cloneNode = fn;
  return fn;
}
function delegateEvents(eventNames, document = window.document) {
  const e = document[$$EVENTS] || (document[$$EVENTS] = new Set());
  for (let i = 0, l = eventNames.length; i < l; i++) {
    const name = eventNames[i];
    if (!e.has(name)) {
      e.add(name);
      document.addEventListener(name, eventHandler);
    }
  }
}
function setAttribute(node, name, value) {
  if (isHydrating(node)) return;
  if (value == null) node.removeAttribute(name);else node.setAttribute(name, value);
}
function className(node, value) {
  if (isHydrating(node)) return;
  if (value == null) node.removeAttribute("class");else node.className = value;
}
function addEventListener(node, name, handler, delegate) {
  if (delegate) {
    if (Array.isArray(handler)) {
      node[`$$${name}`] = handler[0];
      node[`$$${name}Data`] = handler[1];
    } else node[`$$${name}`] = handler;
  } else if (Array.isArray(handler)) {
    const handlerFn = handler[0];
    node.addEventListener(name, handler[0] = e => handlerFn.call(node, handler[1], e));
  } else node.addEventListener(name, handler, typeof handler !== "function" && handler);
}
function style(node, value, prev) {
  if (!value) return prev ? setAttribute(node, "style") : value;
  const nodeStyle = node.style;
  if (typeof value === "string") return nodeStyle.cssText = value;
  typeof prev === "string" && (nodeStyle.cssText = prev = undefined);
  prev || (prev = {});
  value || (value = {});
  let v, s;
  for (s in prev) {
    value[s] == null && nodeStyle.removeProperty(s);
    delete prev[s];
  }
  for (s in value) {
    v = value[s];
    if (v !== prev[s]) {
      nodeStyle.setProperty(s, v);
      prev[s] = v;
    }
  }
  return prev;
}
function setStyleProperty(node, name, value) {
  value != null ? node.style.setProperty(name, value) : node.style.removeProperty(name);
}
function use(fn, element, arg) {
  return untrack(() => fn(element, arg));
}
function insert(parent, accessor, marker, initial) {
  if (marker !== undefined && !initial) initial = [];
  if (typeof accessor !== "function") return insertExpression(parent, accessor, initial, marker);
  createRenderEffect(current => insertExpression(parent, accessor(), current, marker), initial);
}
function isHydrating(node) {
  return !!sharedConfig.context && !sharedConfig.done && (!node || node.isConnected);
}
function eventHandler(e) {
  if (sharedConfig.registry && sharedConfig.events) {
    if (sharedConfig.events.find(([el, ev]) => ev === e)) return;
  }
  let node = e.target;
  const key = `$$${e.type}`;
  const oriTarget = e.target;
  const oriCurrentTarget = e.currentTarget;
  const retarget = value => Object.defineProperty(e, "target", {
    configurable: true,
    value
  });
  const handleNode = () => {
    const handler = node[key];
    if (handler && !node.disabled) {
      const data = node[`${key}Data`];
      data !== undefined ? handler.call(node, data, e) : handler.call(node, e);
      if (e.cancelBubble) return;
    }
    node.host && typeof node.host !== "string" && !node.host._$host && node.contains(e.target) && retarget(node.host);
    return true;
  };
  const walkUpTree = () => {
    while (handleNode() && (node = node._$host || node.parentNode || node.host));
  };
  Object.defineProperty(e, "currentTarget", {
    configurable: true,
    get() {
      return node || document;
    }
  });
  if (sharedConfig.registry && !sharedConfig.done) sharedConfig.done = _$HY.done = true;
  if (e.composedPath) {
    const path = e.composedPath();
    retarget(path[0]);
    for (let i = 0; i < path.length - 2; i++) {
      node = path[i];
      if (!handleNode()) break;
      if (node._$host) {
        node = node._$host;
        walkUpTree();
        break;
      }
      if (node.parentNode === oriCurrentTarget) {
        break;
      }
    }
  }
  else walkUpTree();
  retarget(oriTarget);
}
function insertExpression(parent, value, current, marker, unwrapArray) {
  const hydrating = isHydrating(parent);
  if (hydrating) {
    !current && (current = [...parent.childNodes]);
    let cleaned = [];
    for (let i = 0; i < current.length; i++) {
      const node = current[i];
      if (node.nodeType === 8 && node.data.slice(0, 2) === "!$") node.remove();else cleaned.push(node);
    }
    current = cleaned;
  }
  while (typeof current === "function") current = current();
  if (value === current) return current;
  const t = typeof value,
    multi = marker !== undefined;
  parent = multi && current[0] && current[0].parentNode || parent;
  if (t === "string" || t === "number") {
    if (hydrating) return current;
    if (t === "number") {
      value = value.toString();
      if (value === current) return current;
    }
    if (multi) {
      let node = current[0];
      if (node && node.nodeType === 3) {
        node.data !== value && (node.data = value);
      } else node = document.createTextNode(value);
      current = cleanChildren(parent, current, marker, node);
    } else {
      if (current !== "" && typeof current === "string") {
        current = parent.firstChild.data = value;
      } else current = parent.textContent = value;
    }
  } else if (value == null || t === "boolean") {
    if (hydrating) return current;
    current = cleanChildren(parent, current, marker);
  } else if (t === "function") {
    createRenderEffect(() => {
      let v = value();
      while (typeof v === "function") v = v();
      current = insertExpression(parent, v, current, marker);
    });
    return () => current;
  } else if (Array.isArray(value)) {
    const array = [];
    const currentArray = current && Array.isArray(current);
    if (normalizeIncomingArray(array, value, current, unwrapArray)) {
      createRenderEffect(() => current = insertExpression(parent, array, current, marker, true));
      return () => current;
    }
    if (hydrating) {
      if (!array.length) return current;
      if (marker === undefined) return current = [...parent.childNodes];
      let node = array[0];
      if (node.parentNode !== parent) return current;
      const nodes = [node];
      while ((node = node.nextSibling) !== marker) nodes.push(node);
      return current = nodes;
    }
    if (array.length === 0) {
      current = cleanChildren(parent, current, marker);
      if (multi) return current;
    } else if (currentArray) {
      if (current.length === 0) {
        appendNodes(parent, array, marker);
      } else reconcileArrays(parent, current, array);
    } else {
      current && cleanChildren(parent);
      appendNodes(parent, array);
    }
    current = array;
  } else if (value.nodeType) {
    if (hydrating && value.parentNode) return current = multi ? [value] : value;
    if (Array.isArray(current)) {
      if (multi) return current = cleanChildren(parent, current, marker, value);
      cleanChildren(parent, current, null, value);
    } else if (current == null || current === "" || !parent.firstChild) {
      parent.appendChild(value);
    } else parent.replaceChild(value, parent.firstChild);
    current = value;
  } else ;
  return current;
}
function normalizeIncomingArray(normalized, array, current, unwrap) {
  let dynamic = false;
  for (let i = 0, len = array.length; i < len; i++) {
    let item = array[i],
      prev = current && current[normalized.length],
      t;
    if (item == null || item === true || item === false) ; else if ((t = typeof item) === "object" && item.nodeType) {
      normalized.push(item);
    } else if (Array.isArray(item)) {
      dynamic = normalizeIncomingArray(normalized, item, prev) || dynamic;
    } else if (t === "function") {
      if (unwrap) {
        while (typeof item === "function") item = item();
        dynamic = normalizeIncomingArray(normalized, Array.isArray(item) ? item : [item], Array.isArray(prev) ? prev : [prev]) || dynamic;
      } else {
        normalized.push(item);
        dynamic = true;
      }
    } else {
      const value = String(item);
      if (prev && prev.nodeType === 3 && prev.data === value) normalized.push(prev);else normalized.push(document.createTextNode(value));
    }
  }
  return dynamic;
}
function appendNodes(parent, array, marker = null) {
  for (let i = 0, len = array.length; i < len; i++) parent.insertBefore(array[i], marker);
}
function cleanChildren(parent, current, marker, replacement) {
  if (marker === undefined) return parent.textContent = "";
  const node = replacement || document.createTextNode("");
  if (current.length) {
    let inserted = false;
    for (let i = current.length - 1; i >= 0; i--) {
      const el = current[i];
      if (node !== el) {
        const isParent = el.parentNode === parent;
        if (!inserted && !i) isParent ? parent.replaceChild(node, el) : parent.insertBefore(node, marker);else isParent && el.remove();
      } else inserted = true;
    }
  } else parent.insertBefore(node, marker);
  return [node];
}
const SVG_NAMESPACE = "http://www.w3.org/2000/svg";
function createElement(tagName, isSVG = false, is = undefined) {
  return isSVG ? document.createElementNS(SVG_NAMESPACE, tagName) : document.createElement(tagName, {
    is
  });
}
function Portal(props) {
  const {
      useShadow
    } = props,
    marker = document.createTextNode(""),
    mount = () => props.mount || document.body,
    owner = getOwner();
  let content;
  let hydrating = !!sharedConfig.context;
  createEffect(() => {
    if (hydrating) getOwner().user = hydrating = false;
    content || (content = runWithOwner(owner, () => createMemo(() => props.children)));
    const el = mount();
    if (el instanceof HTMLHeadElement) {
      const [clean, setClean] = createSignal(false);
      const cleanup = () => setClean(true);
      createRoot(dispose => insert(el, () => !clean() ? content() : dispose(), null));
      onCleanup(cleanup);
    } else {
      const container = createElement(props.isSVG ? "g" : "div", props.isSVG),
        renderRoot = useShadow && container.attachShadow ? container.attachShadow({
          mode: "open"
        }) : container;
      Object.defineProperty(container, "_$host", {
        get() {
          return marker.parentNode;
        },
        configurable: true
      });
      insert(renderRoot, content);
      el.appendChild(container);
      props.ref && props.ref(container);
      onCleanup(() => el.contains(container) && el.removeChild(container));
    }
  }, undefined, {
    render: !hydrating
  });
  return marker;
}

const scriptRel = 'modulepreload';const assetsURL = function(dep, importerUrl) { return new URL(dep, importerUrl).href };const seen = {};const __vitePreload = function preload(baseModule, deps, importerUrl) {
	let promise = Promise.resolve();
	if (true               && deps && deps.length > 0) {
		const links = document.getElementsByTagName("link");
		const cspNonceMeta = document.querySelector("meta[property=csp-nonce]");
		const cspNonce = cspNonceMeta?.nonce || cspNonceMeta?.getAttribute("nonce");
		function allSettled(promises$2) {
			return Promise.all(promises$2.map((p) => Promise.resolve(p).then((value$1) => ({
				status: "fulfilled",
				value: value$1
			}), (reason) => ({
				status: "rejected",
				reason
			}))));
		}
		promise = allSettled(deps.map((dep) => {
			dep = assetsURL(dep, importerUrl);
			if (dep in seen) return;
			seen[dep] = true;
			const isCss = dep.endsWith(".css");
			const cssSelector = isCss ? "[rel=\"stylesheet\"]" : "";
			if (!!importerUrl) for (let i$1 = links.length - 1; i$1 >= 0; i$1--) {
				const link$1 = links[i$1];
				if (link$1.href === dep && (!isCss || link$1.rel === "stylesheet")) return;
			}
			else if (document.querySelector(`link[href="${dep}"]${cssSelector}`)) return;
			const link = document.createElement("link");
			link.rel = isCss ? "stylesheet" : scriptRel;
			if (!isCss) link.as = "script";
			link.crossOrigin = "";
			link.href = dep;
			if (cspNonce) link.setAttribute("nonce", cspNonce);
			document.head.appendChild(link);
			if (isCss) return new Promise((res, rej) => {
				link.addEventListener("load", res);
				link.addEventListener("error", () => rej(/* @__PURE__ */ new Error(`Unable to preload CSS for ${dep}`)));
			});
		}));
	}
	function handlePreloadError(err$2) {
		const e$1 = new Event("vite:preloadError", { cancelable: true });
		e$1.payload = err$2;
		window.dispatchEvent(e$1);
		if (!e$1.defaultPrevented) throw err$2;
	}
	return promise.then((res) => {
		for (const item of res || []) {
			if (item.status !== "rejected") continue;
			handlePreloadError(item.reason);
		}
		return baseModule().catch(handlePreloadError);
	});
};

const __variableDynamicImportRuntimeHelper = (glob$1, path$13, segs) => {
	const v = glob$1[path$13];
	if (v) return typeof v === "function" ? v() : Promise.resolve(v);
	return new Promise((_, reject) => {
		(typeof queueMicrotask === "function" ? queueMicrotask : setTimeout)(reject.bind(null, /* @__PURE__ */ new Error("Unknown variable dynamic import: " + path$13 + (path$13.split("/").length !== segs ? ". Note that variables only represent file names one level deep." : ""))));
	});
};

const en = {
  "header.title": "ZEROMOUNT",
  "header.subtitle": "Enginex0",
  "nav.status": "Status",
  "nav.modules": "Modules",
  "nav.config": "Config",
  "nav.settings": "Settings",
  "status.engineActive": "Engine Active",
  "status.engineInactive": "Engine Inactive",
  "status.mountsActive": "Mounts Active",
  "status.noModulesLoaded": "No Modules Loaded",
  "status.enableEngine": "ENABLE ENGINE",
  "status.disableEngine": "DISABLE ENGINE",
  "status.quickStats": "Quick Stats",
  "status.activeRules": "Active Rules",
  "status.pathsHidden": "Paths Hidden",
  "status.mapsHidden": "Maps Hidden",
  "status.modeStatistics": "Mode Statistics",
  "status.modeVfs": "VFS Redirection",
  "status.modeOverlay": "OverlayFS",
  "status.modeMagicMount": "Magic Mount",
  "status.modeSusfsOnly": "SUSFS Only",
  "status.modeValueActive": "Active",
  "status.modeValueNoMount": "No Mount",
  "status.modeValueUnavailable": "Unavailable",
  "status.modeValueStandby": "Standby",
  "status.modeDescVfs": "Kernel VFS driver handling filesystem redirection",
  "status.modeDescOverlay": "OverlayFS stacked filesystem · Storage: {storage}",
  "status.modeDescMagicMount": "Bind mounts · Storage: {storage}",
  "status.modeDescSusfsOnly": "SUSFS hiding active, no mount redirection",
  "status.strategy": "Strategy",
  "status.switchingModeRequiresReboot": "Switching mode requires reboot",
  "status.susfs": "SUSFS",
  "status.susfsExtended": "Extended",
  "status.susfsStock": "Stock",
  "status.susfsUnavailable": "Unavailable",
  "status.perModuleStrategy": "Per-Module Strategy",
  "status.showLess": "Show Less",
  "status.showMore": "+{count} more",
  "status.filesUnit": "files",
  "status.rulesUnit": "rules",
  "status.mountInfo": "Mount Info",
  "status.modules": "Modules",
  "status.modulesActive": "{count} active",
  "status.source": "Source",
  "status.redirectedPaths": "Redirected Paths",
  "status.noPathsRedirected": "No paths redirected",
  "status.engineStatus": "Engine Status",
  "status.levelInfo": "INFO",
  "status.levelWarning": "WARNING",
  "status.healthSusfs": "SUSFS",
  "status.healthSusfsExtendedAll": "Extended kernel, all features available",
  "status.healthSusfsActive": "SUSFS active, core protections enabled",
  "status.healthSusfsAvailableDisabled": "SUSFS available but disabled",
  "status.healthSusfsNotDetected": "SUSFS not detected on this kernel",
  "status.healthRuleFailures": "Mount Errors",
  "status.healthRules": "Rules",
  "status.healthNoRulesHint": "Add redirection rules to start mounting modules",
  "status.recentActivity": "Recent Activity",
  "status.viewAll": "View All",
  "status.timeJustNow": "Just now",
  "status.timeMinAgo": "{minutes} min ago",
  "status.timeHoursAgo": "{hours}h ago",
  "status.timeDaysAgo": "{days} days ago",
  "status.systemInfo": "System Info",
  "status.infoDevice": "Device:",
  "status.infoAndroid": "Android:",
  "status.infoSelinux": "SELinux:",
  "status.infoKernel": "Kernel:",
  "status.infoDriver": "Driver:",
  "status.infoEngine": "Engine:",
  "status.infoSusfs": "SUSFS:",
  "status.infoRoot": "Root:",
  "status.infoRootUnknown": "Unknown",
  "status.infoMisc": "misc:",
  "status.infoMiscValue": "/dev/zeromount",
  "modules.searchPlaceholder": "Search modules...",
  "modules.scan": "SCAN",
  "modules.filesCount": "{count} files",
  "modules.detailActive": "Active",
  "modules.detailInactive": "Inactive",
  "modules.hotUnload": "HOT UNLOAD",
  "modules.hotLoad": "HOT LOAD",
  "modules.emptyNoMatch": "No modules match your search",
  "modules.emptyNoModules": "No modules with system overlays",
  "modules.emptyHintSearch": "Try a different search term",
  "modules.emptyHintInstall": "Install KernelSU modules with system/vendor/product directories",
  "modules.path": "Path",
  "modules.partitions": "Partitions",
  "modules.files": "Files:",
  "modules.status": "Status:",
  "modules.notLoaded": "Not Loaded",
  "modules.font": "Font",
  "modules.overlay": "Overlay",
  "modules.magic": "Magic",
  "modules.loaded": "Loaded",
  "config.searchPlaceholder": "Search apps...",
  "config.excludedApps": "Excluded Apps",
  "config.excludedDesc": "These apps bypass spoofing and mounts are visible - caution",
  "config.excludedNoMatches": "No matches",
  "config.excludedNone": "No excluded apps",
  "config.remove": "REMOVE",
  "config.allApps": "All Apps",
  "config.userApps": "User Apps",
  "config.systemApps": "System Apps",
  "config.sysBadge": "SYS",
  "config.appsNoMatches": "No matches",
  "config.appsNoAll": "No apps found",
  "config.appsNoUser": "No user apps found",
  "config.exclude": "EXCLUDE",
  "settings.engine": "Engine",
  "settings.verboseLogging": "Verbose logging",
  "settings.verboseLoggingDesc": "Capture all ZeroMount logs from boot — requires reboot",
  "settings.verboseModeActive": "Verbose mode active — logs captured since last boot",
  "settings.verboseLogsAt": "Logs at: {path}/",
  "settings.clearAllRules": "CLEAR ALL RULES",
  "settings.vfsUnavailable": "VFS UNAVAILABLE",
  "settings.propertySpoofing": "Property Spoofing",
  "settings.propNote": "Uses resetprop, independent of SUSFS",
  "settings.buildProperties": "Build Properties",
  "settings.buildPropertiesDesc": "Spoof ro.build.* properties for detection bypass",
  "settings.androidSettings": "Android Settings",
  "settings.developerOptions": "Developer Options",
  "settings.developerOptionsDesc": "Default system settings toggle",
  "settings.usbDebugging": "USB Debugging",
  "settings.performance": "Performance",
  "settings.perfTweak": "Performance Tweak",
  "settings.perfTweakDesc": "Optimize scheduler, memory, I/O and CPU frequency at boot",
  "settings.emoji": "Emoji",
  "settings.facebookEmojis": "Facebook Emojis",
  "settings.facebookEmojisDesc": "Replace system emojis with Facebook 15.0 style",
  "settings.emojiConflict": "Conflicting font module: {module}",
  "settings.more": "More",
  "modal.clearAllRulesTitle": "Clear All Rules?",
  "modal.clearAllRulesText": "This will permanently delete all {count} VFS rules. This action cannot be undone.",
  "modal.cancel": "Cancel",
  "modal.clearAll": "CLEAR ALL",
  "appearance.title": "Appearance",
  "appearance.theme": "Theme",
  "appearance.language": "Language",
  "appearance.dark": "Dark",
  "appearance.light": "Light",
  "appearance.auto": "Auto",
  "appearance.amoled": "AMOLED",
  "appearance.accentColor": "Accent Color",
  "appearance.colorOrange": "Orange",
  "appearance.colorEmerald": "Emerald",
  "appearance.colorBeige": "Beige",
  "appearance.colorAmethyst": "Amethyst",
  "appearance.colorFuchsia": "Fuchsia",
  "appearance.colorLime": "Lime",
  "appearance.colorIndigo": "Indigo",
  "appearance.colorCoral": "Coral",
  "appearance.randomAccent": "Random Accent",
  "appearance.randomAccentDesc": "Change accent color each session",
  "appearance.glassIntensity": "Glass Intensity",
  "appearance.glassIntensityDesc": "Background frosted glass effect",
  "appearance.fixBottomNav": "Fix Bottom Nav",
  "appearance.fixBottomNavDesc": "Pin navigation to bottom of screen",
  "capabilities.title": "Kernel Capabilities",
  "capabilities.desc": "Optional kernel features that can extend ZeroMount",
  "capabilities.expandLabel": "Available Enhancements",
  "capabilities.vfsDriver": "VFS Driver",
  "capabilities.vfsDriverDesc": "Kernel-level filesystem redirection. Requires a custom kernel with the ZeroMount VFS patch applied.",
  "capabilities.kstatRedirect": "Kstat Redirect",
  "capabilities.kstatRedirectDesc": "Extended file metadata spoofing. Requires SUSFS with kstat_redirect support compiled into the kernel.",
  "capabilities.overlayFs": "OverlayFS",
  "capabilities.overlayFsDesc": "Stacked filesystem mounts. Requires CONFIG_OVERLAY_FS enabled in kernel config.",
  "capabilities.susfs": "SUSFS",
  "capabilities.susfsDesc": "Kernel-level hiding and spoofing. Requires SUSFS patches applied to the kernel source.",
  "engine.mountEngine": "Mount Engine",
  "engine.mountStrategy": "Mount Strategy",
  "engine.mountStrategyDescVfs": "VFS driver detected — auto-selects VFS when kernel driver is present",
  "engine.mountStrategyDescNoVfs": "No VFS driver — controls overlay vs magic mount preference",
  "engine.strategyVfs": "VFS",
  "engine.strategyVfsHint": "Auto / Kernel",
  "engine.strategyOverlay": "Overlay",
  "engine.strategyOverlayHint": "OverlayFS",
  "engine.strategyMagic": "Magic",
  "engine.strategyMagicHint": "Bind Mount",
  "engine.switchingRequiresReboot": "Switching mode requires reboot",
  "engine.magicMountNoSusfsWarning": "MagicMount leaves detectable bind-mount traces without SUSFS. Consider OverlayFS for better stealth.",
  "engine.storageBackend": "Storage Backend",
  "engine.storageBackendDesc": "Filesystem for staging module content",
  "engine.storageBackendNoXattr": "tmpfs lacks xattr — overlay whiteouts unavailable",
  "engine.storageAuto": "Auto",
  "engine.storageErofs": "EROFS",
  "engine.storageTmpfs": "tmpfs",
  "engine.storageExt4": "ext4",
  "engine.storageUnavailable": "{selected} unavailable — resolved to {resolved}",
  "engine.randomMountPaths": "Random Mount Paths",
  "engine.randomMountPathsDesc": "Randomize staging directory names at boot",
  "engine.overlayMountSource": "Overlay Mount Source",
  "engine.overlayMountSourceDesc": "Source device for overlay mounts",
  "engine.stagingMountSource": "Staging Mount Source",
  "engine.stagingMountSourceDesc": "Source device for staging mounts",
  "engine.titleVfsUnavailable": "VFS kernel driver not available",
  "engine.titleVfsAuto": "Auto: VFS when driver present, overlay/magic fallback",
  "engine.titleOverlayUnavailable": "OverlayFS not supported on this kernel",
  "engine.titleOverlayPrefer": "Prefer OverlayFS stacked filesystem",
  "engine.titleMagicMount": "Bind mounts (Magisk-style) — always available",
  "engine.customLabel": "Custom",
  "engine.overlayOptAuto": "Resolves per root manager (KSU/Magisk)",
  "engine.overlayOptKsu": "KernelSU device label",
  "engine.overlayOptMagisk": "Magisk device label",
  "engine.overlayOptOverlay": "Generic overlay device",
  "engine.overlayOptCustom": "Enter a custom device label",
  "engine.overlayPlaceholder": "e.g. my_overlay",
  "engine.stagingOptAuto": "Random selection per boot",
  "engine.stagingOptTmpfs": "RAM-backed temporary filesystem",
  "engine.stagingOptNone": "VFS tmpfs mount",
  "engine.stagingOptShmem": "Shared memory mount",
  "engine.stagingOptShm": "POSIX shared memory",
  "engine.stagingOptCustom": "Enter a custom device source",
  "engine.excludeHosts": "Exclude Hosts Overrides",
  "engine.excludeHostsDesc": "Skip modules that replace the system hosts file",
  "engine.restartFramework": "Restart Framework",
  "engine.restartFrameworkDesc": "Restart Android after mounting. Needed for GPU drivers and bootanimation modules",
  "engine.advancedMounting": "Advanced",
  "exclusion.title": "Module Exclusions",
  "exclusion.label": "Module Exclusions",
  "exclusion.desc": "Select modules to skip mounting. Takes effect on next reboot.",
  "exclusion.tagSelf": "self",
  "exclusion.tagDisabled": "disabled",
  "engine.ext4ImageSize": "EXT4 Image Size (MB)",
  "engine.ext4ImageSizeDesc": "Override sparse image size. 0 = auto-calculate",
  "engine.stagingPlaceholder": "e.g. my_source",
  "about.footerMadeWith": "Made with",
  "about.footerPassion": "passion",
  "about.footerForThe": "for the Android",
  "about.footerCommunity": "community",
  "susfs.title": "SUSFS Integration",
  "susfs.integrationDescAvailable": "Version {version} — {status}",
  "susfs.integrationDescNotDetected": "Not detected on this kernel",
  "susfs.toastTakingOwnership": "Taking SUSFS ownership from zeromount",
  "susfs.toastDeferred": "Deferred to {module}",
  "susfs.hideSusMounts": "Hide Sus Mounts",
  "susfs.hideSusMountsDesc": "Hide module mounts from non-root processes",
  "susfs.keepMountsAfterBoot": "Keep active after boot",
  "susfs.keepMountsAfterBootDesc": "Keep mounts hidden after boot completes",
  "susfs.pathHiding": "Path Hiding",
  "susfs.pathHidingDesc": "Hide paths from detection apps",
  "susfs.kstatSpoofing": "Kstat Spoofing",
  "susfs.kstatSpoofingDesc": "Spoof file metadata for redirected files",
  "susfs.mapsHiding": "Maps Hiding",
  "susfs.mapsHidingDesc": "Hide module entries from /proc/maps",
  "susfs.advancedSettings": "Advanced Settings",
  "susfs.controlLabel": "SUSFS Control",
  "susfs.emulateVoldAppData": "Emulate Vold App Data",
  "susfs.emulateVoldAppDataDesc": "Hide app data paths via sus_path on /sdcard/Android/data",
  "susfs.voldUsePathLoop": "Use sus_path_loop",
  "susfs.voldUsePathLoopDesc": "Recursive directory hiding instead of per-path",
  "susfs.forceHideLsposed": "Force Hide LSPosed",
  "susfs.forceHideLsposedDesc": "Unmount dex2oat paths to hide LSPosed injection",
  "susfs.hideKsuLoopDevices": "Hide KSU Loop Devices",
  "susfs.hideKsuLoopDevicesDesc": "Hide loop device entries in /proc/fs",
  "susfs.avcLogSpoofing": "AVC Log Spoofing",
  "susfs.avcLogSpoofingDesc": "Suppress SELinux audit log entries",
  "susfs.spoofCmdline": "Cmdline / Bootconfig",
  "susfs.spoofCmdlineDesc": "SUSFS: bootconfig on GKI, cmdline on non-GKI. Format-aware boot-state fields with readback. Does not change the bootloader or Knox fuse. Reboot required.",
  "susfs.susfsDebugLog": "SUSFS Debug Log",
  "susfs.susfsDebugLogDesc": "Enable kernel-level SUSFS logging",
  "susfs.autoHidingLabel": "Auto-Hiding",
  "susfs.hideRootedAppFolders": "Hide Rooted App Folders",
  "susfs.hideRootedAppFoldersDesc": "Hide Magisk/KSU app data directories",
  "susfs.hideModuleInjections": "Hide Module Injections",
  "susfs.hideModuleInjectionsDesc": "Hide injected module files from /proc/maps",
  "susfs.hideInjectedApks": "Hide Injected APKs",
  "susfs.hideInjectedApksDesc": "Hide module APKs in vendor/product/system_ext",
  "susfs.hideZygiskMaps": "Hide Zygisk .so in Maps",
  "susfs.hideZygiskMapsDesc": "Remove zygisk entries from /proc/maps",
  "susfs.hideFontFilesMaps": "Hide Font Files in Maps",
  "susfs.hideFontFilesMapsDesc": "Remove custom font entries from /proc/maps",
  "susfs.hideRecoveryFolders": "Hide Recovery Folders",
  "susfs.hideRecoveryFoldersDesc": "Hide TWRP/OrangeFox directories",
  "susfs.hideDataLocalTmp": "Hide /data/local/tmp",
  "susfs.hideDataLocalTmpDesc": "Hide temp files used by detection tools",
  "susfs.kernelUmount": "Kernel Umount",
  "susfs.kernelUmountDesc": "Enable kernel-level module unmounting via ksud",
  "susfs.autoTryUmount": "Auto Try Umount",
  "susfs.autoTryUmountDesc": "Discover and unmount KSU bind mounts in app namespaces",
  "susfs.skipLegitMounts": "Skip Legit Mounts",
  "susfs.skipLegitMountsDesc": "Skip known system mounts during auto try umount",
  "susfs.customRomLabel": "Custom ROM",
  "susfs.hideCusrom": "Hide Custom ROM Paths",
  "susfs.hideCusromDesc": "Hide LineageOS/CrDroid paths from detection",
  "susfs.hideCusromLevel": "Hide Level",
  "susfs.hideCusromLevel1": "Exclude .apk, .jar, .odex, .vdex, .so, .rc, /vendor/bin/hw/",
  "susfs.hideCusromLevel2": "Exclude .apk, .jar, .odex, .vdex, .so, /vendor/bin/hw/",
  "susfs.hideCusromLevel3": "Exclude .apk, .jar, .odex, .vdex, /vendor/bin/hw/",
  "susfs.hideCusromLevel4": "Exclude .apk, .jar, /vendor/bin/hw/",
  "susfs.hideCusromLevel5": "Hide all custom ROM paths (risky)",
  "susfs.spoofingLabel": "Spoofing",
  "susfs.unameSpoofing": "Uname Spoofing",
  "susfs.unameSpoofingDesc": "Spoof kernel version string",
  "susfs.unameModeDisabled": "Disabled",
  "susfs.unameModeStatic": "Static",
  "susfs.unameModeDynamic": "Dynamic",
  "guard.title": "Bootloop Guard",
  "guard.label": "Bootloop Guard",
  "guard.desc": "Auto-disable modules on repeated boot failures",
  "guard.pfd": "PFD {current}/{threshold}",
  "guard.svc": "SVC {current}/{threshold}",
  "guard.lastRecovery": "Last recovery: {date}",
  "guard.lockoutActive": "Recovery lockout active — mount pipeline disabled",
  "guard.clearLockout": "Clear lockout",
  "guard.systemuiMonitor": "SystemUI Monitor",
  "guard.systemuiMonitorDesc": "Continuous crash detection for SystemUI",
  "guard.protectedModules": "Protected Modules ({protected}/{total})",
  "guard.tagDisabled": "disabled",
  "guard.tagAlways": "always",
  "guard.thresholds": "Thresholds",
  "guard.bootTimeout": "Boot timeout (s)",
  "guard.markerThreshold": "Marker threshold",
  "guard.zygoteMaxRestarts": "Zygote max restarts",
  "guard.systemuiMaxRestarts": "SystemUI max restarts",
  "guard.systemuiAbsentTimeout": "SystemUI absent timeout (s)",
  "guard.moduleDisabled": "Module disabled",
  "guard.moduleActive": "Active",
  "guard.bootcount": "Boot #{count}",
  "guard.whitelist": "Module Whitelist",
  "guard.whitelistDesc": "Whitelisted ZeroMount-managed modules survive scoped guard isolation",
  "guard.self": "self",
  "guard.disabled": "disabled",
  "about.title": "About",
  "about.appName": "ZeroMount",
  "about.badge": "GHOST",
  "about.repository": "Repository",
  "about.copyDebugInfo": "Copy Debug Info",
  "about.exportConfig": "Export Config",
  "about.importConfig": "Import Config",
  "about.footer": "Made with {passion} for the Android {community}",
  "toast.failedLoadData": "Failed to load data",
  "toast.engineActivated": "Engine activated",
  "toast.engineDeactivated": "Engine deactivated",
  "toast.failedToggleEngine": "Failed to toggle engine",
  "toast.excludedApp": "Excluded {appName}",
  "toast.failedExcludeUid": "Failed to exclude UID",
  "toast.uidIncluded": "UID included",
  "toast.failedIncludeUid": "Failed to include UID",
  "toast.allRulesCleared": "All rules cleared",
  "toast.failedSaveKey": "Failed to save {key}",
  "toast.mountStrategyChanged": "Mount strategy changed — reboot to apply",
  "toast.failedLoadApps": "Failed to load apps",
  "toast.failedScanModules": "Failed to scan modules",
  "toast.moduleLoaded": "Loaded {moduleName} ({count} rules)",
  "toast.moduleUnloaded": "Unloaded {moduleName} ({count} rules)",
  "toast.logsSaved": "Logs saved to {path}",
  "toast.configExported": "Config exported to Downloads",
  "toast.importedConfig": "Imported {filename} — reload complete",
  "toast.failedExportConfig": "Failed to export config",
  "toast.failedImportConfig": "Failed to import config",
  "toast.failedDumpLogs": "Failed to dump logs",
  "toast.failedReadConfig": "Failed to read config",
  "toast.emptyFile": "Selected file is empty",
  "toast.failedWriteConfig": "Failed to write config",
  "toast.rebootingVerbose": "Rebooting in 3 seconds for verbose logging...",
  "toast.rebootFailed": "Reboot failed — please reboot manually",
  "toast.verboseDisabled": "Verbose logging disabled.",
  "toast.failedSetVerbose": "Failed to set verbose logging",
  "toast.cannotExcludeUnknownUid": "Cannot exclude app with unknown UID",
  "toast.cannotIncludeUnknownUid": "Cannot include app with unknown UID",
  "toast.addedToWhitelist": "{name} added to whitelist",
  "toast.failedWhitelist": "Failed to whitelist {name}",
  "toast.cannotRemoveSelf": "meta-zeromount cannot be removed",
  "toast.removedFromWhitelist": "{name} removed from whitelist",
  "toast.failedRemove": "Failed to remove {name}",
  "toast.lockoutCleared": "Recovery lockout cleared — pipeline re-enabled",
  "toast.failedClearLockout": "Failed to clear lockout",
  "toast.failedSaveUnameMode": "Failed to save uname mode",
  "toast.failedSaveUname": "Failed to save uname {field}",
  "toast.failedSaveStorageMode": "Failed to save storage mode",
  "toast.failedSaveMountSource": "Failed to save mount source",
  "toast.failedSaveOverlaySource": "Failed to save overlay source",
  "toast.failedSaveMountStrategy": "Failed to save mount strategy",
  "toast.failedLoadModule": "Failed to load {moduleName}",
  "toast.failedUnloadModule": "Failed to unload {moduleName}",
  "toast.vfsUnavailable": "ZeroMount VFS unavailable",
  "toast.failedClearRules": "Failed to clear rules",
  "ui.backToOptions": "Back to options",
  "ui.nMore": "{count} more",
  "uname.release": "Release",
  "uname.version": "Version",
  "scenario.fullProtection": "Full Protection",
  "scenario.vfsActive": "VFS Active",
  "scenario.strategyActive": "{strategy} Active",
  "scenario.initializing": "Initializing",
  "scenario.descInitializing": "Detecting kernel capabilities...",
  "scenario.susfsEnhanced": " + Enhanced SUSFS",
  "scenario.susfsEmbedded": " + Embedded SUSFS",
  "scenario.susfsSuffix": " + SUSFS",
  "scenario.descVfs": "VFS kernel driver{susfs}",
  "scenario.descAltVfsAvail": "{strategy}{susfs} · VFS available",
  "scenario.descSusfsOnly": "{strategy} + SUSFS protections",
  "scenario.descModuleMounts": "{strategy} module mounts",
  "rules.blocked": "[BLOCKED]",
  "rules.defaultName": "Rule",
  "exclusion.fallbackPackage": "app_{uid}",
  "exclusion.fallbackName": "UID {uid}",
  "activity.engineOn": "Engine → ON",
  "activity.engineOff": "Engine → OFF",
  "activity.themeChanged": "Theme → {value}",
  "activity.accentChanged": "Accent → {value}",
  "activity.fixedNavChanged": "Fixed nav → {value}",
  "activity.verboseChanged": "Verbose logging → {value}",
  "activity.settingChanged": "{key} → {value}",
  "activity.allRulesCleared": "All rules cleared",
  "activity.uidExcluded": "{name} (UID {uid})",
  "activity.uidIncluded": "UID {uid} included",
  "activity.strategyChanged": "Strategy → {value}",
  "activity.on": "ON",
  "activity.off": "OFF",
  "activity.empty": "(empty)",
  "susfs.cleanupSusMarker": "Clean SUS storage marker",
  "susfs.cleanupSusMarkerDesc": "Remove writable ..5.u.S redirect leftovers once after boot",
  "susfs.hideNonstandardAndroid": "Hide non-standard Android folders",
  "susfs.hideNonstandardAndroidDesc": "Hide direct /storage/emulated/0/Android children except data, media and obb (advanced)",
  "susfs.syncSuCompat": "Persist SU compatibility",
  "susfs.syncSuCompatDesc": "Apply and save both ON and OFF for su_compat; repeat the selected state after boot.",
  "susfs.syncSelinuxHide": "Persist SELinux hide",
  "susfs.syncSelinuxHideDesc": "Apply and save both ON and OFF for selinux_hide; repeat the selected state after boot.",
  "susfs.storageFilter": "Filter storage folders (BRENE 66)",
  "susfs.storageFilterDesc": "Optional: hide non-standard children of /storage/emulated/0. Standard and Samsung folders remain visible. Add exceptions to brene.sdcard_allowlist. May affect apps; reboot required.",
  "susfs.propertyGroups": "Build and system properties",
  "susfs.generalProps": "System properties",
  "susfs.generalPropsDesc": "Apply general property rules at boot. Shared boot values keep their central owner.",
  "susfs.fingerprintProps": "Fingerprint properties",
  "susfs.fingerprintPropsDesc": "BRENE 67: align existing partition fingerprints to the cleaned system fingerprint. Applied after reboot.",
  "susfs.utcProps": "UTC build-date properties",
  "susfs.utcPropsDesc": "Align existing UTC build-date properties to ro.build.date.utc. Does not change the device clock. Applied after reboot.",
  "susfs.dateProps": "Build-date text properties",
  "susfs.datePropsDesc": "Align existing partition date strings to ro.build.date. Applied after reboot.",
  "susfs.repeatProps": "Repeat system properties",
  "susfs.repeatPropsDesc": "Recheck general system properties every 60 seconds. Default off; restart to start the worker.",
};

const en$1 = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
	__proto__: null,
	default: en
}, Symbol.toStringTag, { value: 'Module' }));

const cache = { en };
const [locale, setLocaleSignal] = createSignal('en');
const [strings, setStrings] = createSignal(en);
function t(key, params) {
    let str = strings()[key] ?? en[key] ?? key;
    if (params) {
        for (const [k, v] of Object.entries(params))
            str = str.replaceAll(`{${k}}`, String(v));
    }
    return str;
}
function getInlinedLocale(code) {
    const locales = window.__ZM_LOCALES__;
    if (locales && typeof locales === 'object' && locales[code])
        return locales[code];
    return null;
}
async function loadLocale(code) {
    if (code === 'en') {
        setStrings(en);
        setLocaleSignal('en');
        return;
    }
    if (!cache[code]) {
        // Check boot-time inlined locales first (zero I/O)
        const inlined = getInlinedLocale(code);
        if (inlined) {
            cache[code] = inlined;
        }
        else {
            try {
                cache[code] = (await __variableDynamicImportRuntimeHelper((/* #__PURE__ */ Object.assign({"../locales/af.json": () => __vitePreload(() => import('./af-D0bOMiMr.js'),true              ?[]:void 0,import.meta.url),"../locales/ar.json": () => __vitePreload(() => import('./ar-0qTg9Atg.js'),true              ?[]:void 0,import.meta.url),"../locales/bg.json": () => __vitePreload(() => import('./bg-Bccp7FMF.js'),true              ?[]:void 0,import.meta.url),"../locales/bn.json": () => __vitePreload(() => import('./bn-B2y58mJm.js'),true              ?[]:void 0,import.meta.url),"../locales/ca.json": () => __vitePreload(() => import('./ca-CIrfb8UI.js'),true              ?[]:void 0,import.meta.url),"../locales/cs.json": () => __vitePreload(() => import('./cs-CIlPqLC1.js'),true              ?[]:void 0,import.meta.url),"../locales/da.json": () => __vitePreload(() => import('./da-BiWzoAlb.js'),true              ?[]:void 0,import.meta.url),"../locales/de.json": () => __vitePreload(() => import('./de-BYw8tcvK.js'),true              ?[]:void 0,import.meta.url),"../locales/el.json": () => __vitePreload(() => import('./el-BIc1xpn8.js'),true              ?[]:void 0,import.meta.url),"../locales/en.json": () => __vitePreload(() => Promise.resolve().then(() => en$1),true              ?void 0:void 0,import.meta.url),"../locales/es.json": () => __vitePreload(() => import('./es-B3eExmPS.js'),true              ?[]:void 0,import.meta.url),"../locales/fa.json": () => __vitePreload(() => import('./fa-DsWqSgXS.js'),true              ?[]:void 0,import.meta.url),"../locales/fi.json": () => __vitePreload(() => import('./fi-CkzmRrTJ.js'),true              ?[]:void 0,import.meta.url),"../locales/fr.json": () => __vitePreload(() => import('./fr-Bf6Fie-H.js'),true              ?[]:void 0,import.meta.url),"../locales/he.json": () => __vitePreload(() => import('./he-C4Nt_zcC.js'),true              ?[]:void 0,import.meta.url),"../locales/hi.json": () => __vitePreload(() => import('./hi-CKs5U5Ux.js'),true              ?[]:void 0,import.meta.url),"../locales/hu.json": () => __vitePreload(() => import('./hu-B2hkvHAp.js'),true              ?[]:void 0,import.meta.url),"../locales/id.json": () => __vitePreload(() => import('./id-C8PvgYBX.js'),true              ?[]:void 0,import.meta.url),"../locales/it.json": () => __vitePreload(() => import('./it-CtwCVPFo.js'),true              ?[]:void 0,import.meta.url),"../locales/ja.json": () => __vitePreload(() => import('./ja-D7sjgs0-.js'),true              ?[]:void 0,import.meta.url),"../locales/ko.json": () => __vitePreload(() => import('./ko-7-0MmnmP.js'),true              ?[]:void 0,import.meta.url),"../locales/nl.json": () => __vitePreload(() => import('./nl-zjw5OI9t.js'),true              ?[]:void 0,import.meta.url),"../locales/no.json": () => __vitePreload(() => import('./no-CDwz5af0.js'),true              ?[]:void 0,import.meta.url),"../locales/pl.json": () => __vitePreload(() => import('./pl-I8TW6R9C.js'),true              ?[]:void 0,import.meta.url),"../locales/pt-BR.json": () => __vitePreload(() => import('./pt-BR-BP5ZNjCR.js'),true              ?[]:void 0,import.meta.url),"../locales/pt-PT.json": () => __vitePreload(() => import('./pt-PT-L3J1gf3A.js'),true              ?[]:void 0,import.meta.url),"../locales/ro.json": () => __vitePreload(() => import('./ro-8fDCIXn5.js'),true              ?[]:void 0,import.meta.url),"../locales/ru.json": () => __vitePreload(() => import('./ru-CwUsRcGb.js'),true              ?[]:void 0,import.meta.url),"../locales/sr.json": () => __vitePreload(() => import('./sr-BESnMY_X.js'),true              ?[]:void 0,import.meta.url),"../locales/sv.json": () => __vitePreload(() => import('./sv-CKoIQdrZ.js'),true              ?[]:void 0,import.meta.url),"../locales/th.json": () => __vitePreload(() => import('./th-CqdcCd4o.js'),true              ?[]:void 0,import.meta.url),"../locales/tr.json": () => __vitePreload(() => import('./tr-Bd_2eJgZ.js'),true              ?[]:void 0,import.meta.url),"../locales/uk.json": () => __vitePreload(() => import('./uk-DGvPPzKP.js'),true              ?[]:void 0,import.meta.url),"../locales/vi.json": () => __vitePreload(() => import('./vi-CjtGXAkG.js'),true              ?[]:void 0,import.meta.url),"../locales/zh-CN.json": () => __vitePreload(() => import('./zh-CN-C1MxWSDT.js'),true              ?[]:void 0,import.meta.url),"../locales/zh-TW.json": () => __vitePreload(() => import('./zh-TW-JOViNfQR.js'),true              ?[]:void 0,import.meta.url)})), `../locales/${code}.json`, 3)).default;
            }
            catch {
                setStrings(en);
                setLocaleSignal('en');
                return;
            }
        }
    }
    setStrings({ ...en, ...cache[code] });
    setLocaleSignal(code);
}
function detectLocale(available) {
    const stored = localStorage.getItem('zeromount-language');
    if (stored && available.includes(stored))
        return stored;
    const hint = window.__ZM_LOCALE_CODE__;
    if (typeof hint === 'string' && available.includes(hint))
        return hint;
    const raw = navigator.language || 'en';
    if (available.includes(raw))
        return raw;
    const normalized = raw.replace(/_/g, '-');
    if (available.includes(normalized))
        return normalized;
    const lower = normalized.toLowerCase();
    if (lower.startsWith('zh-hans') || lower.startsWith('zh-cn')) {
        if (available.includes('zh-CN'))
            return 'zh-CN';
    }
    if (lower.startsWith('zh-hant') || lower.startsWith('zh-tw')) {
        if (available.includes('zh-TW'))
            return 'zh-TW';
    }
    const base = raw.split('-')[0];
    if (available.includes(base))
        return base;
    const partial = available.find(c => c.split('-')[0] === base);
    if (partial)
        return partial;
    return 'en';
}
const RTL_LOCALES = new Set(['ar', 'fa', 'he']);
const LANGUAGES = [
    { code: 'en', name: 'English' },
    { code: 'af', name: 'Afrikaans' },
    { code: 'ar', name: 'العربية' },
    { code: 'bg', name: 'Български' },
    { code: 'bn', name: 'বাংলা' },
    { code: 'ca', name: 'Català' },
    { code: 'cs', name: 'Čeština' },
    { code: 'da', name: 'Dansk' },
    { code: 'de', name: 'Deutsch' },
    { code: 'el', name: 'Ελληνικά' },
    { code: 'es', name: 'Español' },
    { code: 'fa', name: 'فارسی' },
    { code: 'fi', name: 'Suomi' },
    { code: 'fr', name: 'Français' },
    { code: 'he', name: 'עברית' },
    { code: 'hi', name: 'हिन्दी' },
    { code: 'hu', name: 'Magyar' },
    { code: 'id', name: 'Bahasa Indonesia' },
    { code: 'it', name: 'Italiano' },
    { code: 'ja', name: '日本語' },
    { code: 'ko', name: '한국어' },
    { code: 'nl', name: 'Nederlands' },
    { code: 'no', name: 'Norsk' },
    { code: 'pl', name: 'Polski' },
    { code: 'pt-BR', name: 'Português (BR)' },
    { code: 'pt-PT', name: 'Português (PT)' },
    { code: 'ro', name: 'Română' },
    { code: 'ru', name: 'Русский' },
    { code: 'sr', name: 'Српски' },
    { code: 'sv', name: 'Svenska' },
    { code: 'th', name: 'ไทย' },
    { code: 'tr', name: 'Türkçe' },
    { code: 'uk', name: 'Українська' },
    { code: 'vi', name: 'Tiếng Việt' },
    { code: 'zh-CN', name: '简体中文' },
    { code: 'zh-TW', name: '繁體中文' },
];

var _tmpl$$c = /*#__PURE__*/template(`<header class=header><h1 class=header__title></h1><span class=header__subtitle>`);
function Header() {
  return (() => {
    var _el$ = _tmpl$$c(),
      _el$2 = _el$.firstChild,
      _el$3 = _el$2.nextSibling;
    insert(_el$2, () => t('header.title'));
    insert(_el$3, () => t('header.subtitle'));
    return _el$;
  })();
}

const $RAW = Symbol("store-raw"),
  $NODE = Symbol("store-node"),
  $HAS = Symbol("store-has"),
  $SELF = Symbol("store-self");
function wrap$1(value) {
  let p = value[$PROXY];
  if (!p) {
    Object.defineProperty(value, $PROXY, {
      value: p = new Proxy(value, proxyTraps$1)
    });
    if (!Array.isArray(value)) {
      const keys = Object.keys(value),
        desc = Object.getOwnPropertyDescriptors(value),
        proto = Object.getPrototypeOf(value);
      const isClass = proto !== null && value !== null && typeof value === "object" && !Array.isArray(value) && proto !== Object.prototype;
      if (isClass) {
        const descriptors = Object.getOwnPropertyDescriptors(proto);
        keys.push(...Object.keys(descriptors));
        Object.assign(desc, descriptors);
      }
      for (let i = 0, l = keys.length; i < l; i++) {
        const prop = keys[i];
        if (isClass && prop === "constructor") continue;
        if (desc[prop].get) {
          Object.defineProperty(value, prop, {
            configurable: true,
            enumerable: desc[prop].enumerable,
            get: desc[prop].get.bind(p)
          });
        }
      }
    }
  }
  return p;
}
function isWrappable(obj) {
  let proto;
  return obj != null && typeof obj === "object" && (obj[$PROXY] || !(proto = Object.getPrototypeOf(obj)) || proto === Object.prototype || Array.isArray(obj));
}
function unwrap(item, set = new Set()) {
  let result, unwrapped, v, prop;
  if (result = item != null && item[$RAW]) return result;
  if (!isWrappable(item) || set.has(item)) return item;
  if (Array.isArray(item)) {
    if (Object.isFrozen(item)) item = item.slice(0);else set.add(item);
    for (let i = 0, l = item.length; i < l; i++) {
      v = item[i];
      if ((unwrapped = unwrap(v, set)) !== v) item[i] = unwrapped;
    }
  } else {
    if (Object.isFrozen(item)) item = Object.assign({}, item);else set.add(item);
    const keys = Object.keys(item),
      desc = Object.getOwnPropertyDescriptors(item);
    for (let i = 0, l = keys.length; i < l; i++) {
      prop = keys[i];
      if (desc[prop].get) continue;
      v = item[prop];
      if ((unwrapped = unwrap(v, set)) !== v) item[prop] = unwrapped;
    }
  }
  return item;
}
function getNodes(target, symbol) {
  let nodes = target[symbol];
  if (!nodes) Object.defineProperty(target, symbol, {
    value: nodes = Object.create(null)
  });
  return nodes;
}
function getNode(nodes, property, value) {
  if (nodes[property]) return nodes[property];
  const [s, set] = createSignal(value, {
    equals: false,
    internal: true
  });
  s.$ = set;
  return nodes[property] = s;
}
function proxyDescriptor$1(target, property) {
  const desc = Reflect.getOwnPropertyDescriptor(target, property);
  if (!desc || desc.get || !desc.configurable || property === $PROXY || property === $NODE) return desc;
  delete desc.value;
  delete desc.writable;
  desc.get = () => target[$PROXY][property];
  return desc;
}
function trackSelf(target) {
  getListener() && getNode(getNodes(target, $NODE), $SELF)();
}
function ownKeys(target) {
  trackSelf(target);
  return Reflect.ownKeys(target);
}
const proxyTraps$1 = {
  get(target, property, receiver) {
    if (property === $RAW) return target;
    if (property === $PROXY) return receiver;
    if (property === $TRACK) {
      trackSelf(target);
      return receiver;
    }
    const nodes = getNodes(target, $NODE);
    const tracked = nodes[property];
    let value = tracked ? tracked() : target[property];
    if (property === $NODE || property === $HAS || property === "__proto__") return value;
    if (!tracked) {
      const desc = Object.getOwnPropertyDescriptor(target, property);
      if (getListener() && (typeof value !== "function" || Object.prototype.hasOwnProperty.call(target, property)) && !(desc && desc.get)) value = getNode(nodes, property, value)();
    }
    return isWrappable(value) ? wrap$1(value) : value;
  },
  has(target, property) {
    if (property === $RAW || property === $PROXY || property === $TRACK || property === $NODE || property === $HAS || property === "__proto__") return true;
    getListener() && getNode(getNodes(target, $HAS), property)();
    return property in target;
  },
  set() {
    return true;
  },
  deleteProperty() {
    return true;
  },
  ownKeys: ownKeys,
  getOwnPropertyDescriptor: proxyDescriptor$1
};
function setProperty(state, property, value, deleting = false) {
  if (property === "__proto__") {
    return;
  }
  if (!deleting && state[property] === value) return;
  const prev = state[property],
    len = state.length;
  if (value === undefined) {
    delete state[property];
    if (state[$HAS] && state[$HAS][property] && prev !== undefined) state[$HAS][property].$();
  } else {
    state[property] = value;
    if (state[$HAS] && state[$HAS][property] && prev === undefined) state[$HAS][property].$();
  }
  let nodes = getNodes(state, $NODE),
    node;
  if (node = getNode(nodes, property, prev)) node.$(() => value);
  if (Array.isArray(state) && state.length !== len) {
    for (let i = state.length; i < len; i++) (node = nodes[i]) && node.$();
    (node = getNode(nodes, "length", len)) && node.$(state.length);
  }
  (node = nodes[$SELF]) && node.$();
}
function mergeStoreNode(state, value) {
  const keys = Object.keys(value);
  for (let i = 0; i < keys.length; i += 1) {
    const key = keys[i];
    if (isUnsafeKey$1(key)) continue;
    setProperty(state, key, value[key]);
  }
}
function isUnsafeKey$1(property) {
  return property === "__proto__" || property === "constructor" || property === "prototype";
}
function updateArray(current, next) {
  if (typeof next === "function") next = next(current);
  next = unwrap(next);
  if (Array.isArray(next)) {
    if (current === next) return;
    let i = 0,
      len = next.length;
    for (; i < len; i++) {
      const value = next[i];
      if (current[i] !== value) setProperty(current, i, value);
    }
    setProperty(current, "length", len);
  } else mergeStoreNode(current, next);
}
function updatePath(current, path, traversed = []) {
  let part,
    prev = current;
  if (path.length > 1) {
    part = path.shift();
    const partType = typeof part,
      isArray = Array.isArray(current);
    if (partType === "string" && (part === "__proto__" || path.length > 1 && isUnsafeKey$1(part))) {
      return;
    }
    if (Array.isArray(part)) {
      for (let i = 0; i < part.length; i++) {
        updatePath(current, [part[i]].concat(path), traversed);
      }
      return;
    } else if (isArray && partType === "function") {
      for (let i = 0; i < current.length; i++) {
        if (part(current[i], i)) updatePath(current, [i].concat(path), traversed);
      }
      return;
    } else if (isArray && partType === "object") {
      const {
        from = 0,
        to = current.length - 1,
        by = 1
      } = part;
      for (let i = from; i <= to; i += by) {
        updatePath(current, [i].concat(path), traversed);
      }
      return;
    } else if (path.length > 1) {
      updatePath(current[part], path, [part].concat(traversed));
      return;
    }
    prev = current[part];
    traversed = [part].concat(traversed);
  }
  let value = path[0];
  if (typeof value === "function") {
    value = value(prev, traversed);
    if (value === prev) return;
  }
  if (part === undefined && value == undefined) return;
  value = unwrap(value);
  if (part === undefined || isWrappable(prev) && isWrappable(value) && !Array.isArray(value)) {
    mergeStoreNode(prev, value);
  } else setProperty(current, part, value);
}
function createStore(...[store, options]) {
  const unwrappedStore = unwrap(store || {});
  const isArray = Array.isArray(unwrappedStore);
  const wrappedStore = wrap$1(unwrappedStore);
  function setStore(...args) {
    batch(() => {
      isArray && args.length === 1 ? updateArray(unwrappedStore, args[0]) : updatePath(unwrappedStore, args);
    });
  }
  return [wrappedStore, setStore];
}

/**
 * Source: https://github.com/KOWX712/kernelsu-alt
 * Npm: https://www.npmjs.com/package/kernelsu-alt
 * 
 * Imported from https://www.npmjs.com/package/kernelsu
 * Modified version by KOWX712
 */

let callbackCounter = 0;
function getUniqueCallbackName(prefix) {
    return `${prefix}_callback_${Date.now()}_${callbackCounter++}`;
}

/**
 * Check if KernelSU WebUI bridge is available
 * @returns {boolean} True if ksu object is available in the global scope
 */
function isKsuWebui() {
    return typeof globalThis.ksu !== 'undefined';
}

/**
 * Execute shell command with ksu.exec
 * @param {string} command - The command to execute
 * @param {Object} [options={}] - Options object containing:
 *   - cwd <string> - Current working directory of the child process
 *   - env {Object} - Environment key-value pairs
 * @returns {Promise<Object>} Resolves with:
 *   - errno {number} - Exit code of the command
 *   - stdout {string} - Standard output from the command
 *   - stderr {string} - Standard error from the command
 */
function exec(command, options = {}) {
    return new Promise((resolve, reject) => {
        const callbackFuncName = getUniqueCallbackName("exec");
        window[callbackFuncName] = (errno, stdout, stderr) => {
            resolve({ errno, stdout, stderr });
            cleanup(callbackFuncName);
        };
        function cleanup(successName) {
            delete window[successName];
        }
        try {
            if (isKsuWebui()) {
                ksu.exec(command, JSON.stringify(options), callbackFuncName);
            } else {
                resolve({ errno: 1, stdout: "", stderr: "ksu is not defined" });
            }
        } catch (error) {
            reject(error);
            cleanup(callbackFuncName);
        }
    });
}

/**
 * Standard I/O stream for a child process.
 * @class
 */
class Stdio {
    constructor() {
        this.listeners = {};
    }
    on(event, listener) {
        if (!this.listeners[event]) {
            this.listeners[event] = [];
        }
        this.listeners[event].push(listener);
    }
    emit(event, ...args) {
        if (this.listeners[event]) {
            this.listeners[event].forEach(listener => listener(...args));
        }
    }
}

/**
 * Spawn shell process with ksu.spawn
 * @param {string} command - The command to execute
 * @param {string[]} [args=[]] - Array of arguments to pass to the command
 * @param {Object} [options={}] - Options object containing:
 *   - cwd <string> - Current working directory of the child process
 *   - env {Object} - Environment key-value pairs
 * @returns {Object} A child process object with:
 *   - stdout: Stream for standard output
 *   - stderr: Stream for standard error
 *   - stdin: Stream for standard input
 *   - on(event, listener): Attach event listener ('exit', 'error')
 *   - emit(event, ...args): Emit events internally
 */
function spawn(command, args = [], options = {}) {
    const child = {
        listeners: {},
        stdout: new Stdio(),
        stderr: new Stdio(),
        stdin: new Stdio(),
        on(event, listener) {
            if (!this.listeners[event]) this.listeners[event] = [];
            this.listeners[event].push(listener);
        },
        emit(event, ...args) {
            if (this.listeners[event]) {
                this.listeners[event].forEach(listener => listener(...args));
            }
        }
    };
    const callbackName = getUniqueCallbackName("spawn");
    window[callbackName] = child;
    child.on("exit", () => delete window[callbackName]);
    try {
        if (isKsuWebui()) {
            ksu.spawn(command, JSON.stringify(args), JSON.stringify(options), callbackName);
        } else {
            setTimeout(() => {
                child.stderr.emit("data", "ksu is not defined");
                child.emit("exit", 1);
            }, 0);
        }
    } catch (error) {
        child.emit("error", error);
        delete window[callbackName];
    }
    return child;
}

/**
 * Supported since KernelSU v2.1.1-14 (22082)
 * Supported since APatch 11159
 * Fallback to pm list packages when unsupported
 * 
 * List installed packages
 * @param {string} [type="all"] - The type of packages to list: "user", "system", or "all".
 * @returns {Promise<string[]>} A promise that resolves to an array of package names.
 */
async function listPackages$1(type) {
    if (typeof globalThis.ksu?.listPackages === 'function') {
        try {
            return JSON.parse(ksu.listPackages(type));
        } catch (error) {
            // Fallback to pm list package
        }
    }

    return new Promise((resolve, reject) => {
        const pmArgs = {
            all: [],
            user: ['-3'],
            system: ['-s'],
        };

        if (!(type in pmArgs)) {
            return reject(new Error(`Unknown listPackages type: ${type}`));
        }

        let pkgs = [];
        let stderr = '';

        const pm = spawn('pm', ['list', 'packages', ...pmArgs[type]]);
        pm.stdout.on('data', (data) => {
            if (data.trim() !== '') {
                pkgs.push(data.trim().replace(/^package:/, ''));
            }
        });
        pm.stderr.on('data', (data) => (stderr += data));
        pm.on('exit', (code) => {
            if (code !== 0) {
                return reject(new Error(`pm process exited with code ${code}: ${stderr.trim()}`));
            }
            resolve(pkgs);
        });
        pm.on('error', (error) => {
            reject(error);
        });
    });
}

/**
 * @typedef {object} PackagesInfo
 * @property {string} packageName - Package name of the application.
 * @property {string} versionName - Version of the application.
 * @property {number} versionCode - Version code of the application.
 * @property {string} appLabel - Display name of the application.
 * @property {boolean} isSystem - Whether the application is a system app.
 * @property {number} uid - UID of the application.
 */

/**
 * Supported since KernelSU v2.1.1-14 (22082)
 * Supported since APatch 11159
 * 
 * Retrieves detailed information for one or more packages.
 * @param {string|string[]} pkg - A single package name or an array of package names.
 * @returns {Promise<PackagesInfo|PackagesInfo[]>} Resolves with:
 *   - a single package information object if one package is provided
 *   - {}
 *   - an array of package information objects if multiple packages are provided
 *   - [{},{}]
 */
function getPackagesInfo$1(pkg) {
    return new Promise((resolve, reject) => {
        if (!pkg) {
            return resolve([]);
        }

        if (typeof globalThis.ksu?.getPackagesInfo !== 'function') {
            return reject(new Error("ksu.getPackagesInfo is not available."));
        }

        const pkgs = Array.isArray(pkg) ? pkg : [pkg];
        if (pkgs.length === 0) {
            return resolve([]);
        }

        try {
            const infoJson = ksu.getPackagesInfo(JSON.stringify(pkgs));
            const result = JSON.parse(infoJson);
            
            if (!Array.isArray(pkg) && result.length === 1) {
                resolve(result[0]);
            } else {
                resolve(result);
            }
        } catch (error) {
            reject(new Error(`Failed to get package info: ${error.message}`));
        }
    });
}

const VALID_PACKAGE_RE = /^[a-zA-Z][a-zA-Z0-9_.]*$/;
function isValidPackageName(name) {
    return VALID_PACKAGE_RE.test(name) && name.length <= 256;
}
function isRealEnvironment() {
    return typeof ksu !== 'undefined';
}
function runShell(command) {
    if (!isRealEnvironment())
        return Promise.resolve({ errno: -1, stdout: '', stderr: 'KSU not available' });
    return exec(command);
}
async function listPackages(type) {
    if (!isRealEnvironment())
        return [];
    try {
        const result = await listPackages$1(type);
        if (Array.isArray(result) && result.length > 0)
            return result;
    }
    catch { }
    const pmFlags = { all: '', user: '-3', system: '-s' };
    const { stdout, errno } = await runShell(`pm list packages ${pmFlags[type]} | sed 's/package://'`);
    if (errno === 0 && stdout.trim()) {
        return stdout.trim().split('\n').filter(Boolean);
    }
    return [];
}
async function getPackagesInfo(packageNames) {
    if (!packageNames.length)
        return [];
    if (isRealEnvironment()) {
        try {
            const result = await getPackagesInfo$1(packageNames);
            if (Array.isArray(result) && result.length > 0)
                return result;
        }
        catch { }
    }
    const valid = packageNames.filter(isValidPackageName);
    const invalid = packageNames.filter(p => !isValidPackageName(p));
    const results = invalid.map(packageName => ({
        packageName, appLabel: packageName, versionName: '', versionCode: 0, isSystem: false, uid: -1,
    }));
    if (valid.length > 0) {
        const script = valid.map(pkg => `label=$(pm path ${pkg} 2>/dev/null | head -1 | sed 's/package://' | xargs -I{} aapt dump badging {} 2>/dev/null | grep "application-label:" | head -1 | sed "s/application-label:'\\(.*\\)'/\\1/"); printf '%s\\t%s\\n' ${pkg} "\${label:-}"`).join('\n');
        const { stdout } = await runShell(script);
        const lines = stdout.trim().split('\n').filter(Boolean);
        const labelMap = new Map(lines.map(l => { const [pkg, ...rest] = l.split('\t'); return [pkg, rest.join('\t')]; }));
        for (const packageName of valid) {
            const appLabel = labelMap.get(packageName)?.trim() || packageName;
            results.push({ packageName, appLabel, versionName: '', versionCode: 0, isSystem: false, uid: -1 });
        }
    }
    return results;
}
async function ksuWriteFile(content, path) {
    const escaped = content.replace(/'/g, "'\\''");
    return runShell(`printf '%s' '${escaped}' > '${path}'`);
}
async function getAppLabelViaAapt(packageName) {
    if (!isValidPackageName(packageName))
        return null;
    const { stdout, errno } = await runShell(`pm path ${packageName} 2>/dev/null | head -1 | sed 's/package://' | xargs -I{} aapt dump badging {} 2>/dev/null | grep "application-label:" | head -1 | sed "s/application-label:'\\(.*\\)'/\\1/"`);
    return errno === 0 && stdout.trim() ? stdout.trim() : null;
}

const MODULE_ID_RE$1 = /^[a-zA-Z][a-zA-Z0-9._-]+$/;
const MODULE_ID = (() => {
    try {
        const id = globalThis.ksu?.moduleInfo?.();
        if (id && MODULE_ID_RE$1.test(id))
            return id;
    }
    catch { }
    return 'meta-zeromount';
})();
const PATHS = {
    BINARY: `/data/adb/modules/${MODULE_ID}/bin/zm`,
    DATA_DIR: '/data/adb/zeromount/',
    MODULE_PATHS: '/data/adb/zeromount/module_paths',
    EXCLUSION_FILE: '/data/adb/zeromount/.exclusion_list',
    EXCLUSION_META: '/data/adb/zeromount/.exclusion_meta.json',
    ACTIVITY_LOG: '/data/adb/zeromount/activity.log',
    VERBOSE_FLAG: '/data/adb/zeromount/.verbose',
};
const GITHUB_URL = 'https://github.com/Enginex0/zeromount';
const APP_VERSION = '2.0.216-dev.guard5.brene67';

function escapeShellArg(arg) {
    return "'" + arg.replace(/'/g, "'\\''") + "'";
}
function withTimeout(p, ms) {
    return Promise.race([p, new Promise((_, rej) => setTimeout(() => rej(new Error('timeout')), ms))]);
}
function shouldUseMock() {
    return false;
}
// --- In-memory TTL cache for webui-init data (Layer 1) ---
const CACHE_PATH = PATHS.BINARY.replace(/\/bin\/zm$/, '/webroot/cache.json');
let _cacheData = null;
let _cacheTs = 0;
const CACHE_TTL = 5000;
async function readFromCache() {
    // Hot path: in-memory TTL cache
    if (_cacheData && Date.now() - _cacheTs < CACHE_TTL)
        return _cacheData;
    const inlined = window.__ZM_CACHE__;
    if (inlined && typeof inlined === 'object') {
        _cacheData = inlined;
        _cacheTs = Date.now();
        window.__ZM_CACHE__ = null;
        return _cacheData;
    }
    try {
        const { errno, stdout } = await runShell(`cat '${CACHE_PATH}'`);
        if (errno !== 0 || !stdout.trim())
            return null;
        _cacheData = JSON.parse(stdout);
        _cacheTs = Date.now();
        return _cacheData;
    }
    catch {
        return null;
    }
}
function invalidateCache() {
    _cacheData = null;
    _cacheTs = 0;
    window.__ZM_CACHE__ = null;
}
Promise.resolve();
function parseRulesOutput(stdout) {
    const lines = stdout.trim().split('\n').filter(line => line.trim());
    // Kernel outputs: real_path->virtual_path (zeromount-core.patch:1021)
    // source = real_path (module file providing content)
    // target = virtual_path (system path where it appears)
    const rules = lines.map((line, index) => {
        const idx = line.indexOf('->');
        const source = idx === -1 ? line.trim() : line.slice(0, idx).trim();
        const target = idx === -1 ? t('rules.blocked') : line.slice(idx + 2).trim();
        return {
            id: String(index + 1),
            name: target.split('/').pop() || t('rules.defaultName'),
            source,
            target,
            createdAt: new Date(),
        };
    });
    return rules;
}
// Serialize EXCLUSION_META read-modify-write to prevent concurrent overwrites
let metaMutex = Promise.resolve();
function withMetaLock(fn) {
    const prev = metaMutex;
    let resolve;
    metaMutex = new Promise(r => { resolve = r; });
    return prev.then(fn).finally(() => resolve());
}
async function parseExclusionFiles() {
    try {
        const { errno: listErr, stdout: listOut } = await runShell(`cat "${PATHS.EXCLUSION_FILE}"`);
        if (listErr !== 0 || !listOut.trim()) {
            return [];
        }
        const uids = listOut.trim().split('\n').map(line => parseInt(line.trim(), 10)).filter(uid => !isNaN(uid));
        let meta = {};
        try {
            const { errno: metaErr, stdout: metaOut } = await runShell(`cat "${PATHS.EXCLUSION_META}"`);
            if (metaErr === 0 && metaOut.trim()) {
                meta = JSON.parse(metaOut);
            }
        }
        catch (e) {
            // Meta file optional
        }
        const result = uids.map(uid => {
            const info = meta[String(uid)];
            return {
                uid,
                packageName: info?.packageName || t('exclusion.fallbackPackage', { uid }),
                appName: info?.appName || t('exclusion.fallbackName', { uid }),
                excludedAt: info?.excludedAt ? new Date(info.excludedAt) : new Date(),
            };
        });
        return result;
    }
    catch (e) {
        return [];
    }
}
async function parseActivityLog() {
    try {
        const { errno, stdout } = await runShell(`tail -10 "${PATHS.ACTIVITY_LOG}"`);
        if (errno !== 0 || !stdout.trim()) {
            return [];
        }
        const validTypes = ['rule_added', 'rule_removed', 'uid_excluded', 'uid_included', 'engine_enabled', 'engine_disabled', 'setting_changed', 'mount_strategy_changed', 'susfs_toggle', 'brene_toggle', 'theme_changed'];
        const lines = stdout.trim().split('\n').filter(line => line.trim());
        const items = [];
        for (let i = 0; i < lines.length; i++) {
            const match = lines[i].match(/^\[(.+?)\]\s+(\w+):\s+(.+)$/);
            if (!match)
                continue;
            const [, timestamp, type, message] = match;
            const parsed = new Date(timestamp);
            if (isNaN(parsed.getTime()))
                continue;
            const normalizedType = type.toLowerCase();
            items.push({
                id: String(i + 1),
                type: (validTypes.includes(normalizedType) ? normalizedType : 'engine_enabled'),
                message,
                timestamp: parsed,
            });
        }
        items.sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());
        return items.slice(0, 10);
    }
    catch (e) {
        return [];
    }
}
async function logActivity(type, message) {
    try {
        const timestamp = new Date().toISOString();
        const line = `[${timestamp}] ${type.toUpperCase()}: ${message}`;
        await runShell(`echo ${escapeShellArg(line)} >> "${PATHS.ACTIVITY_LOG}"`);
    }
    catch (e) {
    }
}
function syncDescription() {
    runShell(`${PATHS.BINARY} sync-description`).catch(() => { });
}
const api = {
    async getVersion() {
        try {
            const { errno, stdout } = await runShell(`${PATHS.BINARY} version`);
            if (errno === 0 && stdout) {
                return stdout.trim();
            }
        }
        catch (e) {
            // Fallback
        }
        return `v${APP_VERSION}`;
    },
    async getSystemInfo() {
        const info = {
            driverVersion: `v${APP_VERSION}`,
            kernelVersion: '-',
            susfsVersion: '-',
            uptime: '-',
            deviceModel: '-',
            androidVersion: '-',
            selinuxStatus: '-',
        };
        try {
            const [verRes, kernRes, uptimeRes, modelRes, androidRes, selinuxRes, susfsRes] = await Promise.all([
                runShell(`${PATHS.BINARY} version`).catch(() => ({ errno: 1, stdout: '', stderr: '' })),
                runShell('uname -r').catch(() => ({ errno: 1, stdout: '', stderr: '' })),
                runShell('cat /proc/uptime').catch(() => ({ errno: 1, stdout: '', stderr: '' })),
                runShell('getprop ro.product.model').catch(() => ({ errno: 1, stdout: '', stderr: '' })),
                runShell('getprop ro.build.version.release').catch(() => ({ errno: 1, stdout: '', stderr: '' })),
                runShell('getenforce').catch(() => ({ errno: 1, stdout: '', stderr: '' })),
                runShell('ksu_susfs show version 2>/dev/null || echo ""').catch(() => ({ errno: 1, stdout: '', stderr: '' })),
            ]);
            if (verRes.errno === 0 && verRes.stdout) {
                info.driverVersion = verRes.stdout.trim();
            }
            if (kernRes.errno === 0 && kernRes.stdout) {
                info.kernelVersion = kernRes.stdout.trim();
            }
            if (uptimeRes.errno === 0 && uptimeRes.stdout) {
                const seconds = parseInt(uptimeRes.stdout.split(' ')[0], 10);
                if (!isNaN(seconds)) {
                    const hours = Math.floor(seconds / 3600);
                    const mins = Math.floor((seconds % 3600) / 60);
                    info.uptime = `${hours}h ${mins}m`;
                }
            }
            if (modelRes.errno === 0 && modelRes.stdout.trim()) {
                info.deviceModel = modelRes.stdout.trim();
            }
            if (androidRes.errno === 0 && androidRes.stdout.trim()) {
                info.androidVersion = androidRes.stdout.trim();
            }
            if (selinuxRes.errno === 0 && selinuxRes.stdout.trim()) {
                info.selinuxStatus = selinuxRes.stdout.trim();
            }
            if (susfsRes.errno === 0 && susfsRes.stdout.trim()) {
                info.susfsVersion = susfsRes.stdout.trim();
            }
        }
        catch (e) {
        }
        return info;
    },
    async getSystemInfoBatched() {
        const info = {
            driverVersion: `v${APP_VERSION}`,
            kernelVersion: '-',
            susfsVersion: '-',
            uptime: '-',
            deviceModel: '-',
            androidVersion: '-',
            selinuxStatus: '-',
        };
        try {
            const { errno, stdout } = await runShell([
                `${PATHS.BINARY} version 2>/dev/null || echo ''`,
                'uname -r',
                'cat /proc/uptime',
                'getprop ro.product.model',
                'getprop ro.build.version.release',
                'getenforce 2>/dev/null || echo Permissive',
                "ksu_susfs show version 2>/dev/null || echo ''",
            ].map(c => `echo "$(${c})"`).join(' && echo "---DELIM---" && '));
            if (errno === 0 && stdout) {
                const parts = stdout.split('---DELIM---').map(s => s.trim());
                if (parts[0])
                    info.driverVersion = parts[0];
                if (parts[1])
                    info.kernelVersion = parts[1];
                if (parts[2]) {
                    const seconds = parseInt(parts[2].split(' ')[0], 10);
                    if (!isNaN(seconds)) {
                        const hours = Math.floor(seconds / 3600);
                        const mins = Math.floor((seconds % 3600) / 60);
                        info.uptime = `${hours}h ${mins}m`;
                    }
                }
                if (parts[3])
                    info.deviceModel = parts[3];
                if (parts[4])
                    info.androidVersion = parts[4];
                if (parts[5])
                    info.selinuxStatus = parts[5];
                if (parts[6])
                    info.susfsVersion = parts[6];
            }
        }
        catch (e) {
        }
        return info;
    },
    async getRules() {
        try {
            const { errno, stdout } = await runShell(`${PATHS.BINARY} vfs list`);
            if (errno === 0 && stdout.trim()) {
                return parseRulesOutput(stdout);
            }
        }
        catch (e) {
            // Fallback
        }
        return [];
    },
    async clearAllRules() {
        const cmd = `${PATHS.BINARY} vfs clear`;
        const { errno, stderr } = await runShell(cmd);
        if (errno !== 0) {
            throw new Error(stderr || 'Failed to clear rules');
        }
        syncDescription();
    },
    async getExcludedUids() {
        return parseExclusionFiles();
    },
    async excludeUid(uid, packageName, appName) {
        // Validation FIRST
        if (!Number.isInteger(uid) || uid < 0)
            throw new Error('Invalid UID');
        const cmd = `${PATHS.BINARY} uid block ${escapeShellArg(String(uid))}`;
        const { errno, stderr } = await runShell(cmd);
        if (errno !== 0) {
            throw new Error(stderr || 'Failed to exclude UID');
        }
        await runShell(`echo ${escapeShellArg(String(uid))} >> "${PATHS.EXCLUSION_FILE}"`).catch(() => { });
        await withMetaLock(async () => {
            try {
                let meta = {};
                const { errno: metaErr, stdout: metaOut } = await runShell(`cat "${PATHS.EXCLUSION_META}" 2>/dev/null`);
                if (metaErr === 0 && metaOut.trim()) {
                    try {
                        meta = JSON.parse(metaOut);
                    }
                    catch (parseErr) {
                        meta = {};
                    }
                }
                meta[String(uid)] = { packageName, appName, excludedAt: new Date().toISOString() };
                await runShell(`echo ${escapeShellArg(JSON.stringify(meta))} > "${PATHS.EXCLUSION_META}"`);
            }
            catch (e) {
            }
        });
        return {
            uid,
            packageName,
            appName,
            excludedAt: new Date(),
        };
    },
    async includeUid(uid) {
        const cmd = `${PATHS.BINARY} uid unblock ${escapeShellArg(String(uid))}`;
        const { errno, stderr } = await runShell(cmd);
        if (errno !== 0) {
            throw new Error(stderr || 'Failed to include UID');
        }
        if (!/^\d+$/.test(String(uid)))
            throw new Error('invalid uid');
        await runShell(`sed -i '/^${uid}$/d' "${PATHS.EXCLUSION_FILE}"`).catch(() => { });
        await withMetaLock(async () => {
            try {
                const { errno: metaErr, stdout: metaOut } = await runShell(`cat "${PATHS.EXCLUSION_META}" 2>/dev/null`);
                if (metaErr === 0 && metaOut.trim()) {
                    try {
                        const meta = JSON.parse(metaOut);
                        delete meta[String(uid)];
                        await runShell(`echo ${escapeShellArg(JSON.stringify(meta))} > "${PATHS.EXCLUSION_META}"`);
                    }
                    catch (parseErr) {
                    }
                }
            }
            catch (e) {
            }
        });
    },
    async getActivity() {
        return parseActivityLog();
    },
    async getStats() {
        const [rules, uids] = await Promise.all([
            this.getRules(),
            this.getExcludedUids(),
        ]);
        return {
            activeRules: rules.length,
            excludedUids: uids.length,
            hiddenPaths: 0,
            hiddenMaps: 0,
        };
    },
    async toggleEngine(enable) {
        const cmd = enable ? `${PATHS.BINARY} vfs enable` : `${PATHS.BINARY} vfs disable`;
        const { errno, stderr } = await runShell(cmd);
        if (errno !== 0) {
            throw new Error(stderr || 'Failed to toggle engine');
        }
    },
    async setVerboseLogging(enabled) {
        const subcmd = enabled ? 'enable' : 'disable';
        const cmd = `${PATHS.BINARY} log ${subcmd}`;
        const { errno, stderr } = await runShell(cmd);
        if (errno !== 0) {
            throw new Error(stderr || 'Failed to set verbose logging');
        }
    },
    async reboot() {
        await runShell('svc power reboot');
    },
    async getVerboseLogging() {
        const cmd = `${PATHS.BINARY} config get logging.verbose`;
        const { errno, stdout } = await runShell(cmd);
        if (errno !== 0) {
            return false;
        }
        return stdout.trim() === 'true';
    },
    async getVerboseDumpPath() {
        try {
            const { errno, stdout } = await runShell(`cat /data/adb/zeromount/.dump_path 2>/dev/null`);
            if (errno === 0 && stdout.trim())
                return stdout.trim();
        }
        catch (e) {
        }
        return null;
    },
    async getInstalledApps() {
        return [];
    },
    // Check if daemon has signaled a refresh (returns trigger timestamp or null)
    async getRefreshTrigger() {
        try {
            const response = await fetch('link/.refresh_trigger?t=' + Date.now());
            if (response.ok) {
                const text = await response.text();
                const timestamp = parseInt(text.trim(), 10);
                if (!isNaN(timestamp)) {
                    return timestamp;
                }
            }
        }
        catch (e) {
            // Trigger file doesn't exist yet
        }
        return null;
    },
    async scanKsuModules() {
        try {
            // Single shell call that outputs JSON - replaces ~22 separate exec calls
            const script = `
# Extract unique module base paths from zm list (format: system_path->module_file_path)
loaded_modules=$(${PATHS.BINARY} vfs list 2>/dev/null | awk -F'->' '{print $2}' | grep -oE '/data/adb/modules/[^/]+' | sort -u || echo "")
echo "["
first=1
for dir in /data/adb/modules/*/; do
  [ -d "$dir" ] || continue
  name=$(basename "$dir")
  path="/data/adb/modules/$name"

  has_sys=0; has_ven=0; has_prod=0
  [ -d "$path/system" ] && has_sys=1
  [ -d "$path/vendor" ] && has_ven=1
  [ -d "$path/product" ] && has_prod=1

  [ $has_sys -eq 0 ] && [ $has_ven -eq 0 ] && [ $has_prod -eq 0 ] && continue

  count=$(find "$path" \\( -type f -o -type c \\) \\( -path "*/system/*" -o -path "*/vendor/*" -o -path "*/product/*" \\) 2>/dev/null | wc -l)

  display_name="$name"
  if [ -f "$path/module.prop" ]; then
    prop_name=$(grep "^name=" "$path/module.prop" 2>/dev/null | cut -d= -f2)
    [ -n "$prop_name" ] && display_name="$prop_name"
  fi

  is_loaded=0
  echo "$loaded_modules" | grep -qx "$path" && is_loaded=1

  [ $first -eq 0 ] && echo ","
  first=0
  printf '{"name":"%s","path":"%s","hasSystem":%s,"hasVendor":%s,"hasProduct":%s,"isLoaded":%s,"fileCount":%d}' \\
    "$display_name" "$path" \\
    $([ $has_sys -eq 1 ] && echo true || echo false) \\
    $([ $has_ven -eq 1 ] && echo true || echo false) \\
    $([ $has_prod -eq 1 ] && echo true || echo false) \\
    $([ $is_loaded -eq 1 ] && echo true || echo false) \\
    "$count"
done
echo "]"
`;
            const { errno, stdout } = await runShell(script);
            if (errno !== 0) {
                return [];
            }
            // Filesystem corruption can produce duplicate directory entries (same path).
            // Dedup by path to avoid showing the same module twice.
            const raw = JSON.parse(stdout.trim());
            const seen = new Set();
            const modules = raw.filter(m => {
                if (seen.has(m.path))
                    return false;
                seen.add(m.path);
                return true;
            });
            return modules;
        }
        catch (e) {
            return [];
        }
    },
    async loadKsuModule(moduleName, modulePath) {
        try {
            const { stdout } = await runShell(`find ${escapeShellArg(modulePath)} \\( -type f -o -type c \\) \\( -path "*/system/*" -o -path "*/vendor/*" -o -path "*/product/*" \\) 2>/dev/null`);
            const files = stdout.trim().split('\n').filter(Boolean);
            const cmds = files.flatMap(filePath => {
                const rel = filePath.replace(modulePath, '');
                if (!rel.startsWith('/system/') && !rel.startsWith('/vendor/') && !rel.startsWith('/product/'))
                    return [];
                return [`${PATHS.BINARY} vfs add ${escapeShellArg(rel)} ${escapeShellArg(filePath)} && echo OK || echo FAIL`];
            });
            let addedCount = 0;
            if (cmds.length > 0) {
                const { stdout: batchOut } = await runShell(cmds.join('\n'));
                addedCount = (batchOut.match(/\bOK\b/g) ?? []).length;
            }
            await logActivity('MODULE_LOADED', `${moduleName}: ${addedCount} rules added`);
            syncDescription();
            return addedCount;
        }
        catch (e) {
            throw e;
        }
    },
    async unloadKsuModule(moduleName, modulePath) {
        const moduleId = modulePath.split('/').pop() || '';
        const { errno, stdout } = await runShell(`${PATHS.BINARY} module unload ${escapeShellArg(moduleId)}`);
        if (errno !== 0) {
            throw new Error(stdout || 'Failed to unload module');
        }
        let removed = 0;
        try {
            const result = JSON.parse(stdout.trim());
            if (result.error)
                throw new Error(result.error);
            removed = result.removed || 0;
        }
        catch (e) {
            if (e instanceof SyntaxError)
                throw new Error(stdout || 'Unexpected response');
            throw e;
        }
        await logActivity('MODULE_UNLOADED', `${moduleName}: ${removed} mounts removed`);
        syncDescription();
        return removed;
    },
    async fetchSystemColor() {
        // Check boot-time inlined accent color first (zero exec)
        const inlined = window.__ZM_ACCENT__;
        if (typeof inlined === 'string' && inlined)
            return inlined;
        try {
            const { errno, stdout } = await runShell('settings get secure theme_customization_overlay_packages');
            if (errno !== 0 || !stdout.trim())
                return null;
            const match = /#?([0-9a-fA-F]{6,8})/i.exec(stdout);
            if (match)
                return '#' + match[1].slice(0, 6);
            return null;
        }
        catch (e) {
            return null;
        }
    },
    async getRuntimeStatus() {
        try {
            const { errno, stdout } = await withTimeout(runShell(`${PATHS.BINARY} status --json`), 5000);
            if (errno === 0 && stdout.trim()) {
                return JSON.parse(stdout.trim());
            }
        }
        catch (e) {
        }
        return null;
    },
    async configDump() {
        try {
            const { errno, stdout } = await runShell(`${PATHS.BINARY} config dump --json`);
            if (errno === 0 && stdout.trim()) {
                return JSON.parse(stdout.trim());
            }
        }
        catch (e) {
        }
        return null;
    },
    async configGet(key) {
        try {
            const { errno, stdout } = await runShell(`${PATHS.BINARY} config get ${escapeShellArg(key)}`);
            if (errno === 0 && stdout.trim()) {
                return stdout.trim();
            }
        }
        catch (e) {
        }
        return null;
    },
    async configSet(key, value) {
        const { errno, stderr } = await runShell(`${PATHS.BINARY} config set ${escapeShellArg(key)} ${escapeShellArg(value)}`);
        if (errno !== 0) {
            throw new Error(stderr || `Failed to set config: ${key}`);
        }
    },
    async liveBrene(key, enabled) {
        const { errno, stderr } = await runShell(`${PATHS.BINARY} live-brene ${escapeShellArg(key)} ${enabled ? 'true' : 'false'}`);
        if (errno !== 0) throw new Error(stderr || 'BRENE-Schreibaktion fehlgeschlagen');
    },
    async setSusfsAvcSpoofing(enabled) { await this.liveBrene('avc_log_spoofing', enabled); },
    async logActivity(type, message) { return logActivity(type, message); },
    async setSusfsLog(enabled) { await this.liveBrene('susfs_log', enabled); },
    async setSusfsHideMounts(enabled) { await this.liveBrene('hide_sus_mounts', enabled); },
    async setKernelFeature(feature, enabled) {
        const key = {su_compat:'sync_su_compat',selinux_hide:'sync_selinux_hide',kernel_umount:'kernel_umount'}[feature];
        if (!key) throw new Error('Unsupported feature');
        await this.liveBrene(key, enabled);
    },
    async writeSusfsConfigVar(key, value) {
        const configPath = '/data/adb/susfs4ksu/config.sh';
        await runShell(`sed -i 's/^${escapeShellArg(key)}=.*/${escapeShellArg(key)}=${escapeShellArg(value)}/' ${escapeShellArg(configPath)}`);
    },
    async bridgeWrite(_key, _value) {
        await runShell(`${PATHS.BINARY} bridge write`);
    },
    async readSusfsConfigVar(key, basePath = '/data/adb/susfs4ksu/config.sh') {
        try {
            const { errno, stdout } = await runShell(`grep -m1 '^${escapeShellArg(key)}=' ${escapeShellArg(basePath)} | cut -d= -f2`);
            if (errno === 0 && stdout.trim())
                return stdout.trim();
        }
        catch (e) {
        }
        return null;
    },
    async readAllBridgeValues(basePath) {
        try {
            const { errno, stdout } = await runShell(`grep -E '^[a-zA-Z_]+=.' ${escapeShellArg(basePath)} 2>/dev/null`);
            if (errno !== 0 || !stdout.trim())
                return {};
            const result = {};
            for (const line of stdout.trim().split('\n')) {
                const eq = line.indexOf('=');
                if (eq === -1)
                    continue;
                result[line.slice(0, eq)] = line.slice(eq + 1);
            }
            return result;
        }
        catch (e) {
            console.error('[ZM-API] readAllBridgeValues() error:', e);
            return {};
        }
    },
    async webuiInit() {
        try {
            const { errno, stdout } = await withTimeout(runShell(`${PATHS.BINARY} webui-init`), 10000);
            if (errno === 0 && stdout.trim()) {
                return JSON.parse(stdout.trim());
            }
        }
        catch (e) {
        }
        return null;
    },
};

const accentPresets = {
    '#FF8E53': {
        gradient: 'linear-gradient(135deg, #FF8E53 0%, #FF7B3D 50%, #E85D04 100%)',
        textAccent: '#FF8E53',
        rgb: '255, 142, 83',
        textOnAccent: '#1A1A2E',
    },
    '#00D68F': {
        gradient: 'linear-gradient(135deg, #00D68F 0%, #00E5A0 50%, #69F0AE 100%)',
        textAccent: '#00D68F',
        rgb: '0, 214, 143',
        textOnAccent: '#1A1A2E',
    },
    '#D4A574': {
        gradient: 'linear-gradient(135deg, #D4A574 0%, #DEB887 50%, #F0D9B5 100%)',
        textAccent: '#DEB887',
        rgb: '212, 165, 116',
        textOnAccent: '#1A1A2E',
    },
    '#A855F7': {
        gradient: 'linear-gradient(135deg, #A855F7 0%, #C084FC 50%, #DDD6FE 100%)',
        textAccent: '#C084FC',
        rgb: '168, 85, 247',
        textOnAccent: '#FFFFFF',
    },
    '#D946EF': {
        gradient: 'linear-gradient(135deg, #D946EF 0%, #E879F9 50%, #F0ABFC 100%)',
        textAccent: '#E879F9',
        rgb: '217, 70, 239',
        textOnAccent: '#FFFFFF',
    },
    '#84CC16': {
        gradient: 'linear-gradient(135deg, #84CC16 0%, #A3E635 50%, #BEF264 100%)',
        textAccent: '#A3E635',
        rgb: '132, 204, 22',
        textOnAccent: '#1A1A2E',
    },
    '#6366F1': {
        gradient: 'linear-gradient(135deg, #6366F1 0%, #818CF8 50%, #A5B4FC 100%)',
        textAccent: '#818CF8',
        rgb: '99, 102, 241',
        textOnAccent: '#FFFFFF',
    },
    '#FF6B6B': {
        gradient: 'linear-gradient(135deg, #FF6B6B 0%, #FF8A80 50%, #FFAB91 100%)',
        textAccent: '#FF6B6B',
        rgb: '255, 107, 107',
        textOnAccent: '#1A1A2E',
    },
};
const accentNames = {
    '#FF8E53': 'Orange',
    '#00D68F': 'Emerald',
    '#D4A574': 'Beige',
    '#A855F7': 'Amethyst',
    '#D946EF': 'Fuchsia',
    '#84CC16': 'Lime',
    '#6366F1': 'Indigo',
    '#FF6B6B': 'Coral',
};
function needsDarkText(accentColor) {
    const preset = accentPresets[accentColor];
    if (!preset)
        return false;
    const [r, g, b] = preset.rgb.split(',').map(n => parseInt(n.trim()));
    return (0.299 * r + 0.587 * g + 0.114 * b) / 255 > 0.6;
}
function getAccentStyles(accentColor) {
    return accentPresets[accentColor] || accentPresets['#FF8E53'];
}
const darkTheme = {
    bgBase: '15, 15, 26',
    gradientPrimary: 'linear-gradient(135deg, #FF6B6B 0%, #FF8E53 50%, #E85D04 100%)',
    gradientSecondary: 'linear-gradient(180deg, #1A1A2E 0%, #0F0F1A 100%)',
    colorSuccess: '#00D68F',
    colorSuccessGlow: 'rgba(0, 214, 143, 0.4)',
    colorWarning: '#FFB800',
    colorWarningGlow: 'rgba(255, 184, 0, 0.4)',
    colorError: '#FF3D71',
    colorErrorGlow: 'rgba(255, 61, 113, 0.4)',
    colorInfo: '#00B4D8',
    colorInfoGlow: 'rgba(0, 180, 216, 0.4)',
    bgPrimary: 'linear-gradient(180deg, #0F0F1A 0%, #1A1A2E 100%)',
    bgSurface: 'rgba(255, 255, 255, 0.05)',
    bgSurfaceElevated: 'rgba(255, 255, 255, 0.08)',
    bgSurfaceHover: 'rgba(255, 255, 255, 0.12)',
    glassBg: 'rgba(255, 255, 255, 0.06)',
    glassBorder: 'rgba(255, 255, 255, 0.1)',
    glassBlur: 'blur(20px)',
    textPrimary: '#FFFFFF',
    textSecondary: 'rgba(255, 255, 255, 0.7)',
    textTertiary: 'rgba(255, 255, 255, 0.5)',
    textAccent: '#FF8E53',
    fontDisplay: "'Space Grotesk', system-ui, sans-serif",
    fontBody: "'Inter', system-ui, sans-serif",
    fontMono: "'JetBrains Mono', 'Fira Code', monospace",
    radiusSmall: '8px',
    radiusMedium: '12px',
    radiusLarge: '16px',
    radiusXLarge: '24px',
    shadowSmall: '0 2px 8px rgba(0, 0, 0, 0.2)',
    shadowMedium: '0 8px 24px rgba(0, 0, 0, 0.3)',
    shadowLarge: '0 20px 40px rgba(0, 0, 0, 0.4)',
    shadowGlow: '0 0 20px rgba(255, 107, 107, 0.3)',
    accentRgb: '255, 107, 107',
};
const lightTheme = {
    ...darkTheme,
    bgBase: '245, 245, 245',
    gradientSecondary: 'linear-gradient(180deg, #FFFFFF 0%, #F5F5F5 100%)',
    bgPrimary: 'linear-gradient(180deg, #F5F5F5 0%, #FFFFFF 100%)',
    bgSurface: 'rgba(0, 0, 0, 0.03)',
    bgSurfaceElevated: 'rgba(0, 0, 0, 0.05)',
    bgSurfaceHover: 'rgba(0, 0, 0, 0.08)',
    glassBg: 'rgba(0, 0, 0, 0.03)',
    glassBorder: 'rgba(0, 0, 0, 0.1)',
    textPrimary: '#1A1A2E',
    textSecondary: 'rgba(0, 0, 0, 0.7)',
    textTertiary: 'rgba(0, 0, 0, 0.5)',
    textAccent: '#E65100',
    shadowSmall: '0 2px 8px rgba(0, 0, 0, 0.1)',
    shadowMedium: '0 8px 24px rgba(0, 0, 0, 0.15)',
    shadowLarge: '0 20px 40px rgba(0, 0, 0, 0.2)',
    shadowGlow: '0 0 20px rgba(255, 107, 107, 0.4)',
};
const amoledTheme = {
    ...darkTheme,
    bgBase: '0, 0, 0',
    gradientSecondary: 'linear-gradient(180deg, #000000 0%, #050505 100%)',
    bgPrimary: '#000000',
    bgSurface: 'rgba(255, 255, 255, 0.03)',
    bgSurfaceElevated: 'rgba(255, 255, 255, 0.05)',
    bgSurfaceHover: 'rgba(255, 255, 255, 0.08)',
    glassBg: 'rgba(255, 255, 255, 0.02)',
    glassBorder: 'rgba(255, 255, 255, 0.08)',
    shadowSmall: '0 2px 8px rgba(0, 0, 0, 0.5)',
    shadowMedium: '0 8px 24px rgba(0, 0, 0, 0.6)',
    shadowLarge: '0 20px 40px rgba(0, 0, 0, 0.7)',
};
const theme = darkTheme;
function applyTheme(themeObj, accentColor) {
    const root = document.documentElement;
    root.style.setProperty('--bg-primary', themeObj.bgPrimary);
    root.style.setProperty('--bg-surface', themeObj.bgSurface);
    root.style.setProperty('--bg-surface-elevated', themeObj.bgSurfaceElevated);
    root.style.setProperty('--bg-surface-hover', themeObj.bgSurfaceHover);
    root.style.setProperty('--glass-bg', themeObj.glassBg);
    root.style.setProperty('--glass-border', themeObj.glassBorder);
    root.style.setProperty('--text-primary', themeObj.textPrimary);
    root.style.setProperty('--text-secondary', themeObj.textSecondary);
    root.style.setProperty('--text-tertiary', themeObj.textTertiary);
    root.style.setProperty('--gradient-secondary', themeObj.gradientSecondary);
    root.style.setProperty('--color-success', themeObj.colorSuccess);
    root.style.setProperty('--color-success-glow', themeObj.colorSuccessGlow);
    root.style.setProperty('--color-warning', themeObj.colorWarning);
    root.style.setProperty('--color-warning-glow', themeObj.colorWarningGlow);
    root.style.setProperty('--color-error', themeObj.colorError);
    root.style.setProperty('--color-error-glow', themeObj.colorErrorGlow);
    root.style.setProperty('--color-info', themeObj.colorInfo);
    root.style.setProperty('--color-info-glow', themeObj.colorInfoGlow);
    root.style.setProperty('--shadow-small', themeObj.shadowSmall);
    root.style.setProperty('--shadow-medium', themeObj.shadowMedium);
    root.style.setProperty('--shadow-large', themeObj.shadowLarge);
    root.style.setProperty('--font-body', themeObj.fontBody);
    root.style.setProperty('--font-mono', themeObj.fontMono);
    root.style.setProperty('--font-display', themeObj.fontDisplay);
    root.style.setProperty('--radius-small', themeObj.radiusSmall);
    root.style.setProperty('--radius-medium', themeObj.radiusMedium);
    root.style.setProperty('--radius-large', themeObj.radiusLarge);
    root.style.setProperty('--radius-xlarge', themeObj.radiusXLarge);
    // Apply accent-based styles
    const accentStyles = getAccentStyles(accentColor || '#FF6B6B');
    root.style.setProperty('--gradient-primary', accentStyles.gradient);
    root.style.setProperty('--text-accent', accentStyles.textAccent);
    root.style.setProperty('--accent-rgb', accentStyles.rgb);
    root.style.setProperty('--text-on-accent', accentStyles.textOnAccent);
    root.style.setProperty('--shadow-glow', `0 0 20px rgba(${accentStyles.rgb}, 0.3)`);
    root.style.setProperty('--bg-base', themeObj.bgBase);
}

const CACHE_KEY = 'zm-state-cache';
const CACHE_VERSION = 4;
function writeCache(state) {
    try {
        const serialized = {
            _v: CACHE_VERSION,
            _ts: Date.now(),
            scenario: state.scenario,
            engineActive: state.engineActive,
            capabilities: state.capabilities,
            stats: state.stats,
            systemInfo: state.systemInfo,
            moduleStatuses: state.moduleStatuses,
            fontModules: state.fontModules,
            degraded: state.degraded,
            degradationReason: state.degradationReason,
            rootManager: state.rootManager,
            runtimeStrategy: state.runtimeStrategy,
            mountSource: state.mountSource,
            resolvedStorageMode: state.resolvedStorageMode,
            rules: state.rules.map(r => ({ ...r, createdAt: r.createdAt.toISOString() })),
            excludedUids: state.excludedUids.map(u => ({ ...u, excludedAt: u.excludedAt.toISOString() })),
            activity: state.activity.map(a => ({ ...a, timestamp: a.timestamp.toISOString() })),
            ksuModules: state.ksuModules,
            brene: state.brene,
            susfs: state.susfs,
            uname: state.uname,
            mount: state.mount,
            adb: state.adb,
            verboseLogging: state.verboseLogging,
            externalSusfsModule: state.externalSusfsModule,
            bridgeValues: state.bridgeValues,
        };
        localStorage.setItem(CACHE_KEY, JSON.stringify(serialized));
    }
    catch (e) {
    }
}
function readCache() {
    try {
        const raw = localStorage.getItem(CACHE_KEY);
        if (!raw)
            return null;
        const cached = JSON.parse(raw);
        if (cached._v !== CACHE_VERSION) {
            localStorage.removeItem(CACHE_KEY);
            return null;
        }
        return {
            scenario: cached.scenario,
            engineActive: cached.engineActive,
            capabilities: cached.capabilities,
            stats: cached.stats,
            systemInfo: cached.systemInfo,
            moduleStatuses: cached.moduleStatuses,
            fontModules: cached.fontModules,
            degraded: cached.degraded,
            degradationReason: cached.degradationReason,
            rootManager: cached.rootManager,
            runtimeStrategy: cached.runtimeStrategy,
            mountSource: cached.mountSource,
            resolvedStorageMode: cached.resolvedStorageMode,
            rules: cached.rules.map(r => ({ ...r, createdAt: new Date(r.createdAt) })),
            excludedUids: cached.excludedUids.map(u => ({ ...u, excludedAt: new Date(u.excludedAt) })),
            activity: cached.activity.map(a => ({ ...a, timestamp: new Date(a.timestamp) })),
            ksuModules: cached.ksuModules,
            brene: cached.brene,
            susfs: cached.susfs,
            uname: cached.uname,
            mount: cached.mount,
            adb: cached.adb,
            verboseLogging: cached.verboseLogging,
            externalSusfsModule: cached.externalSusfsModule ?? null,
            bridgeValues: cached.bridgeValues ?? null,
        };
    }
    catch (e) {
        localStorage.removeItem(CACHE_KEY);
        return null;
    }
}

function createAppStore() {
    const [activeTab, setActiveTab] = createSignal('status');
    const [engineActive, setEngineActive] = createSignal(false);
    // Granular loading states for precise UI feedback
    const [loading, setLoading] = createStore({
        status: false, // Engine status, stats, systemInfo
        modules: false, // KSU modules scan
        apps: false, // Installed apps list
        rules: false, // VFS rules CRUD
        activity: false, // Activity log
        engine: false, // Engine toggle
    });
    const [stats, setStats] = createStore({
        activeRules: 0,
        excludedUids: 0,
        hiddenPaths: 0,
        hiddenMaps: 0,
    });
    const [systemInfo, setSystemInfo] = createStore({
        driverVersion: '',
        kernelVersion: '',
        susfsVersion: '',
        uptime: '',
        deviceModel: '',
        androidVersion: '',
        selinuxStatus: '',
    });
    const [rules, setRules] = createSignal([]);
    const [excludedUids, setExcludedUids] = createSignal([]);
    const [activity, setActivity] = createSignal([]);
    let activitySeq = 0;
    const pushActivity = (type, message) => {
        activitySeq++;
        setActivity(prev => [{ id: `rt-${activitySeq}`, type, message, timestamp: new Date() }, ...prev].slice(0, 10));
        api.logActivity(type.toUpperCase(), message).catch(() => { });
    };
    const [installedApps, setInstalledApps] = createSignal([]);
    const [ksuModules, setKsuModules] = createSignal([]);
    const [scenario, setScenario] = createSignal('none');
    const [capabilities, setCapabilities] = createSignal(null);
    const [moduleStatuses, setModuleStatuses] = createSignal([]);
    const [fontModules, setFontModules] = createSignal([]);
    const [emojiConflict, setEmojiConflict] = createSignal(null);
    const [degraded, setDegraded] = createSignal(false);
    const [degradationReason, setDegradationReason] = createSignal(null);
    const [rootManager, setRootManager] = createSignal(null);
    const [runtimeStrategy, setRuntimeStrategy] = createSignal(null);
    const [mountSource, _setMountSource] = createSignal(null);
    const [resolvedStorageMode, setResolvedStorageMode] = createSignal(null);
    const [lastApiError, setLastApiError] = createSignal(null);
    const [externalSusfsModule, setExternalSusfsModule] = createSignal(null);
    const [bridgeValues, setBridgeValues] = createSignal(null);
    const [verboseDumpPath, setVerboseDumpPath] = createSignal(null);
    const [guardStatus, setGuardStatus] = createSignal({
        enabled: true, recoveryLockout: false, bootcount: 0, disabled: false, lastRecovery: null,
        allowedModules: [], pfdMarkers: 0, svcMarkers: 0,
    });
    const savedBgOpacity = typeof window !== 'undefined'
        ? parseFloat(localStorage.getItem('zeromount-bgOpacity') ?? '0.35')
        : 0.35;
    const [bgOpacity, _setBgOpacity] = createSignal(isNaN(savedBgOpacity) ? 0.35 : savedBgOpacity);
    const setBgOpacity = (value) => {
        const clamped = Math.max(0, Math.min(1, value));
        _setBgOpacity(clamped);
        localStorage.setItem('zeromount-bgOpacity', String(clamped));
        document.documentElement.style.setProperty('--bg-opacity', String(clamped));
    };
    const savedTheme = typeof window !== 'undefined'
        ? localStorage.getItem('zeromount-theme')
        : null;
    const savedFixedNav = typeof window !== 'undefined'
        ? localStorage.getItem('zeromount-fixedNav') === 'true'
        : true;
    const savedAutoAccentRaw = typeof window !== 'undefined'
        ? localStorage.getItem('zeromount-autoAccent')
        : null;
    const savedAutoAccent = savedAutoAccentRaw === null ? true : savedAutoAccentRaw === 'true';
    const savedAccent = typeof window !== 'undefined'
        ? localStorage.getItem('zeromount-accent')
        : null;
    const savedLanguage = typeof window !== 'undefined'
        ? localStorage.getItem('zeromount-language')
        : null;
    if (savedLanguage) {
        loadLocale(savedLanguage);
    }
    else if (typeof window !== 'undefined') {
        const detected = detectLocale(LANGUAGES.map(l => l.code));
        if (detected !== 'en')
            loadLocale(detected);
    }
    const accentColors = Object.keys(accentPresets);
    const randomAccent = accentColors[Math.floor(Math.random() * accentColors.length)];
    const firstOpen = savedAutoAccentRaw === null;
    const initialAccent = firstOpen ? '#FF6B6B' : savedAutoAccent ? randomAccent : (savedAccent && accentPresets[savedAccent] ? savedAccent : '#FF8E53');
    const defaultBrene = {
        enabled: false,
        auto_hide_apk: true,
        auto_hide_zygisk: true,
        auto_hide_fonts: true,
        auto_hide_rooted_folders: true,
        auto_hide_recovery: true,
        auto_hide_tmp: true,
        cleanup_sus_marker: true,
        hide_nonstandard_android: false,
        hide_nonstandard_sdcard: false,
        sync_su_compat: false,
        sync_selinux_hide: false,
        avc_log_spoofing: true,
        susfs_log: false,
        hide_sus_mounts: true,
        hide_sus_mounts_off_after_boot: false,
        emulate_vold_app_data: true,
        vold_use_path_loop: true,
        force_hide_lsposed: true,
        spoof_cmdline: true,
        hide_ksu_loops: true,
        kernel_umount: false,
        try_umount: false,
        skip_legit_mounts: true,
        prop_spoofing: true,
        spoof_fingerprint_properties: false,
        spoof_utc_properties: false,
        spoof_date_properties: false,
        prop_spoofing_repeat: false,
        auto_hide_injections: true,
        hide_cusrom: 0,
    };
    const defaultSusfs = {
        enabled: true,
        path_hide: true,
        kstat: true,
        maps_hide: true,
    };
    const defaultUname = {
        mode: 'disabled',
        release: '',
        version: '',
    };
    const defaultMount = {
        storage_mode: 'auto',
        overlay_preferred: true,
        magic_mount_fallback: true,
        random_mount_paths: true,
        mount_source: 'auto',
        overlay_source: 'auto',
        exclude_hosts_modules: true,
        module_blacklist: '',
        ext4_image_size_mb: 0,
        restart_framework: false,
    };
    const defaultPerf = {
        enabled: false,
    };
    const defaultAdb = {
        usb_debugging: false,
        developer_options: false,
    };
    const defaultGuard = {
        enabled: true,
        boot_timeout_secs: 100,
        zygote_watch_secs: 30,
        zygote_poll_secs: 4,
        zygote_max_restarts: 4,
        systemui_watch_secs: 30,
        systemui_poll_secs: 4,
        systemui_max_restarts: 3,
        systemui_absent_timeout_secs: 25,
        systemui_monitor_enabled: true,
    };
    const [settings, setSettings] = createStore({
        theme: (savedTheme || 'amoled'),
        accentColor: initialAccent,
        autoAccentColor: savedAutoAccent,
        verboseLogging: false,
        fixedNav: savedFixedNav,
        brene: { ...defaultBrene },
        susfs: { ...defaultSusfs },
        uname: { ...defaultUname },
        mount: { ...defaultMount },
        perf: { ...defaultPerf },
        emoji: { enabled: false },
        adb: { ...defaultAdb },
        guard: { ...defaultGuard },
    });
    const [systemPrefersDark, setSystemPrefersDark] = createSignal(typeof window !== 'undefined'
        ? window.matchMedia('(prefers-color-scheme: dark)').matches
        : true);
    if (typeof window !== 'undefined') {
        const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
        mediaQuery.addEventListener('change', (e) => setSystemPrefersDark(e.matches));
    }
    const currentTheme = createMemo(() => {
        const pref = settings.theme;
        const baseTheme = pref === 'light' ? lightTheme
            : pref === 'amoled' ? amoledTheme
                : pref === 'auto' ? (systemPrefersDark() ? darkTheme : lightTheme)
                    : darkTheme;
        const accentStyles = getAccentStyles(settings.accentColor);
        return {
            ...baseTheme,
            gradientPrimary: accentStyles.gradient,
            textAccent: accentStyles.textAccent,
            textOnAccent: accentStyles.textOnAccent,
            accentRgb: accentStyles.rgb,
            shadowGlow: `0 0 20px rgba(${accentStyles.rgb}, 0.3)`,
        };
    });
    createEffect(() => {
        applyTheme(currentTheme(), settings.accentColor);
    });
    createEffect(() => {
        if (typeof window !== 'undefined') {
            localStorage.setItem('zeromount-theme', settings.theme);
        }
    });
    createEffect(() => {
        if (typeof window !== 'undefined') {
            localStorage.setItem('zeromount-accent', settings.accentColor);
        }
    });
    createEffect(() => {
        if (typeof window !== 'undefined') {
            localStorage.setItem('zeromount-fixedNav', String(settings.fixedNav));
        }
    });
    createEffect(() => {
        if (typeof window !== 'undefined') {
            localStorage.setItem('zeromount-autoAccent', String(settings.autoAccentColor));
        }
    });
    // Randomize accent when page becomes visible (for cached WebViews)
    if (typeof window !== 'undefined') {
        let accentDebounce;
        document.addEventListener('visibilitychange', () => {
            if (document.visibilityState === 'visible' && settings.autoAccentColor) {
                clearTimeout(accentDebounce);
                accentDebounce = setTimeout(() => {
                    const colors = Object.keys(accentPresets);
                    const newRandom = colors[Math.floor(Math.random() * colors.length)];
                    setSettings({ accentColor: newRandom });
                }, 300);
            }
        });
    }
    const susfsOwnership = createMemo(() => {
        const caps = capabilities();
        const external = externalSusfsModule();
        const enabled = settings.susfs.enabled;
        if (!caps?.susfs_available)
            return 'disabled';
        if (enabled)
            return 'embedded_active';
        if (external)
            return 'deferred_external';
        return 'disabled';
    });
    const [toast, setToast] = createSignal(null);
    let toastTimer;
    const showToast = (message, type = 'info', duration) => {
        if (toastTimer)
            clearTimeout(toastTimer);
        const ms = duration || (type === 'warning' ? 4500 : 3000);
        setToast({ message, type, duration: ms });
        toastTimer = setTimeout(() => setToast(null), ms);
    };
    const hydrateFromCache = () => {
        const cached = readCache();
        if (!cached)
            return false;
        batch(() => {
            setScenario(cached.scenario);
            setEngineActive(cached.engineActive);
            setCapabilities(cached.capabilities);
            setStats(cached.stats);
            setSystemInfo(cached.systemInfo);
            setModuleStatuses(cached.moduleStatuses);
            setFontModules(cached.fontModules);
            setDegraded(cached.degraded);
            setDegradationReason(cached.degradationReason);
            setRootManager(cached.rootManager);
            setRuntimeStrategy(cached.runtimeStrategy);
            _setMountSource(cached.mountSource);
            setResolvedStorageMode(cached.resolvedStorageMode);
            setRules(cached.rules);
            setExcludedUids(cached.excludedUids);
            setActivity(cached.activity);
            setKsuModules(cached.ksuModules);
            setSettings('brene', prev => ({ ...prev, ...cached.brene }));
            setSettings('susfs', prev => ({ ...prev, ...cached.susfs }));
            setSettings('uname', prev => ({ ...prev, ...cached.uname }));
            setSettings('mount', prev => ({ ...prev, ...cached.mount }));
            setSettings({ verboseLogging: cached.verboseLogging });
            if (cached.externalSusfsModule !== undefined)
                setExternalSusfsModule(cached.externalSusfsModule);
            if (cached.bridgeValues !== undefined)
                setBridgeValues(cached.bridgeValues);
        });
        return true;
    };
    const buildCacheState = () => ({
        scenario: scenario(),
        engineActive: engineActive(),
        capabilities: capabilities(),
        stats: { ...stats },
        systemInfo: { ...systemInfo },
        moduleStatuses: moduleStatuses(),
        fontModules: fontModules(),
        degraded: degraded(),
        degradationReason: degradationReason(),
        rootManager: rootManager(),
        runtimeStrategy: runtimeStrategy(),
        mountSource: mountSource(),
        resolvedStorageMode: resolvedStorageMode(),
        rules: rules(),
        excludedUids: excludedUids(),
        activity: activity(),
        ksuModules: ksuModules(),
        brene: { ...settings.brene },
        susfs: { ...settings.susfs },
        uname: { ...settings.uname },
        mount: { ...settings.mount },
        adb: { ...settings.adb },
        verboseLogging: settings.verboseLogging,
        externalSusfsModule: externalSusfsModule(),
        bridgeValues: bridgeValues(),
    });
    const augmentManagedDroidspacesStatus = (status, liveRules = []) => {
        const modules = [...(status?.modules || [])];
        const managedActive = !!status?.droidspaces_vfs?.active || (Array.isArray(liveRules) && liveRules.some(r => r && r.source === '/data/adb/modules/meta-zeromount/.vfs-stage/droidspaces' && (r.target === '/bin/droidspaces' || r.target === '/system/bin/droidspaces')));
        if (managedActive && !modules.some(m => m.id === 'droidspaces')) {
            modules.push({
                id: 'droidspaces',
                strategy: 'Vfs',
                rules_applied: 1,
                rules_failed: 0,
                errors: [],
                mount_paths: ['/system/bin/droidspaces'],
            });
        }
        const liveCount = Array.isArray(liveRules) ? liveRules.length : 0;
        const managedCount = Number(status?.droidspaces_vfs?.actual_vfs_rule_count || 0);
        const scannerCount = Number(status?.rule_count || 0);
        return {
            modules,
            managedActive,
            activeRules: Math.max(scannerCount, managedCount, liveCount),
        };
    };
    const augmentManagedDroidspacesKsuModules = (modules, managedActive) => {
        const list = [...(modules || [])];
        if (managedActive && !list.some(m => (m.path || '').split('/').pop() === 'droidspaces')) {
            list.push({
                name: 'Droidspaces: Daemon & Init',
                path: '/data/adb/modules/droidspaces',
                hasSystem: true,
                hasVendor: false,
                hasProduct: false,
                isLoaded: true,
                fileCount: 1,
            });
        }
        return list;
    };
    const applyBatchedResponse = (data) => {
        batch(() => {
            const s = data.status;
            const managedView = augmentManagedDroidspacesStatus(s, data.rules);
            setScenario(s.scenario);
            setCapabilities(s.capabilities);
            setModuleStatuses(managedView.modules);
            setFontModules(s.font_modules || []);
            setDegraded(s.degraded);
            setDegradationReason(s.degradation_reason);
            setEngineActive(s.engine_active ?? false);
            if (s.driver_version !== null)
                setSystemInfo('driverVersion', `v${s.driver_version}`);
            setSystemInfo('susfsVersion', s.susfs_version || '');
            setRootManager(s.root_manager);
            setRuntimeStrategy(s.active_strategy ?? null);
            _setMountSource(s.mount_source ?? null);
            setResolvedStorageMode(s.resolved_storage_mode ?? null);
            setStats({
                activeRules: managedView.activeRules,
                excludedUids: s.excluded_uid_count,
                hiddenPaths: s.hidden_path_count,
                hiddenMaps: s.hidden_maps_count ?? 0,
            });
            const si = data.system_info;
            setSystemInfo('kernelVersion', si.kernelVersion);
            setSystemInfo('uptime', si.uptime);
            setSystemInfo('deviceModel', si.deviceModel);
            setSystemInfo('androidVersion', si.androidVersion);
            setSystemInfo('selinuxStatus', si.selinuxStatus);
            const cfg = data.config;
            if (cfg.brene) {
                const brene = {};
                for (const key of Object.keys(cfg.brene)) {
                    if (key in cfg.brene) {
                        const v = cfg.brene[key];
                        brene[key] = typeof v === 'boolean' ? v : String(v) === 'true';
                    }
                }
                setSettings('brene', prev => ({ ...prev, ...brene }));
            }
            if (cfg.susfs) {
                const susfs = {};
                for (const key of Object.keys(cfg.susfs)) {
                    if (key in cfg.susfs) {
                        const v = cfg.susfs[key];
                        susfs[key] = typeof v === 'boolean' ? v : String(v) === 'true';
                    }
                }
                setSettings('susfs', prev => ({ ...prev, ...susfs }));
            }
            if (cfg.uname) {
                setSettings('uname', prev => ({
                    ...prev,
                    mode: (cfg.uname.mode ?? prev.mode),
                    release: cfg.uname.release ?? prev.release,
                    version: cfg.uname.version ?? prev.version,
                }));
            }
            if (cfg.mount) {
                setSettings('mount', prev => ({
                    ...prev,
                    storage_mode: (cfg.mount.storage_mode ?? prev.storage_mode),
                    overlay_preferred: cfg.mount.overlay_preferred ?? prev.overlay_preferred,
                    magic_mount_fallback: cfg.mount.magic_mount_fallback ?? prev.magic_mount_fallback,
                    random_mount_paths: cfg.mount.random_mount_paths ?? prev.random_mount_paths,
                    mount_source: cfg.mount.mount_source ?? prev.mount_source,
                    overlay_source: cfg.mount.overlay_source ?? prev.overlay_source,
                    exclude_hosts_modules: cfg.mount.exclude_hosts_modules ?? prev.exclude_hosts_modules,
                    module_blacklist: cfg.mount.module_blacklist ?? prev.module_blacklist,
                    ext4_image_size_mb: cfg.mount.ext4_image_size_mb ?? prev.ext4_image_size_mb,
                    restart_framework: cfg.mount.restart_framework ?? prev.restart_framework,
                }));
            }
            if (cfg.perf) {
                setSettings('perf', prev => ({
                    ...prev,
                    enabled: typeof cfg.perf.enabled === 'boolean' ? cfg.perf.enabled : prev.enabled,
                }));
            }
            if (cfg.emoji) {
                setSettings('emoji', prev => ({
                    ...prev,
                    enabled: typeof cfg.emoji.enabled === 'boolean' ? cfg.emoji.enabled : prev.enabled,
                }));
            }
            setEmojiConflict(data.emoji_conflict || null);
            const extMod = s.capabilities?.external_susfs_module;
            setExternalSusfsModule(extMod && extMod !== 'none' ? extMod : null);
            setBridgeValues(data.bridge_values ?? null);
            if (data.guard) {
                setGuardStatus(data.guard);
            }
            if (cfg.guard) {
                setSettings('guard', prev => ({ ...prev, ...cfg.guard }));
            }
            if (cfg.logging) {
                setSettings({ verboseLogging: typeof cfg.logging.verbose === 'boolean' ? cfg.logging.verbose : settings.verboseLogging });
            }
            const serverLang = cfg.ui?.language;
            if (serverLang && !savedLanguage)
                loadLocale(serverLang);
            setRules(data.rules.map((r, i) => ({
                id: r.id || String(i + 1),
                name: r.name,
                source: r.source,
                target: r.target,
                createdAt: new Date(),
            })));
            setExcludedUids(data.excluded_uids.map(u => ({
                uid: u.uid,
                packageName: u.packageName,
                appName: u.appName,
                excludedAt: u.excludedAt ? new Date(u.excludedAt) : new Date(),
            })));
            const validTypes = ['rule_added', 'rule_removed', 'uid_excluded', 'uid_included', 'engine_enabled', 'engine_disabled', 'setting_changed', 'mount_strategy_changed', 'susfs_toggle', 'brene_toggle', 'theme_changed'];
            setActivity(prev => {
                const runtimeItems = prev.filter(item => item.id.startsWith('rt-'));
                const rtMessages = new Set(runtimeItems.map(item => item.message));
                const freshItems = data.activity
                    .filter(a => !rtMessages.has(a.message))
                    .map(a => ({
                    id: a.id,
                    type: (validTypes.includes(a.type) ? a.type : 'engine_enabled'),
                    message: a.message,
                    timestamp: new Date(a.timestamp),
                }));
                const merged = [...runtimeItems, ...freshItems];
                merged.sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());
                return merged.slice(0, 10);
            });
            setKsuModules(augmentManagedDroidspacesKsuModules(data.modules, managedView.managedActive));
        });
    };
    const loadInitialDataLegacy = async () => {
        const criticalResults = await Promise.allSettled([
            api.getRuntimeStatus(),
            api.getSystemInfoBatched(),
            api.configDump(),
            settings.autoAccentColor ? api.fetchSystemColor() : Promise.resolve(null),
        ]);
        const status = criticalResults[0].status === 'fulfilled' ? criticalResults[0].value : null;
        const sysInfo = criticalResults[1].status === 'fulfilled' ? criticalResults[1].value : { driverVersion: '', kernelVersion: '', susfsVersion: '', uptime: '', deviceModel: '', androidVersion: '', selinuxStatus: '' };
        const dump = criticalResults[2].status === 'fulfilled' ? criticalResults[2].value : null;
        const systemColor = criticalResults[3].status === 'fulfilled' ? criticalResults[3].value : null;
        batch(() => {
            if (status) {
                const managedView = augmentManagedDroidspacesStatus(status);
                setScenario(status.scenario);
                setCapabilities(status.capabilities);
                setModuleStatuses(managedView.modules);
                setFontModules(status.font_modules || []);
                setDegraded(status.degraded);
                setDegradationReason(status.degradation_reason);
                setEngineActive(status.engine_active ?? false);
                if (status.driver_version !== null)
                    setSystemInfo('driverVersion', `v${status.driver_version}`);
                setSystemInfo('susfsVersion', status.susfs_version || '');
                setRootManager(status.root_manager);
                setRuntimeStrategy(status.active_strategy ?? null);
                _setMountSource(status.mount_source ?? null);
                setResolvedStorageMode(status.resolved_storage_mode ?? null);
                setStats({
                    activeRules: managedView.activeRules,
                    excludedUids: status.excluded_uid_count,
                    hiddenPaths: status.hidden_path_count,
                    hiddenMaps: status.hidden_maps_count ?? 0,
                });
            }
            setSystemInfo('kernelVersion', sysInfo.kernelVersion);
            setSystemInfo('uptime', sysInfo.uptime);
            setSystemInfo('deviceModel', sysInfo.deviceModel);
            setSystemInfo('androidVersion', sysInfo.androidVersion);
            setSystemInfo('selinuxStatus', sysInfo.selinuxStatus);
            if (!status) {
                setSystemInfo('driverVersion', sysInfo.driverVersion);
                setSystemInfo('susfsVersion', sysInfo.susfsVersion);
            }
            if (systemColor)
                setSettings({ accentColor: systemColor });
            setLoading('status', false);
        });
        const configLoads = Promise.allSettled([
            loadBreneSettings(dump),
            loadSusfsSettings(dump),
            loadPerfSettings(dump),
            loadAdbSettings(),
            loadMountSettings(dump),
            loadVerboseState(dump),
        ]);
        const deferredResults = await Promise.allSettled([
            api.getRules(),
            api.getExcludedUids(),
            api.getActivity(),
            api.scanKsuModules(),
        ]);
        const rulesData = deferredResults[0].status === 'fulfilled' ? deferredResults[0].value : [];
        const uidsData = deferredResults[1].status === 'fulfilled' ? deferredResults[1].value : [];
        const activityData = deferredResults[2].status === 'fulfilled' ? deferredResults[2].value : [];
        const ksuModulesData = deferredResults[3].status === 'fulfilled' ? deferredResults[3].value : [];
        batch(() => {
            setRules(rulesData);
            setExcludedUids(uidsData);
            setActivity(prev => {
                const runtimeItems = prev.filter(item => item.id.startsWith('rt-'));
                const rtMessages = new Set(runtimeItems.map(item => item.message));
                const deduped = activityData.filter(item => !rtMessages.has(item.message));
                const merged = [...runtimeItems, ...deduped];
                merged.sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());
                return merged.slice(0, 10);
            });
            if (!status) {
                setStats({
                    activeRules: rulesData.length,
                    excludedUids: uidsData.length,
                });
            }
            setKsuModules(ksuModulesData);
        });
        await configLoads;
    };
    const loadInitialData = async () => {
        setLoading({ status: true, rules: true, activity: true, modules: true });
        hydrateFromCache();
        try {
            // Layer 1+2: check inlined/cached data first (zero ksu.exec)
            const cached = await readFromCache();
            if (cached) {
                applyBatchedResponse(cached);
                // Check boot-time inlined accent color
                const inlinedAccent = window.__ZM_ACCENT__;
                if (settings.autoAccentColor && typeof inlinedAccent === 'string' && inlinedAccent) {
                    setSettings({ accentColor: inlinedAccent });
                }
                // Android owns developer_options + usb_debugging — always read live
                await loadAdbSettings(cached);
            }
            else {
                // Fallback: live ksu.exec (first install before reboot, or cache invalidated)
                const [batchedData, systemColor] = await Promise.all([
                    api.webuiInit(),
                    settings.autoAccentColor ? api.fetchSystemColor() : Promise.resolve(null),
                ]);
                if (systemColor)
                    setSettings({ accentColor: systemColor });
                if (batchedData) {
                    applyBatchedResponse(batchedData);
                    await loadAdbSettings(batchedData);
                }
                else {
                    await loadInitialDataLegacy();
                }
            }
            // Boot cache is historical. Always read mutable gate values live,
            // including when cached module/rule observations remain usable.
            const liveRequirements = await readLiveRequirementState(api);
            await Promise.all([loadBreneSettings(liveRequirements), loadSusfsSettings(liveRequirements)]);
            writeCache(buildCacheState());
            setLastApiError(null);
        }
        catch (err) {
            setLastApiError({ operation: 'loadInitialData', error: err, timestamp: new Date() });
            showToast(t('toast.failedLoadData'), 'error');
        }
        finally {
            setLoading({ status: false, rules: false, activity: false, modules: false });
        }
    };
    const toggleEngine = async () => {
        if (loading.engine)
            return;
        const newState = !engineActive();
        setEngineActive(newState);
        pushActivity(newState ? 'engine_enabled' : 'engine_disabled', newState ? t('activity.engineOn') : t('activity.engineOff'));
        setLoading('engine', true);
        try {
            await api.toggleEngine(newState);
            showToast(newState ? t('toast.engineActivated') : t('toast.engineDeactivated'), 'success');
        }
        catch (err) {
            setEngineActive(!newState);
            showToast(t('toast.failedToggleEngine'), 'error');
        }
        finally {
            setLoading('engine', false);
        }
    };
    const excludeUid = async (uid, packageName, appName) => {
        if (uid <= 0) {
            showToast(t('toast.cannotExcludeUnknownUid'), 'error');
            return null;
        }
        if (pendingUidOperations.has(uid)) {
            return null;
        }
        pendingUidOperations.add(uid);
        setLoading('apps', true);
        try {
            const excluded = await api.excludeUid(uid, packageName, appName);
            setExcludedUids(prev => [...prev, excluded]);
            setStats('excludedUids', s => s + 1);
            pushActivity('uid_excluded', t('activity.uidExcluded', { name: appName, uid }));
            showToast(t('toast.excludedApp', { appName }), 'success');
            return excluded;
        }
        catch (err) {
            showToast(t('toast.failedExcludeUid'), 'error');
            throw err;
        }
        finally {
            pendingUidOperations.delete(uid);
            setLoading('apps', false);
        }
    };
    const includeUid = async (uid) => {
        if (uid <= 0) {
            showToast(t('toast.cannotIncludeUnknownUid'), 'error');
            return;
        }
        if (pendingUidOperations.has(uid)) {
            return;
        }
        pendingUidOperations.add(uid);
        setLoading('apps', true);
        try {
            await api.includeUid(uid);
            setExcludedUids(prev => prev.filter(u => u.uid !== uid));
            setStats('excludedUids', s => s - 1);
            pushActivity('uid_included', t('activity.uidIncluded', { uid }));
            showToast(t('toast.uidIncluded'), 'success');
        }
        catch (err) {
            showToast(t('toast.failedIncludeUid'), 'error');
        }
        finally {
            pendingUidOperations.delete(uid);
            setLoading('apps', false);
        }
    };
    const clearAllRules = async () => {
        setLoading('rules', true);
        try {
            await api.clearAllRules();
            setRules([]);
            setStats('activeRules', 0);
            pushActivity('rule_removed', t('activity.allRulesCleared'));
            showToast(t('toast.allRulesCleared'), 'success');
        }
        catch (err) {
            const msg = String(err).includes('errno') || String(err).includes('No such')
                ? t('toast.vfsUnavailable') : t('toast.failedClearRules');
            showToast(msg, 'error');
        }
        finally {
            setLoading('rules', false);
        }
    };
    const updateSettings = (updates) => {
        setSettings(updates);
        if (updates.theme)
            pushActivity('theme_changed', t('activity.themeChanged', { value: updates.theme }));
        if (updates.accentColor)
            pushActivity('theme_changed', t('activity.accentChanged', { value: accentNames[updates.accentColor] || updates.accentColor }));
        if (updates.fixedNav !== undefined)
            pushActivity('setting_changed', t('activity.fixedNavChanged', { value: updates.fixedNav ? t('activity.on') : t('activity.off') }));
    };
    const fetchSystemColor = async () => {
        try {
            const systemColor = await api.fetchSystemColor();
            if (systemColor) {
                setSettings({ accentColor: systemColor });
            }
        }
        catch (e) {
        }
    };
    const setVerboseLogging = async (enabled) => {
        setSettings({ verboseLogging: enabled });
        try {
            await api.setVerboseLogging(enabled);
            pushActivity('setting_changed', t('activity.verboseChanged', { value: enabled ? t('activity.on') : t('activity.off') }));
            if (enabled) {
                showToast(t('toast.rebootingVerbose'), 'warning', 3000);
                const timerId = setTimeout(async () => {
                    try {
                        await api.reboot();
                    }
                    catch {
                        showToast(t('toast.rebootFailed'), 'error');
                    }
                }, 3000);
                window.__zmRebootTimer = timerId;
            }
            else {
                if (window.__zmRebootTimer) {
                    clearTimeout(window.__zmRebootTimer);
                    window.__zmRebootTimer = null;
                }
                showToast(t('toast.verboseDisabled'), 'info');
                setVerboseDumpPath(null);
            }
        }
        catch (e) {
            setSettings({ verboseLogging: !enabled });
            showToast(t('toast.failedSetVerbose'), 'error');
        }
    };
    const loadBreneSettings = async (dump) => {
        const breneKeys = [
            'enabled',
            'auto_hide_apk', 'auto_hide_zygisk', 'auto_hide_fonts',
            'auto_hide_rooted_folders', 'auto_hide_recovery', 'auto_hide_tmp',
            'cleanup_sus_marker', 'hide_nonstandard_android', 'hide_nonstandard_sdcard', 'sync_su_compat', 'sync_selinux_hide',
            'avc_log_spoofing', 'susfs_log',
            'hide_sus_mounts', 'emulate_vold_app_data', 'force_hide_lsposed',
            'spoof_cmdline', 'hide_ksu_loops', 'kernel_umount', 'try_umount', 'prop_spoofing', 'auto_hide_injections',
            'spoof_fingerprint_properties', 'spoof_utc_properties', 'spoof_date_properties', 'prop_spoofing_repeat',
        ];
        if (dump?.brene && dump?.uname) {
            const brene = {};
            for (const key of breneKeys) {
                if (key in dump.brene) {
                    const v = dump.brene[key];
                    brene[key] = typeof v === 'boolean' ? v : String(v) === 'true';
                }
            }
            setSettings('brene', prev => ({ ...prev, ...brene }));
            const uname = {};
            if (dump.uname.mode != null)
                uname.mode = dump.uname.mode;
            if (dump.uname.release != null)
                uname.release = String(dump.uname.release);
            if (dump.uname.version != null)
                uname.version = String(dump.uname.version);
            setSettings('uname', prev => ({ ...prev, ...uname }));
            return;
        }
        // Fallback: individual configGet calls
        const results = await Promise.allSettled([
            ...breneKeys.map(k => api.configGet(`brene.${k}`)),
            api.configGet('uname.mode'),
            api.configGet('uname.release'),
            api.configGet('uname.version'),
        ]);
        const brene = {};
        breneKeys.forEach((key, i) => {
            const r = results[i];
            if (r.status === 'fulfilled' && r.value !== null) {
                brene[key] = r.value === 'true';
            }
        });
        setSettings('brene', prev => ({ ...prev, ...brene }));
        const unameMode = results[breneKeys.length];
        const unameRelease = results[breneKeys.length + 1];
        const unameVersion = results[breneKeys.length + 2];
        const uname = {};
        if (unameMode.status === 'fulfilled' && unameMode.value !== null) {
            uname.mode = unameMode.value;
        }
        if (unameRelease.status === 'fulfilled' && unameRelease.value !== null) {
            uname.release = unameRelease.value;
        }
        if (unameVersion.status === 'fulfilled' && unameVersion.value !== null) {
            uname.version = unameVersion.value;
        }
        setSettings('uname', prev => ({ ...prev, ...uname }));
    };
    const setBreneToggle = async (key, value) => {
        setSettings('brene', key, value);
        let kernelSet = false;
        try {
            await api.configSet(`brene.${key}`, String(value));
            if (key === 'enabled' && await api.configGet('brene.enabled') !== String(value)) throw new Error('BRENE-Schalter nicht gespeichert');
            // Live supercalls for kernel-immediate toggles
            if (key === 'avc_log_spoofing') {
                await api.setSusfsAvcSpoofing(value);
                kernelSet = true;
            }
            else if (key === 'susfs_log') {
                await api.setSusfsLog(value);
                kernelSet = true;
            }
            else if (key === 'hide_sus_mounts') {
                await api.setSusfsHideMounts(value);
                kernelSet = true;
            }
            else if (key === 'kernel_umount' || key === 'sync_su_compat' || key === 'sync_selinux_hide') {
                kernelSet = true;
                await api.setKernelFeature(key === 'sync_su_compat' ? 'su_compat' : key === 'sync_selinux_hide' ? 'selinux_hide' : 'kernel_umount', value);
            }
            // Bridge write syncs config.toml -> external module config.sh
            await api.bridgeWrite(`brene.${key}`, String(value));
            pushActivity('brene_toggle', t('activity.settingChanged', { key, value: value ? t('activity.on') : t('activity.off') }));
        }
        catch (e) {
            showToast(t('toast.failedSaveKey', { key }), 'error');
            setSettings('brene', key, !value);
            const old = !value;
            api.configSet(`brene.${key}`, String(old)).catch(() => { });
            if (kernelSet) {
                const rollbackKernel = key === 'avc_log_spoofing' ? api.setSusfsAvcSpoofing(old)
                    : key === 'susfs_log' ? api.setSusfsLog(old)
                        : key === 'hide_sus_mounts' ? api.setSusfsHideMounts(old)
                            : key === 'kernel_umount' || key === 'sync_su_compat' || key === 'sync_selinux_hide' ? api.setKernelFeature(key === 'sync_su_compat' ? 'su_compat' : key === 'sync_selinux_hide' ? 'selinux_hide' : 'kernel_umount', old)
                                : null;
                rollbackKernel?.catch(() => { });
            }
            api.bridgeWrite(`brene.${key}`, String(old)).catch(() => { });
        }
    };
    const setBreneNumeric = async (key, value) => {
        setSettings('brene', key, value);
        try {
            await api.configSet(`brene.${key}`, String(value));
            await api.bridgeWrite(`brene.${key}`, String(value));
            pushActivity('brene_toggle', t('activity.settingChanged', { key, value: String(value) }));
        }
        catch (e) {
            showToast(t('toast.failedSaveKey', { key }), 'error');
        }
    };
    const setSusfsToggle = async (key, value) => {
        setSettings('susfs', key, value);
        try {
            await api.configSet(`susfs.${key}`, String(value));
            if (key === 'enabled' && await api.configGet('susfs.enabled') !== String(value)) throw new Error('SuSFS-Schalter nicht gespeichert');
            pushActivity('susfs_toggle', t('activity.settingChanged', { key, value: value ? t('activity.on') : t('activity.off') }));
        }
        catch (e) {
            showToast(String(e?.message || t('toast.failedSaveKey', { key })), 'error');
            setSettings('susfs', key, !value);
        }
    };
    const setPerfToggle = async (key, value) => {
        setSettings('perf', key, value);
        try {
            await api.configSet(`perf.${key}`, String(value));
            pushActivity('setting_changed', t('activity.settingChanged', { key: `perf.${key}`, value: value ? t('activity.on') : t('activity.off') }));
        }
        catch (e) {
            showToast(t('toast.failedSaveKey', { key }), 'error');
            setSettings('perf', key, !value);
        }
    };
    const setEmojiToggle = async (key, value) => {
        setSettings('emoji', key, value);
        try {
            await api.configSet(`emoji.${key}`, String(value));
            pushActivity('setting_changed', t('activity.settingChanged', { key: `emoji.${key}`, value: value ? t('activity.on') : t('activity.off') }));
        }
        catch (e) {
            showToast(t('toast.failedSaveKey', { key }), 'error');
            setSettings('emoji', key, !value);
        }
    };
    // Android owns developer-options and USB-debugging values; handlers write them directly.
    const setAdbToggle = async (key, value) => {
        setSettings('adb', key, value);
        pushActivity('setting_changed', t('activity.settingChanged', { key: `adb.${key}`, value: value ? t('activity.on') : t('activity.off') }));
    };
    const setGuardToggle = async (key, value) => {
        setSettings('guard', key, value);
        if (key === 'enabled')
            setGuardStatus(prev => ({ ...prev, enabled: value }));
        try {
            await api.configSet(`guard.${key}`, String(value));
            pushActivity('setting_changed', t('activity.settingChanged', { key: `guard.${key}`, value: value ? t('activity.on') : t('activity.off') }));
        }
        catch (e) {
            showToast(t('toast.failedSaveKey', { key: `guard.${key}` }), 'error');
            setSettings('guard', key, !value);
            if (key === 'enabled')
                setGuardStatus(prev => ({ ...prev, enabled: !value }));
        }
    };
    const guardAllowModule = async (name) => {
        if (!MODULE_ID_RE$1.test(name) || name.length > 256) {
            showToast(t('toast.failedWhitelist', { name }), 'error');
            return;
        }
        try {
            const result = await runShell(`${PATHS.BINARY} guard allow ${name}`);
            if (result.errno !== 0)
                throw new Error(result.stderr || result.stdout || `guard allow failed: ${result.errno}`);
            setGuardStatus(prev => ({
                ...prev,
                allowedModules: [...prev.allowedModules.filter(m => m !== name), name],
            }));
            showToast(t('toast.addedToWhitelist', { name }), 'success');
        }
        catch (e) {
            showToast(t('toast.failedWhitelist', { name }), 'error');
        }
    };
    const guardDisallowModule = async (name) => {
        if (name === 'meta-zeromount') {
            showToast(t('toast.cannotRemoveSelf'), 'error');
            return;
        }
        if (!MODULE_ID_RE$1.test(name) || name.length > 256) {
            showToast(t('toast.failedRemove', { name }), 'error');
            return;
        }
        try {
            const result = await runShell(`${PATHS.BINARY} guard disallow ${name}`);
            if (result.errno !== 0)
                throw new Error(result.stderr || result.stdout || `guard disallow failed: ${result.errno}`);
            setGuardStatus(prev => ({
                ...prev,
                allowedModules: prev.allowedModules.filter(m => m !== name),
            }));
            showToast(t('toast.removedFromWhitelist', { name }), 'success');
        }
        catch (e) {
            showToast(t('toast.failedRemove', { name }), 'error');
        }
    };
    const guardClearLockout = async () => {
        try {
            await runShell(`${PATHS.BINARY} guard clear-lockout`);
            setGuardStatus(prev => ({ ...prev, recoveryLockout: false, pfdMarkers: 0, svcMarkers: 0 }));
            showToast(t('toast.lockoutCleared'), 'success');
        }
        catch {
            showToast(t('toast.failedClearLockout'), 'error');
        }
    };
    const setUnameMode = async (mode) => {
        const prev = settings.uname.mode;
        setSettings('uname', 'mode', mode);
        try {
            await api.configSet('uname.mode', mode);
            pushActivity('setting_changed', t('activity.settingChanged', { key: 'uname.mode', value: mode }));
        }
        catch (e) {
            showToast(t('toast.failedSaveUnameMode'), 'error');
            setSettings('uname', 'mode', prev);
        }
    };
    const setUnameField = async (field, value) => {
        const prev = settings.uname[field];
        setSettings('uname', field, value);
        try {
            await api.configSet(`uname.${field}`, value);
            pushActivity('setting_changed', t('activity.settingChanged', { key: `uname.${field}`, value: value || t('activity.empty') }));
        }
        catch (e) {
            showToast(t('toast.failedSaveUname', { field }), 'error');
            setSettings('uname', field, prev);
        }
    };
    const loadSusfsSettings = async (dump) => {
        if (dump?.susfs) {
            const s = dump.susfs;
            const susfs = {};
            for (const key of ['enabled', 'path_hide', 'kstat', 'maps_hide']) {
                if (key in s) {
                    const v = s[key];
                    susfs[key] = typeof v === 'boolean' ? v : String(v) === 'true';
                }
            }
            setSettings('susfs', prev => ({ ...prev, ...susfs }));
            return;
        }
        const keys = ['enabled', 'path_hide', 'kstat', 'maps_hide'];
        const results = await Promise.allSettled(keys.map(k => api.configGet(`susfs.${k}`)));
        const susfs = {};
        keys.forEach((key, i) => {
            const r = results[i];
            if (r.status === 'fulfilled' && r.value !== null) {
                susfs[key] = r.value === 'true';
            }
        });
        setSettings('susfs', prev => ({ ...prev, ...susfs }));
    };
    const loadPerfSettings = async (dump) => {
        if (dump?.perf) {
            const p = dump.perf;
            const perf = {};
            if ('enabled' in p) {
                const v = p.enabled;
                perf.enabled = typeof v === 'boolean' ? v : String(v) === 'true';
            }
            setSettings('perf', prev => ({ ...prev, ...perf }));
            return;
        }
        const result = await api.configGet('perf.enabled');
        if (result !== null) {
            setSettings('perf', 'enabled', result === 'true');
        }
    };
    // Only read Android's current developer-options and USB-debugging settings.
    const loadAdbSettings = async (_dump) => {
        const [devResult, usbResult] = await Promise.allSettled([
            runShell('/system/bin/settings get global development_settings_enabled'),
            runShell('/system/bin/settings get global adb_enabled'),
        ]);
        const parseFlag = (label, r) => {
            if (r.status !== 'fulfilled') {
                console.warn(`[adb] ${label}: exec rejected`, r.reason);
                return false;
            }
            const { errno, stdout, stderr } = r.value;
            const trimmed = (stdout ?? '').trim();
            if (errno !== 0) {
                console.warn(`[adb] ${label}: errno=${errno} stderr=${stderr} stdout="${trimmed}"`);
                return false;
            }
            if (trimmed === '1' || trimmed === 'true')
                return true;
            if (trimmed === '0' || trimmed === 'null' || trimmed === '')
                return false;
            console.warn(`[adb] ${label}: unexpected stdout="${trimmed}"`);
            return trimmed.startsWith('1');
        };
        setSettings('adb', prev => ({
            ...prev,
            developer_options: parseFlag('developer_options', devResult),
            usb_debugging: parseFlag('usb_debugging', usbResult),
        }));
    };
    const loadMountSettings = async (dump) => {
        if (dump?.mount) {
            const m = dump.mount;
            const mount = {};
            if (m.storage_mode != null)
                mount.storage_mode = m.storage_mode;
            if (m.overlay_preferred != null)
                mount.overlay_preferred = typeof m.overlay_preferred === 'boolean' ? m.overlay_preferred : String(m.overlay_preferred) === 'true';
            if (m.magic_mount_fallback != null)
                mount.magic_mount_fallback = typeof m.magic_mount_fallback === 'boolean' ? m.magic_mount_fallback : String(m.magic_mount_fallback) === 'true';
            if (m.random_mount_paths != null)
                mount.random_mount_paths = typeof m.random_mount_paths === 'boolean' ? m.random_mount_paths : String(m.random_mount_paths) === 'true';
            if (m.mount_source != null)
                mount.mount_source = String(m.mount_source);
            if (m.overlay_source != null)
                mount.overlay_source = String(m.overlay_source);
            if (m.exclude_hosts_modules != null)
                mount.exclude_hosts_modules = typeof m.exclude_hosts_modules === 'boolean' ? m.exclude_hosts_modules : String(m.exclude_hosts_modules) === 'true';
            if (m.module_blacklist != null)
                mount.module_blacklist = String(m.module_blacklist);
            if (m.ext4_image_size_mb != null)
                mount.ext4_image_size_mb = typeof m.ext4_image_size_mb === 'number' ? m.ext4_image_size_mb : parseInt(String(m.ext4_image_size_mb), 10) || 0;
            if (m.restart_framework != null)
                mount.restart_framework = typeof m.restart_framework === 'boolean' ? m.restart_framework : String(m.restart_framework) === 'true';
            setSettings('mount', prev => ({ ...prev, ...mount }));
            return;
        }
        // Fallback: individual configGet calls — all in a single Promise.allSettled
        const boolKeys = [
            'overlay_preferred', 'magic_mount_fallback', 'random_mount_paths',
            'exclude_hosts_modules', 'restart_framework',
        ];
        const results = await Promise.allSettled([
            api.configGet('mount.storage_mode'),
            ...boolKeys.map(k => api.configGet(`mount.${k}`)),
            api.configGet('mount.mount_source'),
            api.configGet('mount.overlay_source'),
            api.configGet('mount.module_blacklist'),
            api.configGet('mount.ext4_image_size_mb'),
        ]);
        const mount = {};
        if (results[0].status === 'fulfilled' && results[0].value !== null) {
            mount.storage_mode = results[0].value;
        }
        boolKeys.forEach((key, i) => {
            const r = results[i + 1];
            if (r.status === 'fulfilled' && r.value !== null) {
                mount[key] = r.value === 'true';
            }
        });
        const mountSourceResult = results[boolKeys.length + 1];
        const overlaySourceResult = results[boolKeys.length + 2];
        const blacklistResult = results[boolKeys.length + 3];
        const ext4SizeResult = results[boolKeys.length + 4];
        if (mountSourceResult.status === 'fulfilled' && mountSourceResult.value !== null) {
            mount.mount_source = mountSourceResult.value;
        }
        if (overlaySourceResult.status === 'fulfilled' && overlaySourceResult.value !== null) {
            mount.overlay_source = overlaySourceResult.value;
        }
        if (blacklistResult.status === 'fulfilled' && blacklistResult.value !== null) {
            mount.module_blacklist = blacklistResult.value;
        }
        if (ext4SizeResult.status === 'fulfilled' && ext4SizeResult.value !== null) {
            mount.ext4_image_size_mb = parseInt(ext4SizeResult.value, 10) || 0;
        }
        setSettings('mount', prev => ({ ...prev, ...mount }));
    };
    const loadVerboseState = async (dump) => {
        if (dump?.logging && 'verbose' in dump.logging) {
            const v = dump.logging.verbose;
            setSettings({ verboseLogging: typeof v === 'boolean' ? v : String(v) === 'true' });
        }
        else {
            try {
                const verbose = await api.getVerboseLogging();
                setSettings({ verboseLogging: verbose });
            }
            catch (e) {
                // Non-fatal: default to false
            }
        }
        try {
            const dumpPath = await api.getVerboseDumpPath();
            setVerboseDumpPath(dumpPath);
        }
        catch (e) {
        }
    };
    const refreshBridgeValues = async () => {
        const ext = externalSusfsModule();
        if (!ext)
            return;
        const basePath = ext === 'brene'
            ? '/data/adb/brene/config.sh'
            : '/data/adb/susfs4ksu/config.sh';
        try {
            const values = await api.readAllBridgeValues(basePath);
            setBridgeValues({ module: ext, values });
        }
        catch (e) {
            console.error('[ZM-Store] refreshBridgeValues() error:', e);
        }
    };
    if (typeof window !== 'undefined') {
        document.addEventListener('visibilitychange', () => {
            if (document.visibilityState === 'visible' && externalSusfsModule()) {
                refreshBridgeValues();
            }
        });
    }
    const setMountStorageMode = async (mode) => {
        const prev = settings.mount.storage_mode;
        setSettings('mount', 'storage_mode', mode);
        try {
            await api.configSet('mount.storage_mode', mode);
            pushActivity('setting_changed', t('activity.settingChanged', { key: 'storage_mode', value: mode }));
        }
        catch (e) {
            showToast(t('toast.failedSaveStorageMode'), 'error');
            setSettings('mount', 'storage_mode', prev);
        }
    };
    const setMountToggle = async (key, value) => {
        const prev = settings.mount[key];
        setSettings('mount', key, value);
        try {
            await api.configSet(`mount.${key}`, String(value));
            pushActivity('setting_changed', t('activity.settingChanged', { key, value: value ? t('activity.on') : t('activity.off') }));
        }
        catch (e) {
            showToast(t('toast.failedSaveKey', { key }), 'error');
            setSettings('mount', key, prev);
        }
    };
    const setMountSource = async (value) => {
        const prev = settings.mount.mount_source;
        setSettings('mount', 'mount_source', value);
        try {
            await api.configSet('mount.mount_source', value);
            pushActivity('setting_changed', t('activity.settingChanged', { key: 'mount_source', value }));
        }
        catch (e) {
            showToast(t('toast.failedSaveMountSource'), 'error');
            setSettings('mount', 'mount_source', prev);
        }
    };
    const setOverlaySource = async (value) => {
        const prev = settings.mount.overlay_source;
        setSettings('mount', 'overlay_source', value);
        try {
            await api.configSet('mount.overlay_source', value);
            pushActivity('setting_changed', t('activity.settingChanged', { key: 'overlay_source', value }));
        }
        catch (e) {
            showToast(t('toast.failedSaveOverlaySource'), 'error');
            setSettings('mount', 'overlay_source', prev);
        }
    };
    const setMountField = async (key, value) => {
        const prev = settings.mount[key];
        setSettings('mount', key, value);
        try {
            await api.configSet(`mount.${key}`, String(value));
            pushActivity('setting_changed', t('activity.settingChanged', { key, value: value || t('activity.empty') }));
        }
        catch (e) {
            showToast(t('toast.failedSaveKey', { key }), 'error');
            setSettings('mount', key, prev);
        }
    };
    const setMountStrategy = async (strategy) => {
        const prevOverlay = settings.mount.overlay_preferred;
        const prevMagic = settings.mount.magic_mount_fallback;
        const mapping = {
            'Vfs': [true, true],
            'Overlay': [true, false],
            'MagicMount': [false, true],
        };
        const [newOverlay, newMagic] = mapping[strategy];
        setSettings('mount', 'overlay_preferred', newOverlay);
        setSettings('mount', 'magic_mount_fallback', newMagic);
        try {
            await Promise.all([
                api.configSet('mount.overlay_preferred', String(newOverlay)),
                api.configSet('mount.magic_mount_fallback', String(newMagic)),
            ]);
            pushActivity('mount_strategy_changed', t('activity.strategyChanged', { value: strategy }));
            showToast(t('toast.mountStrategyChanged'), 'warning');
        }
        catch (e) {
            showToast(t('toast.failedSaveMountStrategy'), 'error');
            setSettings('mount', 'overlay_preferred', prevOverlay);
            setSettings('mount', 'magic_mount_fallback', prevMagic);
        }
    };
    const activeStrategy = createMemo(() => {
        if (settings.mount.overlay_preferred && settings.mount.magic_mount_fallback)
            return 'Vfs';
        if (settings.mount.overlay_preferred && !settings.mount.magic_mount_fallback)
            return 'Overlay';
        return 'MagicMount';
    });
    const effectiveStrategy = createMemo(() => {
        const strategy = activeStrategy();
        const caps = capabilities();
        // Capabilities not loaded yet — show config-based strategy, not MagicMount fallback
        if (!caps)
            return strategy;
        if (strategy === 'Vfs' && !caps.vfs_driver) {
            return caps.overlay_supported ? 'Overlay' : 'MagicMount';
        }
        if (strategy === 'Overlay' && !caps.overlay_supported) {
            return 'MagicMount';
        }
        return strategy;
    });
    const loadRuntimeStatus = async () => {
        try {
            const status = await api.getRuntimeStatus();
            if (!status)
                return;
            batch(() => {
                const managedView = augmentManagedDroidspacesStatus(status);
                setScenario(status.scenario);
                setCapabilities(status.capabilities);
                setModuleStatuses(managedView.modules);
                setFontModules(status.font_modules || []);
                setDegraded(status.degraded);
                setDegradationReason(status.degradation_reason);
                setRootManager(status.root_manager);
                setRuntimeStrategy(status.active_strategy ?? null);
                _setMountSource(status.mount_source ?? null);
                setResolvedStorageMode(status.resolved_storage_mode ?? null);
                setEngineActive(status.engine_active ?? false);
                if (status.driver_version !== null) {
                    setSystemInfo('driverVersion', `v${status.driver_version}`);
                }
                setSystemInfo('susfsVersion', status.susfs_version || '');
                setStats({
                    activeRules: managedView.activeRules,
                    excludedUids: status.excluded_uid_count,
                    hiddenPaths: status.hidden_path_count,
                    hiddenMaps: status.hidden_maps_count ?? 0,
                });
            });
        }
        catch (e) {
            setLastApiError({ operation: 'loadRuntimeStatus', error: e, timestamp: new Date() });
        }
    };
    let lastKnownPackages = null;
    let lastTriggerTimestamp = null;
    let triggerPollInterval;
    let pollingStarted = false;
    let appFetchInProgress = false;
    const pendingUidOperations = new Set();
    const fetchAppsViaKsuApi = async () => {
        const [userPackages, systemPackages] = await Promise.all([
            listPackages('user'),
            listPackages('system'),
        ]);
        const allPackages = [...new Set([...userPackages, ...systemPackages])];
        if (allPackages.length === 0)
            return [];
        const packageInfos = await getPackagesInfo(allPackages);
        const systemSet = new Set(systemPackages);
        return packageInfos.map(info => ({
            packageName: info.packageName,
            appName: info.appLabel || info.packageName,
            uid: info.uid ?? -1,
            isSystemApp: info.isSystem ?? systemSet.has(info.packageName),
        }));
    };
    const refreshApps = async () => {
        if (appFetchInProgress)
            return;
        appFetchInProgress = true;
        try {
            const freshApps = await fetchAppsViaKsuApi();
            setInstalledApps(freshApps);
            lastKnownPackages = new Set(freshApps.map(a => a.packageName));
            // Background: fetch labels for apps where KSU cache returned null
            const seen = new Set();
            const missingLabels = freshApps.filter(a => {
                if (a.appName !== a.packageName || seen.has(a.packageName))
                    return false;
                seen.add(a.packageName);
                return true;
            });
            if (missingLabels.length > 0 && missingLabels.length < 10) {
                for (const app of missingLabels) {
                    getAppLabelViaAapt(app.packageName).then(label => {
                        if (label && label !== app.packageName) {
                            setInstalledApps(prev => prev.map(a => a.packageName === app.packageName ? { ...a, appName: label } : a));
                        }
                    }).catch(() => { });
                }
            }
        }
        finally {
            appFetchInProgress = false;
        }
    };
    const startTriggerPolling = () => {
        if (pollingStarted)
            return;
        pollingStarted = true;
        triggerPollInterval = window.setInterval(async () => {
            if (appFetchInProgress)
                return;
            try {
                const newTrigger = await api.getRefreshTrigger();
                // Trigger file doesn't exist - fall back to package count comparison
                if (newTrigger === null) {
                    if (lastKnownPackages !== null) {
                        const [userPkgs, systemPkgs] = await Promise.all([
                            listPackages('user'),
                            listPackages('system'),
                        ]);
                        const currentCount = new Set([...userPkgs, ...systemPkgs]).size;
                        const lastCount = lastKnownPackages.size;
                        if (currentCount !== lastCount) {
                            await refreshApps();
                        }
                    }
                    return;
                }
                // First poll with trigger file present - record baseline
                if (lastTriggerTimestamp === null) {
                    lastTriggerTimestamp = newTrigger;
                    return;
                }
                // Trigger changed - daemon signaled a refresh
                if (newTrigger !== lastTriggerTimestamp) {
                    lastTriggerTimestamp = newTrigger;
                    await refreshApps();
                }
            }
            catch (e) {
            }
        }, 2000);
    };
    const stopTriggerPolling = () => {
        if (triggerPollInterval) {
            clearInterval(triggerPollInterval);
            triggerPollInterval = undefined;
        }
        pollingStarted = false;
    };
    const loadInstalledApps = async () => {
        if (appFetchInProgress) {
            return;
        }
        appFetchInProgress = true;
        setLoading('apps', true);
        try {
            if (shouldUseMock()) ;
            const apps = await fetchAppsViaKsuApi();
            setInstalledApps(apps);
            // Initialize lastKnownPackages for change detection polling
            lastKnownPackages = new Set(apps.map(a => a.packageName));
            startTriggerPolling();
        }
        catch (err) {
            showToast(t('toast.failedLoadApps'), 'error');
        }
        finally {
            appFetchInProgress = false;
            setLoading('apps', false);
        }
    };
    const scanKsuModules = async () => {
        setLoading('modules', true);
        try {
            const mods = await api.scanKsuModules();
            // Guard6.9: preserve the managed Droidspaces compatibility entry
            // without running an extra shell probe from the Scan button.
            const managedActive = moduleStatuses().some(m => m.id === 'droidspaces') ||
                rules().some(r => r.source === '/data/adb/modules/meta-zeromount/.vfs-stage/droidspaces');
            setKsuModules(augmentManagedDroidspacesKsuModules(mods, managedActive));
        }
        catch (err) {
            showToast(t('toast.failedScanModules'), 'error');
        }
        finally {
            setLoading('modules', false);
        }
    };
    const loadKsuModule = async (moduleName, modulePath) => {
        if (modulePath === '/data/adb/modules/droidspaces') {
            showToast('Droidspaces is managed by ZeroMount; use Module Exclusions and reboot to change it.', 'info');
            return 0;
        }
        try {
            const count = await api.loadKsuModule(moduleName, modulePath);
            setKsuModules(prev => prev.map(m => m.path === modulePath ? { ...m, isLoaded: true } : m));
            setStats('activeRules', s => s + count);
            showToast(t('toast.moduleLoaded', { moduleName, count }), 'success');
            return count;
        }
        catch (err) {
            showToast(t('toast.failedLoadModule', { moduleName }), 'error');
            throw err;
        }
    };
    const unloadKsuModule = async (moduleName, modulePath) => {
        if (modulePath === '/data/adb/modules/droidspaces') {
            showToast('Droidspaces is managed by ZeroMount; use Module Exclusions and reboot to change it.', 'info');
            return 0;
        }
        try {
            const count = await api.unloadKsuModule(moduleName, modulePath);
            setKsuModules(prev => prev.map(m => m.path === modulePath ? { ...m, isLoaded: false } : m));
            const status = await api.getRuntimeStatus();
            if (status) {
                setModuleStatuses(status.modules);
                setFontModules(status.font_modules || []);
            }
            setStats('activeRules', s => Math.max(0, s - count));
            showToast(t('toast.moduleUnloaded', { moduleName, count }), 'success');
            return count;
        }
        catch (err) {
            showToast(t('toast.failedUnloadModule', { moduleName }), 'error');
            throw err;
        }
    };
    const setLanguage = async (code) => {
        await loadLocale(code);
        localStorage.setItem('zeromount-language', code);
        try {
            await api.configSet('ui.language', code);
        }
        catch {
            showToast(t('toast.failedSaveKey', { key: 'ui.language' }), 'error');
        }
    };
    return {
        activeTab,
        setActiveTab,
        engineActive,
        loading,
        stats,
        systemInfo,
        rules,
        excludedUids,
        activity,
        installedApps,
        ksuModules,
        scenario,
        capabilities,
        susfsMode: () => capabilities()?.susfs_mode || 'absent',
        moduleStatuses,
        fontModules,
        degraded,
        degradationReason,
        rootManager,
        runtimeStrategy,
        mountSource,
        resolvedStorageMode,
        bgOpacity,
        setBgOpacity,
        settings,
        currentTheme,
        toast,
        lastApiError,
        externalSusfsModule,
        susfsOwnership,
        bridgeValues,
        refreshBridgeValues,
        loadInitialData,
        loadInstalledApps,
        loadRuntimeStatus,
        loadBreneSettings,
        setBreneToggle,
        setBreneNumeric,
        setSusfsToggle,
        setPerfToggle,
        setEmojiToggle,
        setAdbToggle,
        setGuardToggle,
        guardStatus,
        guardAllowModule,
        guardDisallowModule,
        guardClearLockout,
        emojiConflict,
        setUnameMode,
        setUnameField,
        loadMountSettings,
        setMountStrategy,
        setMountStorageMode,
        setMountToggle,
        setMountField,
        setMountSource,
        setOverlaySource,
        activeStrategy,
        effectiveStrategy,
        scanKsuModules,
        loadKsuModule,
        unloadKsuModule,
        toggleEngine,
        excludeUid,
        includeUid,
        clearAllRules,
        updateSettings,
        fetchSystemColor,
        setVerboseLogging,
        verboseDumpPath,
        showToast,
        setLanguage,
        stopPolling: stopTriggerPolling,
    };
}
const store = createRoot(createAppStore);

var _tmpl$$b = /*#__PURE__*/template(`<nav><div class=navbar__tabs><div class=navbar__indicator>`),
  _tmpl$2$7 = /*#__PURE__*/template(`<button><span class=navbar__icon></span><span class=navbar__label>`),
  _tmpl$3$5 = /*#__PURE__*/template(`<svg width=24 height=24 viewBox="0 0 24 24"fill=currentColor><path d="M13 3h-2v10h2V3zm4.83 2.17l-1.42 1.42C17.99 7.86 19 9.81 19 12c0 3.87-3.13 7-7 7s-7-3.13-7-7c0-2.19 1.01-4.14 2.58-5.42L6.17 5.17C4.23 6.82 3 9.26 3 12c0 4.97 4.03 9 9 9s9-4.03 9-9c0-2.74-1.23-5.18-3.17-6.83z">`),
  _tmpl$4$5 = /*#__PURE__*/template(`<svg width=24 height=24 viewBox="0 0 24 24"fill=currentColor><path d="M10 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2h-8l-2-2z">`),
  _tmpl$5$4 = /*#__PURE__*/template(`<svg width=24 height=24 viewBox="0 0 24 24"fill=currentColor><path d="M3 17v2h6v-2H3zM3 5v2h10V5H3zm10 16v-2h8v-2h-8v-2h-2v6h2zM7 9v2H3v2h4v2h2V9H7zm14 4v-2H11v2h10zm-6-4h2V7h4V5h-4V3h-2v6z">`),
  _tmpl$6$3 = /*#__PURE__*/template(`<svg width=24 height=24 viewBox="0 0 24 24"fill=currentColor><path d="M19.14 12.94c.04-.31.06-.63.06-.94 0-.31-.02-.63-.06-.94l2.03-1.58c.18-.14.23-.41.12-.61l-1.92-3.32c-.12-.22-.37-.29-.59-.22l-2.39.96c-.5-.38-1.03-.7-1.62-.94l-.36-2.54c-.04-.24-.24-.41-.48-.41h-3.84c-.24 0-.43.17-.47.41l-.36 2.54c-.59.24-1.13.57-1.62.94l-2.39-.96c-.22-.08-.47 0-.59.22L2.74 8.87c-.12.21-.08.47.12.61l2.03 1.58c-.04.31-.06.63-.06.94s.02.63.06.94l-2.03 1.58c-.18.14-.23.41-.12.61l1.92 3.32c.12.22.37.29.59.22l2.39-.96c.5.38 1.03.7 1.62.94l.36 2.54c.05.24.24.41.48.41h3.84c.24 0 .44-.17.47-.41l.36-2.54c.59-.24 1.13-.56 1.62-.94l2.39.96c.22.08.47 0 .59-.22l1.92-3.32c.12-.22.07-.47-.12-.61l-2.01-1.58zM12 15.6c-1.98 0-3.6-1.62-3.6-3.6s1.62-3.6 3.6-3.6 3.6 1.62 3.6 3.6-1.62 3.6-3.6 3.6z">`);
const tabDefs = [{
  id: 'status',
  labelKey: 'nav.status',
  icon: 'power_settings_new'
}, {
  id: 'modules',
  labelKey: 'nav.modules',
  icon: 'folder'
}, {
  id: 'config',
  labelKey: 'nav.config',
  icon: 'tune'
}, {
  id: 'settings',
  labelKey: 'nav.settings',
  icon: 'settings'
}];
function NavBar(props) {
  const tabIndex = () => tabDefs.findIndex(td => td.id === props.activeTab);
  const extraPadding = () => store.settings.fixedNav;
  return (() => {
    var _el$ = _tmpl$$b(),
      _el$2 = _el$.firstChild,
      _el$3 = _el$2.firstChild;
    insert(_el$2, createComponent(For, {
      each: tabDefs,
      children: tab => (() => {
        var _el$4 = _tmpl$2$7(),
          _el$5 = _el$4.firstChild,
          _el$6 = _el$5.nextSibling;
        _el$4.$$click = () => props.onTabChange(tab.id);
        insert(_el$5, (() => {
          var _c$ = memo(() => tab.icon === 'power_settings_new');
          return () => _c$() && _tmpl$3$5();
        })(), null);
        insert(_el$5, (() => {
          var _c$2 = memo(() => tab.icon === 'folder');
          return () => _c$2() && _tmpl$4$5();
        })(), null);
        insert(_el$5, (() => {
          var _c$3 = memo(() => tab.icon === 'tune');
          return () => _c$3() && _tmpl$5$4();
        })(), null);
        insert(_el$5, (() => {
          var _c$4 = memo(() => tab.icon === 'settings');
          return () => _c$4() && _tmpl$6$3();
        })(), null);
        insert(_el$6, () => t(tab.labelKey));
        createRenderEffect(() => className(_el$4, `navbar__tab ${props.activeTab === tab.id ? 'navbar__tab--active' : ''}`));
        return _el$4;
      })()
    }), null);
    createRenderEffect(_p$ => {
      var _v$ = `navbar ${extraPadding() ? 'navbar--fixed-nav' : ''}`,
        _v$2 = tabIndex();
      _v$ !== _p$.e && className(_el$, _p$.e = _v$);
      _v$2 !== _p$.t && setStyleProperty(_el$3, "--tab-index", _p$.t = _v$2);
      return _p$;
    }, {
      e: undefined,
      t: undefined
    });
    return _el$;
  })();
}
delegateEvents(["click"]);

var _tmpl$$a = /*#__PURE__*/template(`<svg width=18 height=18 viewBox="0 0 24 24"fill=currentColor><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z">`),
  _tmpl$2$6 = /*#__PURE__*/template(`<svg width=18 height=18 viewBox="0 0 24 24"fill=currentColor><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z">`),
  _tmpl$3$4 = /*#__PURE__*/template(`<svg width=18 height=18 viewBox="0 0 24 24"fill=currentColor><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z">`),
  _tmpl$4$4 = /*#__PURE__*/template(`<svg width=18 height=18 viewBox="0 0 24 24"fill=currentColor><path d="M1 21h22L12 2 1 21zm12-3h-2v-2h2v2zm0-4h-2v-4h2v4z">`),
  _tmpl$5$3 = /*#__PURE__*/template(`<div><div></div><span style=flex:1></span><div>`);
const typeConfig = {
  success: {
    accent: () => store.currentTheme().colorSuccess,
    glow: () => store.currentTheme().colorSuccessGlow,
    glass: 'rgba(0, 214, 143, 0.08)',
    icon: () => _tmpl$$a()
  },
  error: {
    accent: () => store.currentTheme().colorError,
    glow: () => store.currentTheme().colorErrorGlow,
    glass: 'rgba(255, 61, 113, 0.08)',
    icon: () => _tmpl$2$6()
  },
  info: {
    accent: () => store.currentTheme().colorInfo,
    glow: () => store.currentTheme().colorInfoGlow,
    glass: 'rgba(0, 180, 216, 0.08)',
    icon: () => _tmpl$3$4()
  },
  warning: {
    accent: () => store.currentTheme().colorWarning,
    glow: () => store.currentTheme().colorWarningGlow,
    glass: 'rgba(255, 184, 0, 0.10)',
    icon: () => _tmpl$4$4()
  }
};
function Toast(props) {
  const [opacity, setOpacity] = createSignal(0);
  const [translateY, setTranslateY] = createSignal(20);
  const [mounted, setMounted] = createSignal(false);
  const duration = () => props.duration || 3000;
  createEffect(() => {
    if (props.visible) {
      setMounted(true);
      requestAnimationFrame(() => {
        setOpacity(1);
        setTranslateY(0);
      });
    } else {
      setOpacity(0);
      setTranslateY(8);
      setTimeout(() => setMounted(false), 1500);
    }
  });
  const cfg = () => typeConfig[props.type] || typeConfig.info;
  return createComponent(Show, {
    get when() {
      return mounted();
    },
    get children() {
      var _el$5 = _tmpl$5$3(),
        _el$6 = _el$5.firstChild,
        _el$7 = _el$6.nextSibling,
        _el$8 = _el$7.nextSibling;
      insert(_el$6, () => cfg().icon());
      insert(_el$7, () => props.message);
      createRenderEffect(_p$ => {
        var _v$ = `
          --toast-duration: ${duration()}ms;
          position: fixed;
          bottom: 100px;
          left: 50%;
          transform: translateX(-50%) translateY(${translateY()}px);
          z-index: 1000;
          display: flex;
          align-items: center;
          gap: 12px;
          padding: 14px 20px 18px;
          min-width: 280px;
          max-width: 90vw;
          border-radius: ${theme.radiusLarge};
          border: 1px solid rgba(255, 255, 255, 0.08);
          border-left: 3px solid ${cfg().accent()};
          color: #FFFFFF;
          font-family: ${theme.fontBody};
          font-size: 13px;
          font-weight: 500;
          letter-spacing: 0.01em;
          background: ${cfg().glass};
          backdrop-filter: blur(24px) saturate(1.4);
          -webkit-backdrop-filter: blur(24px) saturate(1.4);
          box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3), 0 0 24px ${cfg().glow()};
          opacity: ${opacity()};
          transition: opacity 1.5s ease, transform 0.4s cubic-bezier(0.16, 1, 0.3, 1);
          overflow: hidden;
        `,
          _v$2 = `color: ${cfg().accent()}; flex-shrink: 0; display: flex;`,
          _v$3 = `
            position: absolute;
            bottom: 0;
            left: 0;
            height: 2px;
            width: 100%;
            background: linear-gradient(90deg, ${cfg().accent()}, transparent);
            border-radius: 0 1px 1px 0;
            transform-origin: left center;
            animation: toast-progress var(--toast-duration) linear forwards;
          `;
        _p$.e = style(_el$5, _v$, _p$.e);
        _p$.t = style(_el$6, _v$2, _p$.t);
        _p$.a = style(_el$8, _v$3, _p$.a);
        return _p$;
      }, {
        e: undefined,
        t: undefined,
        a: undefined
      });
      return _el$5;
    }
  });
}

var _tmpl$$9 = /*#__PURE__*/template(`<div>`);
function Card(props) {
  const [local] = splitProps(props, ['variant', 'padding', 'hoverable', 'class', 'children', 'style', 'onClick']);
  const variant = () => local.variant || 'glass';
  const padding = () => local.padding || 'medium';
  const className$1 = () => {
    const classes = ['card'];
    classes.push(`card--${variant()}`);
    classes.push(`card--padding-${padding()}`);
    if (local.hoverable) classes.push('card--hoverable');
    if (local.class) classes.push(local.class);
    return classes.join(' ');
  };
  return (() => {
    var _el$ = _tmpl$$9();
    addEventListener(_el$, "click", local.onClick, true);
    insert(_el$, () => local.children);
    createRenderEffect(_p$ => {
      var _v$ = className$1(),
        _v$2 = local.style || undefined;
      _v$ !== _p$.e && className(_el$, _p$.e = _v$);
      _p$.t = style(_el$, _v$2, _p$.t);
      return _p$;
    }, {
      e: undefined,
      t: undefined
    });
    return _el$;
  })();
}
delegateEvents(["click"]);

var _tmpl$$8 = /*#__PURE__*/template(`<span class=button__spinner>`),
  _tmpl$2$5 = /*#__PURE__*/template(`<button>`);
function Button(props) {
  const [local] = splitProps(props, ['variant', 'size', 'loading', 'fullWidth', 'children', 'disabled', 'onClick', 'style', 'type', 'class']);
  const variant = () => local.variant || 'primary';
  const size = () => local.size || 'medium';
  const classNames = () => {
    const classes = ['button', `button--${variant()}`, `button--${size()}`];
    if (local.fullWidth) classes.push('button--full-width');
    if (local.class) classes.push(local.class);
    return classes.join(' ');
  };
  const dynamicStyles = () => {
    if (variant() === 'primary') {
      const textColor = needsDarkText(store.settings.accentColor) ? '#1A1A2E' : '#FFFFFF';
      return `color: ${textColor};`;
    }
    return '';
  };
  return (() => {
    var _el$ = _tmpl$2$5();
    addEventListener(_el$, "click", local.onClick, true);
    insert(_el$, createComponent(Show, {
      get when() {
        return local.loading;
      },
      get children() {
        return _tmpl$$8();
      }
    }), null);
    insert(_el$, createComponent(Show, {
      get when() {
        return !local.loading;
      },
      get children() {
        return local.children;
      }
    }), null);
    createRenderEffect(_p$ => {
      var _v$ = local.type || 'button',
        _v$2 = classNames(),
        _v$3 = local.loading || local.disabled,
        _v$4 = `${dynamicStyles()} ${local.style || ''}`;
      _v$ !== _p$.e && setAttribute(_el$, "type", _p$.e = _v$);
      _v$2 !== _p$.t && className(_el$, _p$.t = _v$2);
      _v$3 !== _p$.a && (_el$.disabled = _p$.a = _v$3);
      _p$.o = style(_el$, _v$4, _p$.o);
      return _p$;
    }, {
      e: undefined,
      t: undefined,
      a: undefined,
      o: undefined
    });
    return _el$;
  })();
}
delegateEvents(["click"]);

var _tmpl$$7 = /*#__PURE__*/template(`<div>`);
function Skeleton(props) {
  const styles = {
    "--skeleton-width": props.width || "100%",
    "--skeleton-height": props.height || "20px",
    "--skeleton-radius": props.borderRadius || "12px"
  };
  return (() => {
    var _el$ = _tmpl$$7();
    createRenderEffect(_p$ => {
      var _v$ = `skeleton ${props.class || ""}`,
        _v$2 = styles;
      _v$ !== _p$.e && className(_el$, _p$.e = _v$);
      _p$.t = style(_el$, _v$2, _p$.t);
      return _p$;
    }, {
      e: undefined,
      t: undefined
    });
    return _el$;
  })();
}

var _tmpl$$6 = /*#__PURE__*/template(`<div class=scenario><div class=scenario__chip><span class=scenario__dot></span><span class=scenario__label></span></div><div class=scenario__desc>`);
const strategyKeys = {
  Vfs: 'status.modeVfs',
  Overlay: 'status.modeOverlay',
  MagicMount: 'status.modeMagicMount'
};
function strategyLabel(s) {
  return t(strategyKeys[s] ?? s);
}
function strategyColor(s) {
  return s === 'Vfs' ? 'var(--color-success)' : 'var(--color-info, #3b82f6)';
}
function buildConfig(scenario, strategy, susfsEnabled, susfsMode) {
  const active = strategy || 'Vfs';
  const susfsLabel = susfsMode === 'enhanced' ? t('scenario.susfsEnhanced') : susfsMode === 'embedded' ? t('scenario.susfsEmbedded') : susfsEnabled ? t('scenario.susfsSuffix') : '';
  const name = strategyLabel(active);
  switch (scenario) {
    case 'full':
    case 'susfs_frontend':
    case 'kernel_only':
      {
        if (active === 'Vfs') {
          return {
            label: susfsEnabled ? t('scenario.fullProtection') : t('scenario.vfsActive'),
            color: 'var(--color-success)',
            description: t('scenario.descVfs', {
              susfs: susfsLabel
            })
          };
        }
        return {
          label: t('scenario.strategyActive', {
            strategy: name
          }),
          color: strategyColor(active),
          description: t('scenario.descAltVfsAvail', {
            strategy: name,
            susfs: susfsLabel
          })
        };
      }
    case 'susfs_only':
      return {
        label: t('scenario.strategyActive', {
          strategy: name
        }),
        color: strategyColor(active),
        description: t('scenario.descSusfsOnly', {
          strategy: name
        })
      };
    case 'none':
      return {
        label: t('scenario.strategyActive', {
          strategy: name
        }),
        color: strategyColor(active),
        description: t('scenario.descModuleMounts', {
          strategy: name
        })
      };
    default:
      return {
        label: t('scenario.initializing'),
        color: 'var(--color-info, #3b82f6)',
        description: t('scenario.descInitializing')
      };
  }
}
function ScenarioIndicator(props) {
  const scenario = () => store.scenario?.() || 'none';
  const activeStrategy = () => store.runtimeStrategy() || store.effectiveStrategy();
  const susfsEnabled = () => (store.capabilities?.()?.susfs_available ?? false) && store.settings.susfs.enabled;
  const susfsMode = () => store.capabilities?.()?.susfs_mode;
  const config = createMemo(() => buildConfig(scenario(), activeStrategy(), susfsEnabled(), susfsMode()));
  return (() => {
    var _el$ = _tmpl$$6(),
      _el$2 = _el$.firstChild,
      _el$3 = _el$2.firstChild,
      _el$4 = _el$3.nextSibling,
      _el$5 = _el$2.nextSibling;
    insert(_el$4, () => config().label);
    insert(_el$5, () => config().description);
    createRenderEffect(_p$ => {
      var _v$ = props.color || config().color,
        _v$2 = props.color || config().color,
        _v$3 = props.color || config().color;
      _v$ !== _p$.e && setStyleProperty(_el$2, "border-color", _p$.e = _v$);
      _v$2 !== _p$.t && setStyleProperty(_el$3, "background", _p$.t = _v$2);
      _v$3 !== _p$.a && setStyleProperty(_el$3, "color", _p$.a = _v$3);
      return _p$;
    }, {
      e: undefined,
      t: undefined,
      a: undefined
    });
    return _el$;
  })();
}

var _tmpl$$5 = /*#__PURE__*/template(`<span class=subgroup__count>`),
  _tmpl$2$4 = /*#__PURE__*/template(`<div class=subgroup__meta><svg width=24 height=24 viewBox="0 0 24 24"fill=currentColor><path d="M7 10l5 5 5-5z">`),
  _tmpl$3$3 = /*#__PURE__*/template(`<div><span class=subgroup__label>`),
  _tmpl$4$3 = /*#__PURE__*/template(`<div class=subgroup__expanded>`);
function CollapsibleSubgroup(props) {
  const [expanded, setExpanded] = createSignal(false);
  const hasExpandable = () => props.hiddenCount > 0 && props.expandedItems;
  return [(() => {
    var _el$ = _tmpl$3$3(),
      _el$2 = _el$.firstChild;
    _el$.$$click = () => hasExpandable() && setExpanded(!expanded());
    insert(_el$2, () => props.label);
    insert(_el$, createComponent(Show, {
      get when() {
        return hasExpandable();
      },
      get children() {
        var _el$3 = _tmpl$2$4(),
          _el$5 = _el$3.firstChild;
        insert(_el$3, createComponent(Show, {
          get when() {
            return !expanded();
          },
          get children() {
            var _el$4 = _tmpl$$5();
            insert(_el$4, () => t('ui.nMore', {
              count: props.hiddenCount
            }));
            return _el$4;
          }
        }), _el$5);
        createRenderEffect(() => setAttribute(_el$5, "class", `subgroup__chevron${expanded() ? ' subgroup__chevron--open' : ''}`));
        return _el$3;
      }
    }), null);
    createRenderEffect(() => className(_el$, `subgroup__header${hasExpandable() ? '' : ' subgroup__header--static'}`));
    return _el$;
  })(), memo(() => props.defaultItems), createComponent(Show, {
    get when() {
      return memo(() => !!expanded())() && hasExpandable();
    },
    get children() {
      var _el$6 = _tmpl$4$3();
      insert(_el$6, () => props.expandedItems);
      return _el$6;
    }
  })];
}
delegateEvents(["click"]);

var _tmpl$$4 = /*#__PURE__*/template(`<div role=switch tabindex=0><div><div class=toggle-thumb>`);
function Toggle(props) {
  const handleClick = () => {
    if (props.disabled) return;
    props.onChange(!props.checked);
  };
  return (() => {
    var _el$ = _tmpl$$4(),
      _el$2 = _el$.firstChild;
    _el$.$$keydown = e => {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        handleClick();
      }
    };
    _el$.$$click = handleClick;
    createRenderEffect(_p$ => {
      var _v$ = `custom-toggle${props.disabled ? ' custom-toggle--disabled' : ''}`,
        _v$2 = props.checked,
        _v$3 = `toggle-track${props.checked ? ' toggle-track--active' : ''}${props.variant === 'rainbow' ? ' toggle-track--rainbow' : ''}`;
      _v$ !== _p$.e && className(_el$, _p$.e = _v$);
      _v$2 !== _p$.t && setAttribute(_el$, "aria-checked", _p$.t = _v$2);
      _v$3 !== _p$.a && className(_el$2, _p$.a = _v$3);
      return _p$;
    }, {
      e: undefined,
      t: undefined,
      a: undefined
    });
    return _el$;
  })();
}
delegateEvents(["click", "keydown"]);

var _tmpl$$3 = /*#__PURE__*/template(`<h3 class=settings__section-title><svg class=settings__section-icon viewBox="0 0 24 24"fill=currentColor><path d="M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4zm-2 16l-4-4 1.41-1.41L10 14.17l6.59-6.59L18 9l-8 8z">`),
  _tmpl$2$3 = /*#__PURE__*/template(`<div class=guard__header><div class=guard__title-row><div class=guard__title-text><div class=settings__item-label></div><div class=settings__item-desc></div></div></div><div class=guard__controls><svg viewBox="0 0 24 24"fill=currentColor><path d="M7 10l5 5 5-5z">`),
  _tmpl$3$2 = /*#__PURE__*/template(`<div class=guard__lockout-banner><span></span><button class=guard__lockout-clear>`),
  _tmpl$4$2 = /*#__PURE__*/template(`<div class="guard__recovery settings__item-desc">`),
  _tmpl$5$2 = /*#__PURE__*/template(`<div class=guard__body><div class=guard__status-row><span></span><span class="guard__chip guard__chip--ok"></span></div><div class=settings__sub-toggles><div class="settings__item settings__item--sub"><div class=settings__item-content><div class=settings__item-label></div><div class=settings__item-desc>`),
  _tmpl$6$2 = /*#__PURE__*/template(`<div class=guard__module-list>`),
  _tmpl$7$1 = /*#__PURE__*/template(`<svg viewBox="0 0 24 24"fill=currentColor><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z">`),
  _tmpl$8$1 = /*#__PURE__*/template(`<div><div></div><div class=guard__check-label><span>`),
  _tmpl$9$1 = /*#__PURE__*/template(`<span class="guard__tag guard__tag--locked">`),
  _tmpl$0$1 = /*#__PURE__*/template(`<span class="guard__tag guard__tag--disabled">`),
  _tmpl$1$1 = /*#__PURE__*/template(`<div class=guard__threshold-list>`),
  _tmpl$10$1 = /*#__PURE__*/template(`<div class=guard__threshold-row><span class=settings__item-desc></span><input type=number class=guard__threshold-input>`);
function GuardSection() {
  const [expanded, setExpanded] = createSignal(false);
  const [modules, setModules] = createSignal([]);
  const gs = () => store.guardStatus();
  const allowed = createMemo(() => new Set(gs().allowedModules));
  const fetchModules = async () => {
    const {
      errno,
      stdout
    } = await runShell('for d in /data/adb/modules/*/; do [ -d "$d" ] || continue; n=$(basename "$d"); [ -f "$d/disable" ] && echo "1:$n" || echo "0:$n"; done');
    if (errno !== 0) return;
    const entries = stdout.trim().split('\n').filter(Boolean).map(line => {
      const disabled = line.startsWith('1:');
      const name = line.substring(2);
      return {
        name,
        disabled,
        locked: name === 'meta-zeromount'
      };
    });
    if (!entries.some(e => e.name === 'meta-zeromount')) {
      entries.unshift({
        name: 'meta-zeromount',
        disabled: false,
        locked: true
      });
    }
    entries.sort((a, b) => {
      if (a.locked !== b.locked) return a.locked ? -1 : 1;
      return a.name.localeCompare(b.name);
    });
    setModules(entries);
  };
  onMount(fetchModules);
  const protectedCount = createMemo(() => modules().filter(m => allowed().has(m.name)).length);
  const handleCheck = (name, checked) => {
    if (checked) store.guardAllowModule(name);else store.guardDisallowModule(name);
  };
  return createComponent(Card, {
    get children() {
      return [(() => {
        var _el$ = _tmpl$$3();
          _el$.firstChild;
        insert(_el$, () => t('guard.title'), null);
        return _el$;
      })(), (() => {
        var _el$3 = _tmpl$2$3(),
          _el$4 = _el$3.firstChild,
          _el$5 = _el$4.firstChild,
          _el$6 = _el$5.firstChild,
          _el$7 = _el$6.nextSibling,
          _el$8 = _el$4.nextSibling,
          _el$9 = _el$8.firstChild;
        _el$3.$$click = e => {
          if (e.target.closest('.toggle')) return;
          setExpanded(!expanded());
        };
        insert(_el$6, () => t('guard.label'));
        insert(_el$7, () => t('guard.desc'));
        insert(_el$8, createComponent(Toggle, {
          get checked() {
            return gs().enabled;
          },
          onChange: v => store.setGuardToggle('enabled', v)
        }), _el$9);
        createRenderEffect(() => setAttribute(_el$9, "class", `guard__chevron${expanded() ? ' guard__chevron--open' : ''}`));
        return _el$3;
      })(), createComponent(Show, {
        get when() {
          return expanded();
        },
        get children() {
          var _el$0 = _tmpl$5$2(),
            _el$12 = _el$0.firstChild,
            _el$13 = _el$12.firstChild,
            _el$14 = _el$13.nextSibling,
            _el$16 = _el$12.nextSibling,
            _el$17 = _el$16.firstChild,
            _el$18 = _el$17.firstChild,
            _el$19 = _el$18.firstChild,
            _el$20 = _el$19.nextSibling;
          insert(_el$0, createComponent(Show, {
            get when() {
              return gs().recoveryLockout;
            },
            get children() {
              var _el$1 = _tmpl$3$2(),
                _el$10 = _el$1.firstChild,
                _el$11 = _el$10.nextSibling;
              insert(_el$10, () => t('guard.lockoutActive'));
              _el$11.$$click = () => store.guardClearLockout();
              insert(_el$11, () => t('guard.clearLockout'));
              return _el$1;
            }
          }), _el$12);
          insert(_el$13, (() => {
            var _c$ = memo(() => !!gs().disabled);
            return () => _c$() ? t('guard.moduleDisabled') : t('guard.moduleActive');
          })());
          insert(_el$14, () => t('guard.bootcount', {
            count: gs().bootcount
          }));
          insert(_el$0, createComponent(Show, {
            get when() {
              return gs().lastRecovery;
            },
            get children() {
              var _el$15 = _tmpl$4$2();
              insert(_el$15, () => t('guard.lastRecovery', {
                date: gs().lastRecovery
              }));
              return _el$15;
            }
          }), _el$16);
          insert(_el$19, () => t('guard.systemuiMonitor'));
          insert(_el$20, () => t('guard.systemuiMonitorDesc'));
          insert(_el$17, createComponent(Toggle, {
            get checked() {
              return store.settings.guard.systemui_monitor_enabled;
            },
            onChange: v => store.setGuardToggle('systemui_monitor_enabled', v)
          }), null);
          insert(_el$0, createComponent(CollapsibleSubgroup, {
            get label() {
              return t('guard.protectedModules', {
                protected: protectedCount(),
                total: modules().length
              });
            },
            get hiddenCount() {
              return modules().length;
            },
            defaultItems: [],
            get expandedItems() {
              return (() => {
                var _el$21 = _tmpl$6$2();
                insert(_el$21, createComponent(For, {
                  get each() {
                    return modules();
                  },
                  children: mod => {
                    const checked = () => mod.locked || allowed().has(mod.name);
                    return (() => {
                      var _el$22 = _tmpl$8$1(),
                        _el$23 = _el$22.firstChild,
                        _el$25 = _el$23.nextSibling,
                        _el$26 = _el$25.firstChild;
                      _el$22.$$click = () => !mod.locked && handleCheck(mod.name, !checked());
                      insert(_el$23, createComponent(Show, {
                        get when() {
                          return checked();
                        },
                        get children() {
                          return _tmpl$7$1();
                        }
                      }));
                      insert(_el$26, () => mod.name);
                      insert(_el$25, (() => {
                        var _c$2 = memo(() => !!mod.locked);
                        return () => _c$2() && (() => {
                          var _el$27 = _tmpl$9$1();
                          insert(_el$27, () => t('guard.tagAlways'));
                          return _el$27;
                        })();
                      })(), null);
                      insert(_el$25, (() => {
                        var _c$3 = memo(() => !!mod.disabled);
                        return () => _c$3() && (() => {
                          var _el$28 = _tmpl$0$1();
                          insert(_el$28, () => t('guard.tagDisabled'));
                          return _el$28;
                        })();
                      })(), null);
                      createRenderEffect(_p$ => {
                        var _v$ = `guard__check-row${mod.locked ? ' guard__check-row--locked' : ''}`,
                          _v$2 = `guard__checkbox${checked() ? ' guard__checkbox--on' : ''}`;
                        _v$ !== _p$.e && className(_el$22, _p$.e = _v$);
                        _v$2 !== _p$.t && className(_el$23, _p$.t = _v$2);
                        return _p$;
                      }, {
                        e: undefined,
                        t: undefined
                      });
                      return _el$22;
                    })();
                  }
                }));
                return _el$21;
              })();
            }
          }), null);
          insert(_el$0, createComponent(CollapsibleSubgroup, {
            get label() {
              return t('guard.thresholds');
            },
            hiddenCount: 4,
            defaultItems: [],
            get expandedItems() {
              return (() => {
                var _el$29 = _tmpl$1$1();
                insert(_el$29, createComponent(ThresholdRow, {
                  get label() {
                    return t('guard.bootTimeout');
                  },
                  configKey: "guard.boot_timeout_secs",
                  get value() {
                    return store.settings.guard.boot_timeout_secs;
                  }
                }), null);
                insert(_el$29, createComponent(ThresholdRow, {
                  get label() {
                    return t('guard.zygoteMaxRestarts');
                  },
                  configKey: "guard.zygote_max_restarts",
                  get value() {
                    return store.settings.guard.zygote_max_restarts;
                  }
                }), null);
                insert(_el$29, createComponent(ThresholdRow, {
                  get label() {
                    return t('guard.systemuiMaxRestarts');
                  },
                  configKey: "guard.systemui_max_restarts",
                  get value() {
                    return store.settings.guard.systemui_max_restarts;
                  }
                }), null);
                insert(_el$29, createComponent(ThresholdRow, {
                  get label() {
                    return t('guard.systemuiAbsentTimeout');
                  },
                  configKey: "guard.systemui_absent_timeout_secs",
                  get value() {
                    return store.settings.guard.systemui_absent_timeout_secs;
                  }
                }), null);
                return _el$29;
              })();
            }
          }), null);
          createRenderEffect(() => className(_el$13, `guard__chip ${gs().disabled ? 'guard__chip--warn' : 'guard__chip--ok'}`));
          return _el$0;
        }
      })];
    }
  });
}
function ThresholdRow(props) {
  const handleBlur = async e => {
    const val = parseInt(e.currentTarget.value, 10);
    if (isNaN(val) || val === props.value) return;
    try {
      await api.configSet(props.configKey, String(val));
      store.showToast(`${props.label} → ${val}`, 'success');
    } catch {
      store.showToast(t('toast.failedSaveKey', {
        key: props.label
      }), 'error');
    }
  };
  return (() => {
    var _el$30 = _tmpl$10$1(),
      _el$31 = _el$30.firstChild,
      _el$32 = _el$31.nextSibling;
    insert(_el$31, () => props.label);
    _el$32.addEventListener("blur", handleBlur);
    createRenderEffect(() => _el$32.value = props.value);
    return _el$30;
  })();
}
delegateEvents(["click"]);

var _tmpl$$2 = /*#__PURE__*/template(`<h3 class=settings__section-title><svg class=settings__section-icon viewBox="0 0 24 24"fill=currentColor><path d="M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zm0 18a8 8 0 1 1 0-16 8 8 0 0 1 0 16zM8 11h8v2H8z">`),
  _tmpl$2$2 = /*#__PURE__*/template(`<div class=exclusion__header><div class=exclusion__title-row><div class=exclusion__title-text><div class=settings__item-label></div><div class=settings__item-desc></div></div></div><div class=exclusion__controls><span class="exclusion__chip exclusion__chip--ok">/</span><svg viewBox="0 0 24 24"fill=currentColor><path d="M7 10l5 5 5-5z">`),
  _tmpl$3$1 = /*#__PURE__*/template(`<div class=exclusion__body><div class=exclusion__module-list>`),
  _tmpl$4$1 = /*#__PURE__*/template(`<svg viewBox="0 0 24 24"fill=currentColor><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z">`),
  _tmpl$5$1 = /*#__PURE__*/template(`<div><div></div><div class=exclusion__check-label><span>`),
  _tmpl$6$1 = /*#__PURE__*/template(`<span class="exclusion__tag exclusion__tag--self">`);
const MODULE_ID_RE = /^[a-zA-Z][a-zA-Z0-9._-]+$/;
function ModuleExclusionsSection() {
  const [expanded, setExpanded] = createSignal(false);
  const [excluded, setExcluded] = createSignal(new Set());
  onMount(async () => {
    const csv = await api.configGet('mount.module_blacklist');
    if (csv) {
      setExcluded(new Set(csv.split(',').map(s => s.trim()).filter(Boolean)));
    }
  });
  const modules = createMemo(() => {
    const entries = store.ksuModules().map(mod => {
      const name = mod.path.split('/').pop() ?? mod.name;
      return {
        name,
        locked: name === 'meta-zeromount'
      };
    });
    if (!entries.some(e => e.name === 'meta-zeromount')) {
      entries.unshift({
        name: 'meta-zeromount',
        locked: true
      });
    }
    // Guard6.9: Droidspaces is a managed external-source VFS module. Keep it
    // selectable in Module Exclusions even though v6.5.5 has no system tree.
    if (!entries.some(e => e.name === 'droidspaces')) {
      entries.push({
        name: 'droidspaces',
        locked: false
      });
    }
    entries.sort((a, b) => {
      if (a.locked !== b.locked) return a.locked ? -1 : 1;
      return a.name.localeCompare(b.name);
    });
    return entries;
  });
  const excludedCount = createMemo(() => modules().filter(m => excluded().has(m.name)).length);
  const handleCheck = async (name, checked) => {
    if (!MODULE_ID_RE.test(name) || name.length > 256) {
      store.showToast(t('toast.failedSaveKey', {
        key: 'mount.module_blacklist'
      }), 'error');
      return;
    }
    const prev = excluded();
    const next = new Set(prev);
    if (checked) next.add(name);else next.delete(name);
    setExcluded(next);
    try {
      await api.configSet('mount.module_blacklist', [...next].join(','));
    } catch {
      setExcluded(prev);
      store.showToast(t('toast.failedSaveKey', {
        key: 'mount.module_blacklist'
      }), 'error');
    }
  };
  return createComponent(Card, {
    get children() {
      return [(() => {
        var _el$ = _tmpl$$2();
          _el$.firstChild;
        insert(_el$, () => t('exclusion.title'), null);
        return _el$;
      })(), (() => {
        var _el$3 = _tmpl$2$2(),
          _el$4 = _el$3.firstChild,
          _el$5 = _el$4.firstChild,
          _el$6 = _el$5.firstChild,
          _el$7 = _el$6.nextSibling,
          _el$8 = _el$4.nextSibling,
          _el$9 = _el$8.firstChild,
          _el$0 = _el$9.firstChild,
          _el$1 = _el$9.nextSibling;
        _el$3.$$click = () => setExpanded(!expanded());
        insert(_el$6, () => t('exclusion.label'));
        insert(_el$7, () => t('exclusion.desc'));
        insert(_el$9, excludedCount, _el$0);
        insert(_el$9, () => modules().length, null);
        createRenderEffect(() => setAttribute(_el$1, "class", `exclusion__chevron${expanded() ? ' exclusion__chevron--open' : ''}`));
        return _el$3;
      })(), createComponent(Show, {
        get when() {
          return expanded();
        },
        get children() {
          var _el$10 = _tmpl$3$1(),
            _el$11 = _el$10.firstChild;
          insert(_el$11, createComponent(For, {
            get each() {
              return modules();
            },
            children: mod => {
              const checked = () => !mod.locked && excluded().has(mod.name);
              return (() => {
                var _el$12 = _tmpl$5$1(),
                  _el$13 = _el$12.firstChild,
                  _el$15 = _el$13.nextSibling,
                  _el$16 = _el$15.firstChild;
                _el$12.$$click = () => !mod.locked && handleCheck(mod.name, !checked());
                insert(_el$13, createComponent(Show, {
                  get when() {
                    return checked();
                  },
                  get children() {
                    return _tmpl$4$1();
                  }
                }));
                insert(_el$16, () => mod.name);
                insert(_el$15, (() => {
                  var _c$ = memo(() => !!mod.locked);
                  return () => _c$() && (() => {
                    var _el$17 = _tmpl$6$1();
                    insert(_el$17, () => t('exclusion.tagSelf'));
                    return _el$17;
                  })();
                })(), null);
                createRenderEffect(_p$ => {
                  var _v$ = `exclusion__check-row${mod.locked ? ' exclusion__check-row--locked' : ''}`,
                    _v$2 = `exclusion__checkbox${checked() ? ' exclusion__checkbox--on' : ''}`;
                  _v$ !== _p$.e && className(_el$12, _p$.e = _v$);
                  _v$2 !== _p$.t && className(_el$13, _p$.t = _v$2);
                  return _p$;
                }, {
                  e: undefined,
                  t: undefined
                });
                return _el$12;
              })();
            }
          }));
          return _el$10;
        }
      })];
    }
  });
}
delegateEvents(["click"]);

var _tmpl$$1 = /*#__PURE__*/template(`<svg width=20 height=20 viewBox="0 0 24 24"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z">`),
  _tmpl$2$1 = /*#__PURE__*/template(`<svg width=20 height=20 viewBox="0 0 24 24"><path d="M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4z">`),
  _tmpl$3 = /*#__PURE__*/template(`<svg width=20 height=20 viewBox="0 0 24 24"><path d="M19.14 12.94c.04-.31.06-.63.06-.94 0-.31-.02-.63-.06-.94l2.03-1.58c.18-.14.23-.41.12-.61l-1.92-3.32c-.12-.22-.37-.29-.59-.22l-2.39.96c-.5-.38-1.03-.7-1.62-.94l-.36-2.54c-.04-.24-.24-.41-.48-.41h-3.84c-.24 0-.43.17-.47.41l-.36 2.54c-.59.24-1.13.57-1.62.94l-2.39-.96c-.22-.08-.47 0-.59.22L2.74 8.87c-.12.21-.08.47.12.61l2.03 1.58c-.04.31-.06.63-.06.94s.02.63.06.94l-2.03 1.58c-.18.14-.23.41-.12.61l1.92 3.32c.12.22.37.29.59.22l2.39-.96c.5.38 1.03.7 1.62.94l.36 2.54c.05.24.24.41.48.41h3.84c.24 0 .44-.17.47-.41l.36-2.54c.59-.24 1.13-.56 1.62-.94l2.39.96c.22.08.47 0 .59-.22l1.92-3.32c.12-.22.07-.47-.12-.61l-2.01-1.58zM12 15.6c-1.98 0-3.6-1.62-3.6-3.6s1.62-3.6 3.6-3.6 3.6 1.62 3.6 3.6-1.62 3.6-3.6 3.6z">`),
  _tmpl$4 = /*#__PURE__*/template(`<svg width=20 height=20 viewBox="0 0 24 24"><path d="M12 3c-4.97 0-9 4.03-9 9s4.03 9 9 9c.83 0 1.5-.67 1.5-1.5 0-.39-.15-.74-.39-1.01-.23-.26-.38-.61-.38-.99 0-.83.67-1.5 1.5-1.5H16c2.76 0 5-2.24 5-5 0-4.42-4.03-8-9-8z">`),
  _tmpl$5 = /*#__PURE__*/template(`<svg width=20 height=20 viewBox="0 0 24 24"><path d="M7 10l5 5 5-5z">`),
  _tmpl$6 = /*#__PURE__*/template(`<div class=status-hero><div class=status-hero__indicator><span class="status-hero__dot status-hero__dot--active"></span></div><div class="status-hero__shield status-hero__shield--active"><div class="status-hero__glow status-hero__glow--active"></div><svg width=100 height=100 viewBox="0 0 24 24"class=status-hero__shield-svg><path opacity=0.9 d="M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4zm0 10.99h7c-.53 4.12-3.28 7.79-7 8.94V12H5V6.3l7-3.11v8.8z">`),
  _tmpl$7 = /*#__PURE__*/template(`<h3 class="status-section__header color-text-secondary">`),
  _tmpl$8 = /*#__PURE__*/template(`<div class=status-stats><div class="status-stats__card bg-surface"><div class=status-stats__value></div><div class="status-stats__label color-text-tertiary"></div></div><div class="status-stats__card bg-surface"><div class=status-stats__value></div><div class="status-stats__label color-text-tertiary"></div></div><div class="status-stats__card bg-surface"><div class=status-stats__value></div><div class="status-stats__label color-text-tertiary">`),
  _tmpl$9 = /*#__PURE__*/template(`<div class=status-mode><div class=status-mode__row><div class=status-mode__label><span class=status-mode__dot></span><span class="status-mode__text color-text-primary"></span></div><span class="status-mode__value color-text-accent"></span></div><div class="status-mode__desc color-text-tertiary"></div><div class=status-mode__row><div class=status-mode__label><span class=status-mode__dot></span><span class="status-mode__text color-text-primary"></span></div><span class="status-mode__value color-text-accent"></span></div><div class="status-mode__reboot-hint color-text-tertiary"></div><div class=status-mode__row><div class=status-mode__label><span class=status-mode__dot></span><span class="status-mode__text color-text-primary"></span></div><span class="status-mode__value color-text-accent">`),
  _tmpl$0 = /*#__PURE__*/template(`<button class=status-activity__toggle><svg width=24 height=24 viewBox="0 0 24 24"fill=currentColor><path d="M7 10l5 5 5-5z">`),
  _tmpl$1 = /*#__PURE__*/template(`<div class=status-mode__modules><div class=status-mode__modules-header><div class="status-mode__modules-label color-text-tertiary">`),
  _tmpl$10 = /*#__PURE__*/template(`<div class=status-mount__cards><div class="status-mount__card bg-surface"><div class="status-mount__card-label color-text-tertiary"></div><div class="status-mount__card-value color-text-primary"></div></div><div class="status-mount__card bg-surface"><div class="status-mount__card-label color-text-tertiary"></div><div class="status-mount__card-value color-text-accent">`),
  _tmpl$11 = /*#__PURE__*/template(`<div class=status-mount__paths-header><div class="status-mount__paths-label color-text-tertiary">`),
  _tmpl$12 = /*#__PURE__*/template(`<div class=status-mount__paths>`),
  _tmpl$13 = /*#__PURE__*/template(`<div class="settings__item-desc color-text-tertiary"style=margin-bottom:12px>`),
  _tmpl$14 = /*#__PURE__*/template(`<div class=status-health__features>`),
  _tmpl$15 = /*#__PURE__*/template(`<div><div class=status-health__item-header><span class=status-health__level></span><span class="status-health__title color-text-primary"></span></div><div class="status-health__message status-health__message--warning color-text-secondary">`),
  _tmpl$16 = /*#__PURE__*/template(`<div><div class=status-health__item-header><span class=status-health__level></span><span class="status-health__title color-text-primary"></span></div><div class="status-health__message color-text-secondary">`),
  _tmpl$17 = /*#__PURE__*/template(`<div class=status-health><div><div class=status-health__item-header><span class=status-health__level></span><span class="status-health__title color-text-primary"></span></div><div class="status-health__message color-text-secondary">`),
  _tmpl$18 = /*#__PURE__*/template(`<div class=status-activity__header><h3 class="status-section__header status-activity__title color-text-secondary"></h3><button class="status-activity__toggle color-text-accent"><svg width=24 height=24 viewBox="0 0 24 24"fill=currentColor><path d="M7 10l5 5 5-5z">`),
  _tmpl$19 = /*#__PURE__*/template(`<div class=status-activity__list>`),
  _tmpl$20 = /*#__PURE__*/template(`<div><span class="status-info__label color-text-tertiary"></span><span class=color-text-accent>`),
  _tmpl$21 = /*#__PURE__*/template(`<div><span class="status-info__label color-text-tertiary"></span><span class=color-text-primary>`),
  _tmpl$22 = /*#__PURE__*/template(`<div class=status-info__grid><div><span class="status-info__label color-text-tertiary"></span><span class=color-text-primary></span></div><div><span class="status-info__label color-text-tertiary"></span><span class=color-text-primary></span></div><div><span class="status-info__label color-text-tertiary"></span><span class=color-text-accent></span></div><div><span class="status-info__label color-text-tertiary"></span><span class=color-text-primary></span></div><div><span class="status-info__label color-text-tertiary"></span><span class=color-text-accent></span></div><div><span class="status-info__label color-text-tertiary"></span><span class=color-text-accent></span></div><div><span class="status-info__label color-text-tertiary"></span><span class=color-text-accent>`),
  _tmpl$23 = /*#__PURE__*/template(`<div class=status>`),
  _tmpl$24 = /*#__PURE__*/template(`<div class=status-hero>`),
  _tmpl$25 = /*#__PURE__*/template(`<div class=status-stats><div class="status-stats__card bg-surface"></div><div class="status-stats__card bg-surface"></div><div class="status-stats__card bg-surface">`),
  _tmpl$26 = /*#__PURE__*/template(`<div class=status-mode__module-row><span class="status-mode__module-name color-text-primary"></span><div class=status-mode__module-meta><span class="badge badge--medium"></span><span class="status-mode__module-rules color-text-tertiary"> `),
  _tmpl$27 = /*#__PURE__*/template(`<div class="status-mount__empty color-text-tertiary">`),
  _tmpl$28 = /*#__PURE__*/template(`<div class="status-mount__chip bg-surface color-text-primary">`),
  _tmpl$29 = /*#__PURE__*/template(`<div class="settings__item settings__item--stacked"><div class=settings__item-label></div><div class=settings__item-desc>`),
  _tmpl$30 = /*#__PURE__*/template(`<span class="status-health__feat-chip status-health__feat-chip--active">✓ `),
  _tmpl$31 = /*#__PURE__*/template(`<div class="status-activity__item bg-surface"><div class=status-activity__icon></div><div class=status-activity__content><div class="status-activity__message color-text-primary"></div><div class="status-activity__time color-text-tertiary">`),
  _tmpl$32 = /*#__PURE__*/template(`<div class=status-info__grid><div></div><div></div><div></div><div></div><div></div><div></div><div>`);
const MODE_COLOR_POOL = ['#00BCD4', '#9C27B0', '#009688', '#4CAF50', '#FFC107', '#7C4DFF', '#FF6D00', '#26A69A'];
function pickModeColor(accentRgb) {
  const [ar, ag, ab] = accentRgb.split(',').map(s => parseInt(s.trim()));
  const far = MODE_COLOR_POOL.filter(hex => {
    const r = parseInt(hex.slice(1, 3), 16);
    const g = parseInt(hex.slice(3, 5), 16);
    const b = parseInt(hex.slice(5, 7), 16);
    return Math.sqrt((r - ar) ** 2 + (g - ag) ** 2 + (b - ab) ** 2) > 120;
  });
  const pool = far.length ? far : MODE_COLOR_POOL;
  return pool[Math.floor(Math.random() * pool.length)];
}
function StatusTab() {
  const [animatedActiveRules, setAnimatedActiveRules] = createSignal(0);
  const [animatedExcludedUids, setAnimatedExcludedUids] = createSignal(0);
  const [animatedPaths, setAnimatedPaths] = createSignal(0);
  const [animatedMaps, setAnimatedMaps] = createSignal(0);
  const [showAllActivity, setShowAllActivity] = createSignal(false);
  const [showAllModules, setShowAllModules] = createSignal(false);
  const [showAllPaths, setShowAllPaths] = createSignal(false);
  const displayStrategy = createMemo(() => {
    return store.runtimeStrategy() || store.effectiveStrategy();
  });
  const effectiveMode = createMemo(() => {
    const s = store.scenario?.() || 'none';
    if (s === 'susfs_only') return 'susfs_only';
    // Ground truth from last boot — what the pipeline actually executed
    const runtime = store.runtimeStrategy();
    if (runtime) {
      switch (runtime) {
        case 'Vfs':
          return 'vfs';
        case 'Overlay':
          return 'overlay';
        case 'MagicMount':
          return 'magicmount';
      }
    }
    // No runtime data — derive from capabilities-aware effective strategy
    switch (store.effectiveStrategy()) {
      case 'Vfs':
        return 'vfs';
      case 'Overlay':
        return 'overlay';
      case 'MagicMount':
        return 'magicmount';
      default:
        return 'magicmount';
    }
  });
  const mountModeLabel = createMemo(() => {
    switch (effectiveMode()) {
      case 'vfs':
        return t('status.modeVfs');
      case 'overlay':
        return t('status.modeOverlay');
      case 'magicmount':
        return t('status.modeMagicMount');
      case 'susfs_only':
        return t('status.modeSusfsOnly');
    }
  });
  const mountModeValue = createMemo(() => {
    const mode = effectiveMode();
    if (mode === 'susfs_only') return t('status.modeValueNoMount');
    const statuses = store.moduleStatuses();
    if (statuses.some(m => m.strategy !== 'Font')) return t('status.modeValueActive');
    const caps = store.capabilities?.();
    const modeSupported = mode === 'overlay' ? caps?.overlay_supported : mode === 'vfs' ? caps?.vfs_driver : true;
    if (!modeSupported) return t('status.modeValueUnavailable');
    return t('status.modeValueStandby');
  });
  const mountModeDescription = createMemo(() => {
    const mode = effectiveMode();
    const storage = store.settings.mount.storage_mode;
    switch (mode) {
      case 'vfs':
        return t('status.modeDescVfs');
      case 'overlay':
        return t('status.modeDescOverlay', {
          storage
        });
      case 'magicmount':
        return t('status.modeDescMagicMount', {
          storage
        });
      case 'susfs_only':
        return t('status.modeDescSusfsOnly');
    }
  });
  const [modeColor] = createSignal(pickModeColor(store.currentTheme().accentRgb));
  const isVfsMode = createMemo(() => effectiveMode() === 'vfs');
  // VFS uses ioctl engine state; mount-based modes are active when modules are mounted
  const isModuleActive = createMemo(() => {
    if (isVfsMode()) return store.engineActive();
    return store.moduleStatuses().some(m => m.strategy !== 'Font');
  });
  const heroStatusLabel = createMemo(() => {
    if (isVfsMode()) return store.engineActive() ? t('status.engineActive') : t('status.engineInactive');
    return isModuleActive() ? t('status.mountsActive') : t('status.noModulesLoaded');
  });
  onMount(() => {
    const animateNumber = (target, setter, duration = 500) => {
      const start = 0;
      const startTime = performance.now();
      const animate = currentTime => {
        const elapsed = currentTime - startTime;
        const progress = Math.min(elapsed / duration, 1);
        const eased = 1 - Math.pow(1 - progress, 3);
        setter(Math.round(start + (target - start) * eased));
        if (progress < 1) {
          requestAnimationFrame(animate);
        }
      };
      requestAnimationFrame(animate);
    };
    setTimeout(() => {
      animateNumber(store.stats.activeRules, setAnimatedActiveRules);
      animateNumber(store.stats.excludedUids, setAnimatedExcludedUids);
      animateNumber(store.stats.hiddenPaths, setAnimatedPaths);
      animateNumber(store.stats.hiddenMaps, setAnimatedMaps);
    }, 300);
  });
  const formatTimeAgo = date => {
    const seconds = Math.floor((Date.now() - date.getTime()) / 1000);
    if (seconds < 60) return t('status.timeJustNow');
    const minutes = Math.floor(seconds / 60);
    if (minutes < 60) return t('status.timeMinAgo', {
      minutes
    });
    const hours = Math.floor(minutes / 60);
    if (hours < 24) return t('status.timeHoursAgo', {
      hours
    });
    return t('status.timeDaysAgo', {
      days: Math.floor(hours / 24)
    });
  };
  const getActivityIcon = type => {
    const theme = store.currentTheme();
    switch (type) {
      case 'rule_added':
      case 'rule_removed':
        return (() => {
          var _el$ = _tmpl$$1();
          createRenderEffect(() => setAttribute(_el$, "fill", theme.colorSuccess));
          return _el$;
        })();
      case 'uid_excluded':
      case 'uid_included':
        return (() => {
          var _el$2 = _tmpl$2$1();
          createRenderEffect(() => setAttribute(_el$2, "fill", theme.colorError));
          return _el$2;
        })();
      case 'setting_changed':
      case 'brene_toggle':
      case 'susfs_toggle':
      case 'mount_strategy_changed':
        return (() => {
          var _el$3 = _tmpl$3();
          createRenderEffect(() => setAttribute(_el$3, "fill", theme.colorInfo || '#3b82f6'));
          return _el$3;
        })();
      case 'theme_changed':
        return (() => {
          var _el$4 = _tmpl$4();
          createRenderEffect(() => setAttribute(_el$4, "fill", theme.textAccent));
          return _el$4;
        })();
      default:
        return (() => {
          var _el$5 = _tmpl$5();
          createRenderEffect(() => setAttribute(_el$5, "fill", theme.colorWarning));
          return _el$5;
        })();
    }
  };
  const strategyColor = s => {
    switch (s) {
      case 'Vfs':
        return '#4CAF50';
      case 'Overlay':
        return '#26C6DA';
      case 'MagicMount':
        return '#FFA726';
      case 'Font':
        return '#CE93D8';
    }
  };
  const pathChips = createMemo(() => {
    const prefixes = new Set();
    store.rules().forEach(rule => {
      if (rule.source === '/data/adb/modules/meta-zeromount/.vfs-stage/droidspaces' &&
          (rule.target === '/bin/droidspaces' || rule.target === '/system/bin/droidspaces')) {
        prefixes.add('/system/bin/droidspaces');
        return;
      }
      const parts = rule.target.split('/').filter(Boolean);
      if (parts.length >= 2) {
        const prefix = '/' + parts[0] + '/' + parts[1];
        if (!prefix.startsWith('/[BLOCKED]')) prefixes.add(prefix);
      }
    });
    // Overlay mount paths aren't VFS rules — pull from status
    store.moduleStatuses().forEach(mod => {
      mod.mount_paths.forEach(mp => {
        const parts = mp.split('/').filter(Boolean);
        if (parts.length >= 2) prefixes.add('/' + parts[0] + '/' + parts[1]);
      });
    });
    return Array.from(prefixes).sort();
  });
  const loadedModulesCount = createMemo(() => {
    const activeIds = new Set([...store.fontModules(), ...store.moduleStatuses().map(s => s.id)]);
    store.ksuModules().forEach(m => {
      const name = m.path.split('/').pop() || '';
      if (m.isLoaded) activeIds.add(name);
    });
    return activeIds.size;
  });
  const isInitialLoad = () => store.loading.status && !store.systemInfo.driverVersion;
  return (() => {
    var _el$6 = _tmpl$23();
    insert(_el$6, createComponent(Show, {
      get when() {
        return !isInitialLoad();
      },
      get fallback() {
        return createComponent(Card, {
          variant: "gradient-border",
          padding: "large",
          get children() {
            var _el$114 = _tmpl$24();
            insert(_el$114, createComponent(Skeleton, {
              width: "120px",
              height: "24px",
              borderRadius: "12px"
            }), null);
            insert(_el$114, createComponent(Skeleton, {
              width: "100px",
              height: "100px",
              borderRadius: "50%",
              "class": "status-hero__skeleton-shield"
            }), null);
            insert(_el$114, createComponent(Skeleton, {
              width: "200px",
              height: "48px",
              borderRadius: "24px"
            }), null);
            return _el$114;
          }
        });
      },
      get children() {
        return createComponent(Card, {
          variant: "gradient-border",
          padding: "large",
          "class": "status-hero-card status-hero-card--active",
          get children() {
            var _el$7 = _tmpl$6(),
              _el$8 = _el$7.firstChild,
              _el$9 = _el$8.firstChild,
              _el$0 = _el$8.nextSibling,
              _el$1 = _el$0.firstChild,
              _el$10 = _el$1.nextSibling,
              _el$11 = _el$10.firstChild;
            insert(_el$8, heroStatusLabel, null);
            insert(_el$7, createComponent(ScenarioIndicator, {
              get color() {
                return modeColor();
              }
            }), _el$0);
            insert(_el$7, createComponent(Show, {
              get when() {
                return isVfsMode();
              },
              get children() {
                return createComponent(Button, {
                  get variant() {
                    return store.engineActive() ? 'primary' : 'secondary';
                  },
                  size: "large",
                  onClick: () => store.toggleEngine(),
                  get loading() {
                    return store.loading.engine;
                  },
                  style: "min-width: 200px;",
                  get children() {
                    return memo(() => !!store.engineActive())() ? t('status.disableEngine') : t('status.enableEngine');
                  }
                });
              }
            }), null);
            createRenderEffect(_p$ => {
              var _v$ = store.currentTheme().textOnAccent,
                _v$2 = store.currentTheme().textOnAccent,
                _v$3 = `0 0 12px rgba(${store.currentTheme().accentRgb}, 0.5)`,
                _v$4 = `radial-gradient(circle, ${modeColor()}40 0%, transparent 60%)`,
                _v$5 = store.currentTheme().textOnAccent;
              _v$ !== _p$.e && setStyleProperty(_el$8, "color", _p$.e = _v$);
              _v$2 !== _p$.t && setStyleProperty(_el$9, "background", _p$.t = _v$2);
              _v$3 !== _p$.a && setStyleProperty(_el$9, "box-shadow", _p$.a = _v$3);
              _v$4 !== _p$.o && setStyleProperty(_el$1, "background", _p$.o = _v$4);
              _v$5 !== _p$.i && setAttribute(_el$11, "fill", _p$.i = _v$5);
              return _p$;
            }, {
              e: undefined,
              t: undefined,
              a: undefined,
              o: undefined,
              i: undefined
            });
            return _el$7;
          }
        });
      }
    }), null);
    insert(_el$6, createComponent(Card, {
      get children() {
        return [(() => {
          var _el$12 = _tmpl$7();
          insert(_el$12, () => t('status.quickStats'));
          return _el$12;
        })(), createComponent(Show, {
          get when() {
            return !isInitialLoad();
          },
          get fallback() {
            return (() => {
              var _el$115 = _tmpl$25(),
                _el$116 = _el$115.firstChild,
                _el$117 = _el$116.nextSibling,
                _el$118 = _el$117.nextSibling;
              insert(_el$116, createComponent(Skeleton, {
                width: "48px",
                height: "32px",
                borderRadius: "8px"
              }), null);
              insert(_el$116, createComponent(Skeleton, {
                width: "72px",
                height: "14px",
                borderRadius: "6px"
              }), null);
              insert(_el$117, createComponent(Skeleton, {
                width: "48px",
                height: "32px",
                borderRadius: "8px"
              }), null);
              insert(_el$117, createComponent(Skeleton, {
                width: "80px",
                height: "14px",
                borderRadius: "6px"
              }), null);
              insert(_el$118, createComponent(Skeleton, {
                width: "48px",
                height: "32px",
                borderRadius: "8px"
              }), null);
              insert(_el$118, createComponent(Skeleton, {
                width: "64px",
                height: "14px",
                borderRadius: "6px"
              }), null);
              return _el$115;
            })();
          },
          get children() {
            var _el$13 = _tmpl$8(),
              _el$14 = _el$13.firstChild,
              _el$15 = _el$14.firstChild,
              _el$16 = _el$15.nextSibling,
              _el$17 = _el$14.nextSibling,
              _el$18 = _el$17.firstChild,
              _el$19 = _el$18.nextSibling,
              _el$20 = _el$17.nextSibling,
              _el$21 = _el$20.firstChild,
              _el$22 = _el$21.nextSibling;
            insert(_el$15, animatedActiveRules);
            insert(_el$16, () => t('status.activeRules'));
            insert(_el$18, animatedPaths);
            insert(_el$19, () => t('status.pathsHidden'));
            insert(_el$21, animatedMaps);
            insert(_el$22, () => t('status.mapsHidden'));
            return _el$13;
          }
        })];
      }
    }), null);
    insert(_el$6, createComponent(Card, {
      get children() {
        return [(() => {
          var _el$23 = _tmpl$7();
          insert(_el$23, () => t('status.modeStatistics'));
          return _el$23;
        })(), (() => {
          var _el$24 = _tmpl$9(),
            _el$25 = _el$24.firstChild,
            _el$26 = _el$25.firstChild,
            _el$27 = _el$26.firstChild,
            _el$28 = _el$27.nextSibling,
            _el$29 = _el$26.nextSibling,
            _el$30 = _el$25.nextSibling,
            _el$31 = _el$30.nextSibling,
            _el$32 = _el$31.firstChild,
            _el$33 = _el$32.firstChild,
            _el$34 = _el$33.nextSibling,
            _el$35 = _el$32.nextSibling,
            _el$36 = _el$31.nextSibling,
            _el$37 = _el$36.nextSibling,
            _el$38 = _el$37.firstChild,
            _el$39 = _el$38.firstChild,
            _el$40 = _el$39.nextSibling,
            _el$41 = _el$38.nextSibling;
          insert(_el$28, mountModeLabel);
          insert(_el$29, mountModeValue);
          insert(_el$30, mountModeDescription);
          insert(_el$34, () => t('status.strategy'));
          insert(_el$35, displayStrategy);
          insert(_el$36, () => t('status.switchingModeRequiresReboot'));
          insert(_el$40, () => t('status.susfs'));
          insert(_el$41, (() => {
            var _c$ = memo(() => !!store.capabilities?.()?.susfs_available);
            return () => _c$() ? `${(store.capabilities?.()?.susfs_version ?? store.systemInfo.susfsVersion) || '?'} (${store.capabilities?.()?.susfs_kstat_redirect ? t('status.susfsExtended') : t('status.susfsStock')})` : t('status.susfsUnavailable');
          })());
          createRenderEffect(_p$ => {
            var _v$6 = modeColor(),
              _v$7 = strategyColor(displayStrategy()),
              _v$8 = store.capabilities?.()?.susfs_available ? store.currentTheme().colorSuccess : store.currentTheme().colorError;
            _v$6 !== _p$.e && setStyleProperty(_el$27, "background", _p$.e = _v$6);
            _v$7 !== _p$.t && setStyleProperty(_el$33, "background", _p$.t = _v$7);
            _v$8 !== _p$.a && setStyleProperty(_el$39, "background", _p$.a = _v$8);
            return _p$;
          }, {
            e: undefined,
            t: undefined,
            a: undefined
          });
          return _el$24;
        })(), createComponent(Show, {
          get when() {
            return store.moduleStatuses().length > 0;
          },
          get children() {
            var _el$42 = _tmpl$1(),
              _el$43 = _el$42.firstChild,
              _el$44 = _el$43.firstChild;
            insert(_el$44, () => t('status.perModuleStrategy'));
            insert(_el$43, createComponent(Show, {
              get when() {
                return store.moduleStatuses().length > 3;
              },
              get children() {
                var _el$45 = _tmpl$0(),
                  _el$46 = _el$45.firstChild;
                _el$45.$$click = () => setShowAllModules(!showAllModules());
                insert(_el$45, (() => {
                  var _c$2 = memo(() => !!showAllModules());
                  return () => _c$2() ? t('status.showLess') : t('status.showMore', {
                    count: store.moduleStatuses().length - 3
                  });
                })(), _el$46);
                createRenderEffect(_p$ => {
                  var _v$9 = store.currentTheme().textAccent,
                    _v$0 = `status-activity__chevron${showAllModules() ? ' status-activity__chevron--open' : ''}`;
                  _v$9 !== _p$.e && setStyleProperty(_el$45, "color", _p$.e = _v$9);
                  _v$0 !== _p$.t && setAttribute(_el$46, "class", _p$.t = _v$0);
                  return _p$;
                }, {
                  e: undefined,
                  t: undefined
                });
                return _el$45;
              }
            }), null);
            insert(_el$42, createComponent(For, {
              get each() {
                return store.moduleStatuses().slice(0, showAllModules() ? undefined : 3);
              },
              children: mod => (() => {
                var _el$119 = _tmpl$26(),
                  _el$120 = _el$119.firstChild,
                  _el$121 = _el$120.nextSibling,
                  _el$122 = _el$121.firstChild,
                  _el$123 = _el$122.nextSibling,
                  _el$124 = _el$123.firstChild;
                insert(_el$120, () => mod.id);
                insert(_el$122, () => mod.strategy);
                insert(_el$123, () => mod.rules_applied, _el$124);
                insert(_el$123, (() => {
                  var _c$6 = memo(() => mod.strategy === 'Font');
                  return () => _c$6() ? t('status.filesUnit') : t('status.rulesUnit');
                })(), null);
                createRenderEffect(_p$ => {
                  var _v$11 = strategyColor(mod.strategy),
                    _v$12 = `0 0 12px ${strategyColor(mod.strategy)}40`;
                  _v$11 !== _p$.e && setStyleProperty(_el$122, "background", _p$.e = _v$11);
                  _v$12 !== _p$.t && setStyleProperty(_el$122, "box-shadow", _p$.t = _v$12);
                  return _p$;
                }, {
                  e: undefined,
                  t: undefined
                });
                return _el$119;
              })()
            }), null);
            return _el$42;
          }
        })];
      }
    }), null);
    insert(_el$6, createComponent(Card, {
      get children() {
        return [(() => {
          var _el$47 = _tmpl$7();
          insert(_el$47, () => t('status.mountInfo'));
          return _el$47;
        })(), (() => {
          var _el$48 = _tmpl$10(),
            _el$49 = _el$48.firstChild,
            _el$50 = _el$49.firstChild,
            _el$51 = _el$50.nextSibling,
            _el$52 = _el$49.nextSibling,
            _el$53 = _el$52.firstChild,
            _el$54 = _el$53.nextSibling;
          insert(_el$50, () => t('status.modules'));
          insert(_el$51, () => t('status.modulesActive', {
            count: loadedModulesCount()
          }));
          insert(_el$53, () => t('status.source'));
          insert(_el$54, () => {
            const runtime = store.mountSource();
            if (runtime) return runtime;
            const strategy = store.effectiveStrategy();
            if (strategy === 'Vfs') return 'VFS';
            if (strategy === 'MagicMount') return 'KSU';
            const cfg = store.settings.mount.overlay_source;
            return cfg && cfg !== 'auto' ? cfg : 'Overlay';
          });
          return _el$48;
        })(), (() => {
          var _el$55 = _tmpl$11(),
            _el$56 = _el$55.firstChild;
          insert(_el$56, () => t('status.redirectedPaths'));
          insert(_el$55, createComponent(Show, {
            get when() {
              return pathChips().length > 5;
            },
            get children() {
              var _el$57 = _tmpl$0(),
                _el$58 = _el$57.firstChild;
              _el$57.$$click = () => setShowAllPaths(!showAllPaths());
              insert(_el$57, (() => {
                var _c$3 = memo(() => !!showAllPaths());
                return () => _c$3() ? t('status.showLess') : t('status.showMore', {
                  count: pathChips().length - 5
                });
              })(), _el$58);
              createRenderEffect(_p$ => {
                var _v$1 = store.currentTheme().textAccent,
                  _v$10 = `status-activity__chevron${showAllPaths() ? ' status-activity__chevron--open' : ''}`;
                _v$1 !== _p$.e && setStyleProperty(_el$57, "color", _p$.e = _v$1);
                _v$10 !== _p$.t && setAttribute(_el$58, "class", _p$.t = _v$10);
                return _p$;
              }, {
                e: undefined,
                t: undefined
              });
              return _el$57;
            }
          }), null);
          return _el$55;
        })(), createComponent(Show, {
          get when() {
            return pathChips().length > 0;
          },
          get fallback() {
            return (() => {
              var _el$125 = _tmpl$27();
              insert(_el$125, () => t('status.noPathsRedirected'));
              return _el$125;
            })();
          },
          get children() {
            var _el$59 = _tmpl$12();
            insert(_el$59, createComponent(For, {
              get each() {
                return pathChips().slice(0, showAllPaths() ? undefined : 5);
              },
              children: path => (() => {
                var _el$126 = _tmpl$28();
                insert(_el$126, path);
                return _el$126;
              })()
            }));
            return _el$59;
          }
        })];
      }
    }), null);
    insert(_el$6, createComponent(Show, {
      get when() {
        const c = store.capabilities?.();
        return c && (!c.vfs_driver || !c.susfs_available || !c.overlay_supported || !c.susfs_kstat_redirect);
      },
      get children() {
        return createComponent(Card, {
          get children() {
            return [(() => {
              var _el$60 = _tmpl$7();
              insert(_el$60, () => t('capabilities.title'));
              return _el$60;
            })(), (() => {
              var _el$61 = _tmpl$13();
              insert(_el$61, () => t('capabilities.desc'));
              return _el$61;
            })(), createComponent(CollapsibleSubgroup, {
              get label() {
                return t('capabilities.expandLabel');
              },
              get hiddenCount() {
                const c = store.capabilities?.();
                let n = 0;
                if (!c.vfs_driver) n++;
                if (!c.susfs_available) n++;
                if (!c.overlay_supported) n++;
                if (!c.susfs_kstat_redirect && c.susfs_available) n++;
                return n;
              },
              defaultItems: [],
              get expandedItems() {
                return [createComponent(Show, {
                  get when() {
                    return !store.capabilities?.().vfs_driver;
                  },
                  get children() {
                    var _el$127 = _tmpl$29(),
                      _el$128 = _el$127.firstChild,
                      _el$129 = _el$128.nextSibling;
                    insert(_el$128, () => t('capabilities.vfsDriver'));
                    insert(_el$129, () => t('capabilities.vfsDriverDesc'));
                    return _el$127;
                  }
                }), createComponent(Show, {
                  get when() {
                    return !store.capabilities?.().susfs_available;
                  },
                  get children() {
                    var _el$130 = _tmpl$29(),
                      _el$131 = _el$130.firstChild,
                      _el$132 = _el$131.nextSibling;
                    insert(_el$131, () => t('capabilities.susfs'));
                    insert(_el$132, () => t('capabilities.susfsDesc'));
                    return _el$130;
                  }
                }), createComponent(Show, {
                  get when() {
                    return !store.capabilities?.().overlay_supported;
                  },
                  get children() {
                    var _el$133 = _tmpl$29(),
                      _el$134 = _el$133.firstChild,
                      _el$135 = _el$134.nextSibling;
                    insert(_el$134, () => t('capabilities.overlayFs'));
                    insert(_el$135, () => t('capabilities.overlayFsDesc'));
                    return _el$133;
                  }
                }), createComponent(Show, {
                  get when() {
                    return memo(() => !!store.capabilities?.().susfs_available)() && !store.capabilities?.().susfs_kstat_redirect;
                  },
                  get children() {
                    var _el$136 = _tmpl$29(),
                      _el$137 = _el$136.firstChild,
                      _el$138 = _el$137.nextSibling;
                    insert(_el$137, () => t('capabilities.kstatRedirect'));
                    insert(_el$138, () => t('capabilities.kstatRedirectDesc'));
                    return _el$136;
                  }
                })];
              }
            })];
          }
        });
      }
    }), null);
    insert(_el$6, createComponent(Card, {
      get children() {
        return [(() => {
          var _el$62 = _tmpl$7();
          insert(_el$62, () => t('status.engineStatus'));
          return _el$62;
        })(), (() => {
          var _el$63 = _tmpl$17(),
            _el$64 = _el$63.firstChild,
            _el$65 = _el$64.firstChild,
            _el$66 = _el$65.firstChild,
            _el$67 = _el$66.nextSibling,
            _el$68 = _el$65.nextSibling;
          insert(_el$66, () => t('status.levelInfo'));
          insert(_el$67, () => t('status.susfs'));
          insert(_el$68, (() => {
            var _c$4 = memo(() => !!store.settings.susfs.enabled);
            return () => _c$4() ? memo(() => !!store.capabilities?.()?.susfs_kstat_redirect)() ? t('status.healthSusfsExtendedAll') : t('status.healthSusfsActive') : memo(() => !!(store.systemInfo.susfsVersion && store.systemInfo.susfsVersion !== 'N/A'))() ? t('status.healthSusfsAvailableDisabled') : t('status.healthSusfsNotDetected');
          })());
          insert(_el$64, createComponent(Show, {
            get when() {
              return memo(() => !!store.settings.susfs.enabled)() && store.capabilities?.();
            },
            get children() {
              var _el$69 = _tmpl$14();
              insert(_el$69, () => {
                const caps = store.capabilities?.();
                if (!caps) return null;
                const features = [{
                  key: 'vfs_driver',
                  active: caps.vfs_driver
                }, {
                  key: 'kstat',
                  active: caps.susfs_kstat
                }, {
                  key: 'path',
                  active: caps.susfs_path
                }, {
                  key: 'maps',
                  active: caps.susfs_maps
                }, {
                  key: 'kstat_redirect',
                  active: caps.susfs_kstat_redirect
                }].filter(f => f.active);
                return createComponent(For, {
                  each: features,
                  children: f => (() => {
                    var _el$139 = _tmpl$30();
                      _el$139.firstChild;
                    insert(_el$139, () => f.key, null);
                    return _el$139;
                  })()
                });
              });
              return _el$69;
            }
          }), null);
          insert(_el$63, createComponent(Show, {
            get when() {
              return store.degraded();
            },
            get children() {
              var _el$70 = _tmpl$15(),
                _el$71 = _el$70.firstChild,
                _el$72 = _el$71.firstChild,
                _el$73 = _el$72.nextSibling,
                _el$74 = _el$71.nextSibling;
              insert(_el$72, () => t('status.levelWarning'));
              insert(_el$73, () => t('status.healthRuleFailures'));
              insert(_el$74, () => store.degradationReason());
              createRenderEffect(_$p => setStyleProperty(_el$72, "color", store.currentTheme().colorWarning));
              return _el$70;
            }
          }), null);
          insert(_el$63, createComponent(Show, {
            get when() {
              return store.rules().length === 0;
            },
            get children() {
              var _el$75 = _tmpl$16(),
                _el$76 = _el$75.firstChild,
                _el$77 = _el$76.firstChild,
                _el$78 = _el$77.nextSibling,
                _el$79 = _el$76.nextSibling;
              insert(_el$77, () => t('status.levelInfo'));
              insert(_el$78, () => t('status.healthRules'));
              insert(_el$79, () => t('status.healthNoRulesHint'));
              createRenderEffect(_$p => setStyleProperty(_el$77, "color", store.currentTheme().colorInfo || '#3b82f6'));
              return _el$75;
            }
          }), null);
          createRenderEffect(_$p => setStyleProperty(_el$66, "color", store.currentTheme().colorInfo || '#3b82f6'));
          return _el$63;
        })()];
      }
    }), null);
    insert(_el$6, createComponent(GuardSection, {}), null);
    insert(_el$6, createComponent(ModuleExclusionsSection, {}), null);
    insert(_el$6, createComponent(Card, {
      get children() {
        return [(() => {
          var _el$80 = _tmpl$18(),
            _el$81 = _el$80.firstChild,
            _el$82 = _el$81.nextSibling,
            _el$83 = _el$82.firstChild;
          insert(_el$81, () => t('status.recentActivity'));
          _el$82.$$click = () => setShowAllActivity(!showAllActivity());
          insert(_el$82, (() => {
            var _c$5 = memo(() => !!showAllActivity());
            return () => _c$5() ? t('status.showLess') : t('status.viewAll');
          })(), _el$83);
          createRenderEffect(() => setAttribute(_el$83, "class", `status-activity__chevron${showAllActivity() ? ' status-activity__chevron--open' : ''}`));
          return _el$80;
        })(), (() => {
          var _el$84 = _tmpl$19();
          insert(_el$84, createComponent(For, {
            get each() {
              return store.activity().slice(0, showAllActivity() ? 10 : 3);
            },
            children: (item, index) => (() => {
              var _el$142 = _tmpl$31(),
                _el$143 = _el$142.firstChild,
                _el$144 = _el$143.nextSibling,
                _el$145 = _el$144.firstChild,
                _el$146 = _el$145.nextSibling;
              insert(_el$143, () => getActivityIcon(item.type));
              insert(_el$145, () => item.message);
              insert(_el$146, () => formatTimeAgo(item.timestamp));
              createRenderEffect(_$p => setStyleProperty(_el$142, "animation", `slideInRight 0.3s ease-out ${index() * 0.1}s both`));
              return _el$142;
            })()
          }));
          return _el$84;
        })()];
      }
    }), null);
    insert(_el$6, createComponent(Card, {
      get children() {
        return [(() => {
          var _el$85 = _tmpl$7();
          insert(_el$85, () => t('status.systemInfo'));
          return _el$85;
        })(), createComponent(Show, {
          get when() {
            return !isInitialLoad();
          },
          get fallback() {
            return (() => {
              var _el$147 = _tmpl$32(),
                _el$148 = _el$147.firstChild,
                _el$149 = _el$148.nextSibling,
                _el$150 = _el$149.nextSibling,
                _el$151 = _el$150.nextSibling,
                _el$152 = _el$151.nextSibling,
                _el$153 = _el$152.nextSibling,
                _el$154 = _el$153.nextSibling;
              insert(_el$148, createComponent(Skeleton, {
                width: "140px",
                height: "16px"
              }));
              insert(_el$149, createComponent(Skeleton, {
                width: "100px",
                height: "16px"
              }));
              insert(_el$150, createComponent(Skeleton, {
                width: "90px",
                height: "16px"
              }));
              insert(_el$151, createComponent(Skeleton, {
                width: "160px",
                height: "16px"
              }));
              insert(_el$152, createComponent(Skeleton, {
                width: "80px",
                height: "16px"
              }));
              insert(_el$153, createComponent(Skeleton, {
                width: "70px",
                height: "16px"
              }));
              insert(_el$154, createComponent(Skeleton, {
                width: "100px",
                height: "16px"
              }));
              return _el$147;
            })();
          },
          get children() {
            var _el$86 = _tmpl$22(),
              _el$87 = _el$86.firstChild,
              _el$88 = _el$87.firstChild,
              _el$89 = _el$88.nextSibling,
              _el$90 = _el$87.nextSibling,
              _el$91 = _el$90.firstChild,
              _el$92 = _el$91.nextSibling,
              _el$93 = _el$90.nextSibling,
              _el$94 = _el$93.firstChild,
              _el$95 = _el$94.nextSibling,
              _el$96 = _el$93.nextSibling,
              _el$97 = _el$96.firstChild,
              _el$98 = _el$97.nextSibling,
              _el$102 = _el$96.nextSibling,
              _el$103 = _el$102.firstChild,
              _el$104 = _el$103.nextSibling,
              _el$105 = _el$102.nextSibling,
              _el$106 = _el$105.firstChild,
              _el$107 = _el$106.nextSibling,
              _el$108 = _el$105.nextSibling,
              _el$109 = _el$108.firstChild,
              _el$110 = _el$109.nextSibling;
            insert(_el$88, () => t('status.infoDevice'));
            insert(_el$89, () => store.systemInfo.deviceModel);
            insert(_el$91, () => t('status.infoAndroid'));
            insert(_el$92, () => store.systemInfo.androidVersion);
            insert(_el$94, () => t('status.infoSelinux'));
            insert(_el$95, () => store.systemInfo.selinuxStatus);
            insert(_el$97, () => t('status.infoKernel'));
            insert(_el$98, () => store.systemInfo.kernelVersion);
            insert(_el$86, createComponent(Show, {
              get when() {
                return store.systemInfo.driverVersion;
              },
              get children() {
                var _el$99 = _tmpl$20(),
                  _el$100 = _el$99.firstChild,
                  _el$101 = _el$100.nextSibling;
                insert(_el$100, () => t('status.infoDriver'));
                insert(_el$101, () => store.systemInfo.driverVersion);
                return _el$99;
              }
            }), _el$102);
            insert(_el$103, () => t('status.infoEngine'));
            insert(_el$104, () => {
              const s = store.runtimeStrategy() || store.effectiveStrategy();
              return s === 'Vfs' ? t('status.modeVfs') : s === 'Overlay' ? t('status.modeOverlay') : s === 'MagicMount' ? t('status.modeMagicMount') : t('engine.storageAuto');
            });
            insert(_el$106, () => t('status.infoSusfs'));
            insert(_el$107, () => store.systemInfo.susfsVersion);
            insert(_el$109, () => t('status.infoRoot'));
            insert(_el$110, () => store.rootManager() ?? t('status.infoRootUnknown'));
            insert(_el$86, createComponent(Show, {
              get when() {
                return store.engineActive();
              },
              get children() {
                var _el$111 = _tmpl$21(),
                  _el$112 = _el$111.firstChild,
                  _el$113 = _el$112.nextSibling;
                insert(_el$112, () => t('status.infoMisc'));
                insert(_el$113, () => t('status.infoMiscValue'));
                return _el$111;
              }
            }), null);
            return _el$86;
          }
        })];
      }
    }), null);
    return _el$6;
  })();
}
delegateEvents(["click"]);

const bgClouds = ""+new URL('bg-clouds-C6MMwpx8.webp', import.meta.url).href+"";

var _tmpl$ = /*#__PURE__*/template(`<div class=app-bg-image>`),
  _tmpl$2 = /*#__PURE__*/template(`<div class=app-content><main>`);
const ModulesTab = lazy(() => __vitePreload(() => import('./ModulesTab-DL2hno7T.js'),true              ?__vite__mapDeps([0,1,2,3,4]):void 0,import.meta.url).then(m => ({
  default: m.ModulesTab
})));
const ConfigTab = lazy(() => __vitePreload(() => import('./ConfigTab-D00TD33F.js'),true              ?__vite__mapDeps([5,1,2,3,6]):void 0,import.meta.url).then(m => ({
  default: m.ConfigTab
})));
const SettingsTab = lazy(() => __vitePreload(() => import('./SettingsTab-BXf6CWXi.js'),true              ?__vite__mapDeps([7,1,2,8]):void 0,import.meta.url).then(m => ({
  default: m.SettingsTab
})));
function App() {
  onMount(() => {
    globalThis.ksu?.enableEdgeToEdge?.(true);
    store.loadInitialData();
    document.documentElement.style.setProperty('--bg-opacity', String(store.bgOpacity()));
    // Preload remaining tabs while user views Status
    requestIdleCallback(() => {
      __vitePreload(() => import('./ModulesTab-DL2hno7T.js'),true              ?__vite__mapDeps([0,1,2,3,4]):void 0,import.meta.url);
      __vitePreload(() => import('./ConfigTab-D00TD33F.js'),true              ?__vite__mapDeps([5,1,2,3,6]):void 0,import.meta.url);
      __vitePreload(() => import('./SettingsTab-BXf6CWXi.js'),true              ?__vite__mapDeps([7,1,2,8]):void 0,import.meta.url);
    });
  });
  const wrapperBg = createMemo(() => {
    const op = store.bgOpacity();
    if (op <= 0) return store.currentTheme().bgPrimary;
    const scrim = 1 - op * 0.85;
    return `rgba(${store.currentTheme().bgBase}, ${scrim})`;
  });
  return [createComponent(Show, {
    get when() {
      return store.bgOpacity() > 0;
    },
    get children() {
      var _el$ = _tmpl$();
      createRenderEffect(_$p => style(_el$, `background-image: url(${bgClouds})`, _$p));
      return _el$;
    }
  }), (() => {
    var _el$2 = _tmpl$2(),
      _el$3 = _el$2.firstChild;
    insert(_el$2, createComponent(Header, {}), _el$3);
    insert(_el$3, createComponent(Suspense, {
      get children() {
        return createComponent(Switch, {
          get children() {
            return [createComponent(Match, {
              get when() {
                return store.activeTab() === 'status';
              },
              get children() {
                return createComponent(StatusTab, {});
              }
            }), createComponent(Match, {
              get when() {
                return store.activeTab() === 'modules';
              },
              get children() {
                return createComponent(ModulesTab, {});
              }
            }), createComponent(Match, {
              get when() {
                return store.activeTab() === 'config';
              },
              get children() {
                return createComponent(ConfigTab, {});
              }
            }), createComponent(Match, {
              get when() {
                return store.activeTab() === 'settings';
              },
              get children() {
                return createComponent(SettingsTab, {});
              }
            })];
          }
        });
      }
    }));
    insert(_el$2, createComponent(NavBar, {
      get activeTab() {
        return store.activeTab();
      },
      get onTabChange() {
        return store.setActiveTab;
      }
    }), null);
    insert(_el$2, createComponent(Show, {
      get when() {
        return store.toast();
      },
      children: toast => createComponent(Toast, {
        get message() {
          return toast().message;
        },
        get type() {
          return toast().type;
        },
        get duration() {
          return toast().duration;
        },
        visible: true
      })
    }), null);
    createRenderEffect(_p$ => {
      var _v$ = RTL_LOCALES.has(locale()) ? 'rtl' : 'ltr',
        _v$2 = `
          min-height: 100vh;
          min-height: 100dvh;
          background: ${wrapperBg()};
          color: ${store.currentTheme().textPrimary};
          font-family: ${store.currentTheme().fontBody};
          overflow-x: hidden;
        `,
        _v$3 = `
            padding-bottom: ${store.settings.fixedNav ? 'calc(100px + 48px + env(safe-area-inset-bottom))' : 'calc(100px + env(safe-area-inset-bottom))'};
          `;
      _v$ !== _p$.e && setAttribute(_el$2, "dir", _p$.e = _v$);
      _p$.t = style(_el$2, _v$2, _p$.t);
      _p$.a = style(_el$3, _v$3, _p$.a);
      return _p$;
    }, {
      e: undefined,
      t: undefined,
      a: undefined
    });
    return _el$2;
  })()];
}

const root = document.getElementById('root');
render(() => createComponent(App, {}), root);

export { PATHS as A, Button as B, Card as C, ksuWriteFile as D, invalidateCache as E, For as F, GITHUB_URL as G, LANGUAGES as L, Portal as P, Skeleton as S, Toggle as T, createMemo as a, createComponent as b, createSignal as c, Show as d, createRenderEffect as e, className as f, setAttribute as g, template as h, insert as i, createEffect as j, onCleanup as k, delegateEvents as l, memo as m, splitProps as n, onMount as o, addEventListener as p, style as q, theme as r, store as s, t, use as u, locale as v, setStyleProperty as w, CollapsibleSubgroup as x, runShell as y, escapeShellArg as z };
