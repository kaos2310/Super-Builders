import { n as splitProps, i as insert, e as createRenderEffect, f as className, h as template } from './index-G610StableDS.js';

var _tmpl$ = /*#__PURE__*/template(`<span>`);
function Badge(props) {
  const [local] = splitProps(props, ['variant', 'size', 'children']);
  const variant = () => local.variant || 'default';
  const size = () => local.size || 'medium';
  const className$1 = () => `badge badge--${size()} badge--${variant()}`;
  return (() => {
    var _el$ = _tmpl$();
    insert(_el$, () => local.children);
    createRenderEffect(() => className(_el$, className$1()));
    return _el$;
  })();
}

export { Badge as B };
