import { n as splitProps, p as addEventListener, e as createRenderEffect, f as className, g as setAttribute, h as template, l as delegateEvents } from './index-G610StableDS.js';

var _tmpl$ = /*#__PURE__*/template(`<div><div class=input__wrapper><input class=input__field>`);
function Input(props) {
  const [local] = splitProps(props, ['fullWidth', 'placeholder', 'value', 'onInput', 'onBlur', 'type', 'disabled']);
  const containerClass = () => {
    const classes = ['input'];
    if (local.fullWidth) classes.push('input--full-width');
    return classes.join(' ');
  };
  return (() => {
    var _el$ = _tmpl$(),
      _el$2 = _el$.firstChild,
      _el$3 = _el$2.firstChild;
    addEventListener(_el$3, "blur", local.onBlur);
    addEventListener(_el$3, "input", local.onInput, true);
    createRenderEffect(_p$ => {
      var _v$ = containerClass(),
        _v$2 = local.type || 'text',
        _v$3 = local.placeholder,
        _v$4 = local.disabled;
      _v$ !== _p$.e && className(_el$, _p$.e = _v$);
      _v$2 !== _p$.t && setAttribute(_el$3, "type", _p$.t = _v$2);
      _v$3 !== _p$.a && setAttribute(_el$3, "placeholder", _p$.a = _v$3);
      _v$4 !== _p$.o && (_el$3.disabled = _p$.o = _v$4);
      return _p$;
    }, {
      e: undefined,
      t: undefined,
      a: undefined,
      o: undefined
    });
    createRenderEffect(() => _el$3.value = local.value || '');
    return _el$;
  })();
}
delegateEvents(["input"]);

export { Input as I };
