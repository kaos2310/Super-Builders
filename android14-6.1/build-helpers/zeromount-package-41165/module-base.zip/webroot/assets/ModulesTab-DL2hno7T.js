import { c as createSignal, o as onMount, s as store, a as createMemo, i as insert, b as createComponent, t, B as Button, F as For, C as Card, S as Skeleton, d as Show, u as use, e as createRenderEffect, f as className, g as setAttribute, m as memo, h as template } from './index-G610StableDS.js';
import { I as Input } from './Input-BCVrpK5n.js';
import { B as Badge } from './Badge-2OSksFSs.js';

var _tmpl$ = /*#__PURE__*/template(`<div class=modules__list>`),
  _tmpl$2 = /*#__PURE__*/template(`<div class=modules__empty><svg class=modules__empty-icon width=48 height=48 viewBox="0 0 24 24"fill=currentColor><path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-7 14l-5-5 1.41-1.41L12 14.17l4.59-4.58L18 11l-6 6z"></path></svg><div class=modules__empty-title></div><div class=modules__empty-subtitle>`),
  _tmpl$3 = /*#__PURE__*/template(`<div class=modules><div class=modules__search-row><div class=modules__search-wrapper><svg class=modules__search-icon width=20 height=20 viewBox="0 0 24 24"><path d="M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z">`),
  _tmpl$4 = /*#__PURE__*/template(`<div class=modules__item-row><div class=modules__skeleton-content>`),
  _tmpl$5 = /*#__PURE__*/template(`<div class=modules__item-row><div><svg width=22 height=22 viewBox="0 0 24 24"><path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-7 14l-5-5 1.41-1.41L12 14.17l4.59-4.58L18 11l-6 6z"></path></svg></div><div class=modules__item-content><div class=modules__item-name><span></span></div><div class=modules__item-meta></div></div><svg width=24 height=24 viewBox="0 0 24 24"fill=currentColor><path d="M7 10l5 5 5-5z">`),
  _tmpl$6 = /*#__PURE__*/template(`<div class=modules__details><div class=modules__details-inner><div><div class=modules__detail-label></div><div class=modules__path-value></div></div><div><div class="modules__detail-label modules__detail-label--partitions"></div><div class=modules__partitions></div></div><div class=modules__stats-row><div><span class=modules__stat-label></span><span class=modules__stat-value></span></div><div><span class=modules__stat-label></span><span>`),
  _tmpl$7 = /*#__PURE__*/template(`<span class=modules__partition-badge>/`);
const theme = () => store.currentTheme();
function ModulesTab() {
  const [searchQuery, setSearchQuery] = createSignal('');
  const [expandedModule, setExpandedModule] = createSignal(null);
  const [loadingModules, setLoadingModules] = createSignal(new Set());
  onMount(() => {
    if (store.ksuModules().length === 0) {
      store.scanKsuModules();
    }
  });
  const fontModulesSet = createMemo(() => new Set(store.fontModules()));
  const moduleStatusMap = createMemo(() => new Map(store.moduleStatuses().map(s => [s.id, s])));
  const isFontModule = mod => {
    const name = mod.path.split('/').pop() || '';
    return fontModulesSet().has(name);
  };
  const getModuleStatus = mod => {
    const name = mod.path.split('/').pop() || '';
    return moduleStatusMap().get(name);
  };
  const isEffectivelyLoaded = mod => mod.isLoaded || isFontModule(mod) || !!getModuleStatus(mod);
  const badgeInfo = mod => {
    if (!isEffectivelyLoaded(mod)) return {
      text: t('modules.notLoaded'),
      variant: 'default'
    };
    if (isFontModule(mod)) return {
      text: t('modules.font'),
      variant: 'accent'
    };
    const status = getModuleStatus(mod);
    if (status?.strategy === 'Overlay') return {
      text: t('modules.overlay'),
      variant: 'success'
    };
    if (status?.strategy === 'MagicMount') return {
      text: t('modules.magic'),
      variant: 'success'
    };
    return {
      text: t('modules.loaded'),
      variant: 'success'
    };
  };
  const filteredModules = createMemo(() => {
    const query = searchQuery().toLowerCase();
    if (!query) return store.ksuModules();
    return store.ksuModules().filter(mod => mod.name.toLowerCase().includes(query) || mod.path.toLowerCase().includes(query));
  });
  const handleToggleModule = async mod => {
    setLoadingModules(prev => {
      const loading = new Set(prev);
      loading.add(mod.path);
      return loading;
    });
    try {
      if (isEffectivelyLoaded(mod)) {
        await store.unloadKsuModule(mod.name, mod.path);
      } else {
        await store.loadKsuModule(mod.name, mod.path);
      }
    } finally {
      setLoadingModules(prev => {
        const updated = new Set(prev);
        updated.delete(mod.path);
        return updated;
      });
    }
  };
  const isModuleLoading = path => loadingModules().has(path);
  const getPartitionBadges = mod => {
    const badges = [];
    if (mod.hasSystem) badges.push('system');
    if (mod.hasVendor) badges.push('vendor');
    if (mod.hasProduct) badges.push('product');
    return badges;
  };
  return (() => {
    var _el$ = _tmpl$3(),
      _el$2 = _el$.firstChild,
      _el$3 = _el$2.firstChild,
      _el$4 = _el$3.firstChild;
    insert(_el$3, createComponent(Input, {
      get placeholder() {
        return t('modules.searchPlaceholder');
      },
      get value() {
        return searchQuery();
      },
      onInput: e => setSearchQuery(e.currentTarget.value),
      fullWidth: true
    }), _el$4);
    insert(_el$2, createComponent(Button, {
      onClick: () => store.scanKsuModules(),
      get loading() {
        return store.loading.modules;
      },
      style: "white-space: nowrap;",
      get children() {
        return t('modules.scan');
      }
    }), null);
    insert(_el$, createComponent(Show, {
      get when() {
        return store.loading.modules;
      },
      get children() {
        var _el$5 = _tmpl$();
        insert(_el$5, createComponent(For, {
          each: [1, 2, 3],
          children: () => createComponent(Card, {
            get children() {
              var _el$1 = _tmpl$4(),
                _el$10 = _el$1.firstChild;
              insert(_el$1, createComponent(Skeleton, {
                width: "44px",
                height: "44px",
                borderRadius: "12px"
              }), _el$10);
              insert(_el$10, createComponent(Skeleton, {
                width: "140px",
                height: "18px",
                borderRadius: "8px"
              }), null);
              insert(_el$10, createComponent(Skeleton, {
                width: "80px",
                height: "14px",
                borderRadius: "6px"
              }), null);
              insert(_el$1, createComponent(Skeleton, {
                width: "72px",
                height: "24px",
                borderRadius: "12px"
              }), null);
              return _el$1;
            }
          })
        }));
        return _el$5;
      }
    }), null);
    insert(_el$, createComponent(Show, {
      get when() {
        return !store.loading.modules;
      },
      get children() {
        var _el$6 = _tmpl$();
        insert(_el$6, createComponent(For, {
          get each() {
            return filteredModules();
          },
          children: (mod, index) => createComponent(Card, {
            hoverable: true,
            get style() {
              return `animation: slideInRight 0.3s ease-out ${index() * 0.05}s both; cursor: pointer;`;
            },
            onClick: () => setExpandedModule(expandedModule() === mod.path ? null : mod.path),
            get children() {
              return [(() => {
                var _el$11 = _tmpl$5(),
                  _el$12 = _el$11.firstChild,
                  _el$13 = _el$12.firstChild,
                  _el$14 = _el$12.nextSibling,
                  _el$15 = _el$14.firstChild,
                  _el$16 = _el$15.firstChild,
                  _el$17 = _el$15.nextSibling,
                  _el$18 = _el$14.nextSibling;
                use(el => {
                  requestAnimationFrame(() => {
                    if (el.scrollWidth > el.clientWidth) {
                      el.style.setProperty('--scroll-distance', `-${el.scrollWidth - el.clientWidth + 12}px`);
                      el.classList.add('modules__item-name--scrolling');
                    }
                  });
                }, _el$15);
                insert(_el$16, () => mod.name);
                insert(_el$17, () => t('modules.filesCount', {
                  count: mod.fileCount
                }));
                insert(_el$11, createComponent(Badge, {
                  get variant() {
                    return badgeInfo(mod).variant;
                  },
                  size: "small",
                  get children() {
                    return badgeInfo(mod).text;
                  }
                }), _el$18);
                createRenderEffect(_p$ => {
                  var _v$ = `modules__item-icon ${isEffectivelyLoaded(mod) ? 'modules__item-icon--active' : 'modules__item-icon--inactive'}`,
                    _v$2 = isEffectivelyLoaded(mod) ? 'white' : theme().textTertiary,
                    _v$3 = `modules__chevron ${expandedModule() === mod.path ? 'modules__chevron--expanded' : ''}`;
                  _v$ !== _p$.e && className(_el$12, _p$.e = _v$);
                  _v$2 !== _p$.t && setAttribute(_el$13, "fill", _p$.t = _v$2);
                  _v$3 !== _p$.a && setAttribute(_el$18, "class", _p$.a = _v$3);
                  return _p$;
                }, {
                  e: undefined,
                  t: undefined,
                  a: undefined
                });
                return _el$11;
              })(), createComponent(Show, {
                get when() {
                  return expandedModule() === mod.path;
                },
                get children() {
                  var _el$19 = _tmpl$6(),
                    _el$20 = _el$19.firstChild,
                    _el$21 = _el$20.firstChild,
                    _el$22 = _el$21.firstChild,
                    _el$23 = _el$22.nextSibling,
                    _el$24 = _el$21.nextSibling,
                    _el$25 = _el$24.firstChild,
                    _el$26 = _el$25.nextSibling,
                    _el$27 = _el$24.nextSibling,
                    _el$28 = _el$27.firstChild,
                    _el$29 = _el$28.firstChild,
                    _el$30 = _el$29.nextSibling,
                    _el$31 = _el$28.nextSibling,
                    _el$32 = _el$31.firstChild,
                    _el$33 = _el$32.nextSibling;
                  insert(_el$22, () => t('modules.path'));
                  insert(_el$23, () => mod.path);
                  insert(_el$25, () => t('modules.partitions'));
                  insert(_el$26, createComponent(For, {
                    get each() {
                      return getPartitionBadges(mod);
                    },
                    children: partition => (() => {
                      var _el$34 = _tmpl$7();
                        _el$34.firstChild;
                      insert(_el$34, partition, null);
                      return _el$34;
                    })()
                  }));
                  insert(_el$29, () => t('modules.files'));
                  insert(_el$30, () => mod.fileCount.toLocaleString());
                  insert(_el$32, () => t('modules.status'));
                  insert(_el$33, (() => {
                    var _c$3 = memo(() => !!isEffectivelyLoaded(mod));
                    return () => _c$3() ? t('modules.detailActive') : t('modules.detailInactive');
                  })());
                  insert(_el$20, createComponent(Button, {
                    get variant() {
                      return isEffectivelyLoaded(mod) ? 'danger' : 'primary';
                    },
                    size: "small",
                    get loading() {
                      return isModuleLoading(mod.path);
                    },
                    onClick: e => {
                      e.stopPropagation();
                      handleToggleModule(mod);
                    },
                    style: "margin-top: 8px;",
                    get children() {
                      return memo(() => !!isEffectivelyLoaded(mod))() ? t('modules.hotUnload') : t('modules.hotLoad');
                    }
                  }), null);
                  createRenderEffect(() => className(_el$33, `modules__stat-value ${isEffectivelyLoaded(mod) ? 'modules__stat-value--active' : 'modules__stat-value--inactive'}`));
                  return _el$19;
                }
              })];
            }
          })
        }), null);
        insert(_el$6, createComponent(Show, {
          get when() {
            return memo(() => filteredModules().length === 0)() && !store.loading.modules;
          },
          get children() {
            var _el$7 = _tmpl$2(),
              _el$8 = _el$7.firstChild,
              _el$9 = _el$8.nextSibling,
              _el$0 = _el$9.nextSibling;
            insert(_el$9, (() => {
              var _c$ = memo(() => !!searchQuery());
              return () => _c$() ? t('modules.emptyNoMatch') : t('modules.emptyNoModules');
            })());
            insert(_el$0, (() => {
              var _c$2 = memo(() => !!searchQuery());
              return () => _c$2() ? t('modules.emptyHintSearch') : t('modules.emptyHintInstall');
            })());
            return _el$7;
          }
        }), null);
        return _el$6;
      }
    }), null);
    createRenderEffect(() => setAttribute(_el$4, "fill", theme().textTertiary));
    return _el$;
  })();
}

export { ModulesTab };
