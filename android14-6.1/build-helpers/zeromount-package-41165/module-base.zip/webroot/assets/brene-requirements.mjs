// UI explanation only. The existing backend guards remain authoritative.
export function storageFilterRequirements({breneEnabled, susfsEnabled, pathHideEnabled, susfsAvailable, ownership}) {
  const missing = [];
  if (!breneEnabled) missing.push('BRENE-Freigabe einschalten');
  if (!susfsAvailable) missing.push('SuSFS-Unterstützung im Kernel erforderlich');
  if (!susfsEnabled) missing.push('ZeroMount „SUSFS Integration“ einschalten');
  else if (susfsAvailable && ownership !== 'embedded_active') missing.push('ZeroMount als aktiven SuSFS-Verwalter freigeben');
  if (!pathHideEnabled) missing.push('„Path Hiding“ einschalten');
  return missing;
}

export function storageFilterHint(state) {
  const missing = storageFilterRequirements(state);
  if (!missing.length) return '';
  let hint = `Fehlt zum Aktivieren: ${missing.join(' · ')}.`;
  if (!state.susfsEnabled || state.ownership === 'deferred_external') {
    hint += ' Bei aktivem ReSuSFS bleibt ZeroMount-SuSFS gegen parallele Verwaltung gesperrt.';
  }
  return hint;
}

export async function readLiveRequirementState(api) {
  const dump = await api.configDump();
  for (const value of [dump?.brene?.enabled, dump?.susfs?.enabled, dump?.susfs?.path_hide, dump?.brene?.hide_nonstandard_sdcard]) {
    if (typeof value !== 'boolean') throw new Error('Aktueller BRENE-/SuSFS-Schalterstatus konnte nicht gelesen werden.');
  }
  return dump;
}
