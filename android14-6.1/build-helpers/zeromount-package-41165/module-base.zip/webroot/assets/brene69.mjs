// Additive UI: the existing Guard6.10 application assets are never rewritten.
export const KEYS = Object.freeze([
  'spoof_os_security_patch_level_property',
  'spoof_vendor_security_patch_level_property',
  'extended_lock_properties',
]);
const BIN = '/data/adb/modules/meta-zeromount/bin/zm';
export const STATUS_COMMAND = `${BIN} brene-status`;
const LABELS = [
  ['System-Patchdatum', 'Mit aktivem Play Integrity Fix: dessen Patchdatum; sonst aktueller Monat, Tag 01'],
  ['Vendor-Patchdatum', 'Mit aktivem Play Integrity Fix: dessen Patchdatum; sonst aktueller Monat, Tag 05'],
  ['Zusätzliche BRENE-69-Lock-Properties', 'ro.secureboot.devicelock → 1; ro.oem_unlock_supported → 0'],
];
export function saveCommand(key, value) {
  if (!KEYS.includes(key) || typeof value !== 'boolean') throw new Error('Ungültige Einstellung');
  return `${BIN} config set brene.${key} ${value ? 'true' : 'false'}`;
}
export function formatReport(report) {
  const s = report.susfs ?? {};
  const uid = report.uid_gated_hiding ?? {};
  const states = {enabled: 'aktiviert', disabled: 'deaktiviert', not_listed: 'nicht in Kernel-Konfiguration vorhanden', unavailable: 'nicht lesbar'};
  const m = report.suspicious_mounts ?? {};
  return {
    kernel: [`Kernel: ${report.kernel_release ?? 'nicht lesbar'}`,
      `SUSFS: ${s.kernel_reported_version ?? 'unbekannt'} / ${s.variant ?? 'unbekannt'}`,
      `Aktivierte Features: ${s.enabled_count ?? 'unbekannt'}`,
      ...(s.features ?? []),
      ...(s.error || s.feature_error ? [`Abfragefehler: ${s.error ?? s.feature_error}`] : []),
      '', `UID_GATED_HIDING: ${states[uid.kernel_config] ?? 'unbekannt'}`,
      'Kernel-Buildoption, kein bestätigter Laufzeit-Schalter.',
      `Monat: ${report.current_month ?? 'ungültig/nicht verfügbar – Datumsänderung wird übersprungen'}`,
      `Datumsquelle: ${report.patch_date_policy?.source ?? 'nicht abgefragt'}`,
      `Ziel System: ${report.patch_date_policy?.os_target ?? 'nicht verfügbar'}; Vendor: ${report.patch_date_policy?.vendor_target ?? 'nicht verfügbar'}`,
      'Diese Angaben installieren keine Sicherheitsupdates.' ].join('\n'),
    peers: (report.peers ?? []).map(p => `${p.id}: ${p.state}${p.potential_writer_conflict ? ' – möglicher konkurrierender Writer' : ''}`).join('\n') || 'Keine Daten verfügbar.',
    mounts: m.error ? `Nicht lesbar: ${m.error}` : Number.isInteger(m.count) ? `${m.count}${m.count > 0 ? '\n' + (m.paths ?? []).join('\n') : ''}` : 'Nicht abgefragt.',
  };
}

// KernelSU WebView's documented callback-shaped bridge, as shipped in the input.
let callbackId = 0;
export function execReadOrSave(command, scope = globalThis) {
  return new Promise((resolve, reject) => {
    if (typeof scope.ksu?.exec !== 'function') { reject(new Error('Root-Manager-WebView erforderlich')); return; }
    const name = `zm_brene69_${Date.now()}_${callbackId++}`;
    const cleanup = () => { clearTimeout(timer); delete scope[name]; };
    const timer = setTimeout(() => { cleanup(); reject(new Error('Abfrage-Zeitlimit; Status erneut lesen')); }, 15000);
    scope[name] = (errno, stdout, stderr) => {
      cleanup();
      if (Number(errno) !== 0) reject(new Error(String(stderr || `Exit ${errno}`)));
      else resolve(String(stdout));
    };
    try { scope.ksu.exec(command, '{}', name); } catch (error) { cleanup(); reject(error); }
  });
}

export function start(doc, scope = globalThis, exec = execReadOrSave) {
  const byId = id => doc.getElementById(id);
  const inputs = new Map();
  const message = text => { byId('message').textContent = text; };
  let pending = false;
  function disableAll(value) {
    byId('refresh').disabled = value;
    for (const input of inputs.values()) input.disabled = value;
  }
  function applySettings(report) {
    const settings = report.settings;
    if (settings?.error || !settings?.values) throw new Error(settings?.error || 'Konfiguration nicht lesbar');
    // Validate the entire response before enabling any mutation controls.
    for (const key of KEYS) if (!['true', 'false'].includes(settings.values[key])) throw new Error(`Ungültiger Wert: ${key}`);
    for (const key of KEYS) inputs.get(key).checked = settings.values[key] === 'true';
  }
  async function refresh() {
    if (pending) return;
    pending = true; disableAll(true); message('Lese Status …');
    try {
      const report = JSON.parse(await exec(STATUS_COMMAND, scope));
      const display = formatReport(report);
      for (const key of ['kernel', 'peers', 'mounts']) byId(key).textContent = display[key];
      applySettings(report); disableAll(false); message('Status gelesen. Keine Geräteeinstellungen verändert.');
    } catch (e) { message(`Fehler: ${e.message}`); byId('refresh').disabled = false; }
    finally { pending = false; }
  }
  for (const [i, key] of KEYS.entries()) {
    const label = doc.createElement('label');
    const input = doc.createElement('input'); input.type = 'checkbox'; input.disabled = true; input.id = key;
    const text = doc.createElement('span'); text.textContent = LABELS[i][0];
    const description = doc.createElement('small'); description.textContent = LABELS[i][1]; text.append(description);
    label.append(input, text); byId('settings').append(label); inputs.set(key, input);
    input.addEventListener('change', async () => {
      if (pending) return;
      const desired = input.checked;
      if (!scope.confirm(`${LABELS[i][0]} ${desired ? 'aktivieren' : 'deaktivieren'}? Nur Konfiguration speichern; Anwendung ab nächstem Boot.`)) { input.checked = !desired; return; }
      pending = true; disableAll(true);
      try {
        await exec(saveCommand(key, desired), scope);
        const report = JSON.parse(await exec(STATUS_COMMAND, scope));
        applySettings(report);
        if (inputs.get(key).checked !== desired) throw new Error('Gespeicherter Wert stimmt nicht überein');
        disableAll(false); message('Gespeichert und zurückgelesen. Kein Neustart ausgelöst.');
      } catch (e) {
        message(`Speicherstatus unklar: ${e.message}. Status neu lesen.`); byId('refresh').disabled = false;
      } finally { pending = false; }
    });
  }
  byId('refresh').addEventListener('click', refresh);
  return refresh();
}
if (typeof document !== 'undefined') start(document);
