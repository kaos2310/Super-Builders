import { storageFilterHint } from './brene-requirements.mjs';
import { c as createSignal, j as createEffect, k as onCleanup, b as createComponent, p as addEventListener, e as createRenderEffect, q as style, i as insert, r as theme, s as store, d as Show, h as template, l as delegateEvents, P as Portal, f as className, F as For, t, u as use, g as setAttribute, m as memo, v as locale, L as LANGUAGES, w as setStyleProperty, T as Toggle, C as Card, x as CollapsibleSubgroup, B as Button, y as runShell, z as escapeShellArg, A as PATHS, G as GITHUB_URL, D as ksuWriteFile, E as invalidateCache } from './index-G610StableDS.js';
import { I as Input } from './Input-BCVrpK5n.js';

var _tmpl$$9 = /*#__PURE__*/template(`<div>`),
  _tmpl$2$9 = /*#__PURE__*/template(`<div><div></div><h2>`);
function Modal(props) {
  const [visible, setVisible] = createSignal(false);
  const [translateY, setTranslateY] = createSignal(100);
  const [backdropOpacity, setBackdropOpacity] = createSignal(0);
  createEffect(() => {
    if (props.open) {
      setVisible(true);
      setTimeout(() => {
        setTranslateY(0);
        setBackdropOpacity(1);
      }, 10);
      const handleKeyDown = e => {
        if (e.key === 'Escape') {
          props.onClose();
        }
      };
      document.addEventListener('keydown', handleKeyDown);
      onCleanup(() => document.removeEventListener('keydown', handleKeyDown));
    } else {
      setTranslateY(100);
      setBackdropOpacity(0);
      setTimeout(() => setVisible(false), 300);
    }
  });
  return createComponent(Show, {
    get when() {
      return visible();
    },
    get children() {
      return [(() => {
        var _el$ = _tmpl$$9();
        addEventListener(_el$, "click", props.onClose, true);
        createRenderEffect(_$p => style(_el$, `
          position: fixed;
          inset: 0;
          background: rgba(0, 0, 0, 0.6);
          backdrop-filter: blur(4px);
          -webkit-backdrop-filter: blur(4px);
          z-index: 200;
          opacity: ${backdropOpacity()};
          transition: opacity 0.3s ease;
        `, _$p));
        return _el$;
      })(), (() => {
        var _el$2 = _tmpl$2$9(),
          _el$3 = _el$2.firstChild,
          _el$4 = _el$3.nextSibling;
        insert(_el$4, () => props.title);
        insert(_el$2, () => props.children, null);
        createRenderEffect(_p$ => {
          var _v$ = `
          position: fixed;
          bottom: 0;
          left: 0;
          right: 0;
          background: ${store.currentTheme().gradientSecondary};
          border-top-left-radius: ${theme.radiusXLarge};
          border-top-right-radius: ${theme.radiusXLarge};
          padding: 24px 20px;
          padding-bottom: calc(24px + env(safe-area-inset-bottom));
          z-index: 201;
          max-height: 85vh;
          overflow-y: auto;
          transform: translateY(${translateY()}%);
          transition: transform 0.3s cubic-bezier(0.34, 1.56, 0.64, 1);
        `,
            _v$2 = `
            width: 40px;
            height: 4px;
            background: ${store.currentTheme().textTertiary};
            border-radius: 2px;
            margin: 0 auto 20px;
          `,
            _v$3 = `
            font-family: ${theme.fontDisplay};
            font-size: 24px;
            font-weight: 700;
            text-align: center;
            background: ${store.currentTheme().gradientPrimary};
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            margin: 0 0 24px;
          `;
          _p$.e = style(_el$2, _v$, _p$.e);
          _p$.t = style(_el$3, _v$2, _p$.t);
          _p$.a = style(_el$4, _v$3, _p$.a);
          return _p$;
        }, {
          e: undefined,
          t: undefined,
          a: undefined
        });
        return _el$2;
      })()];
    }
  });
}
delegateEvents(["click"]);

var _tmpl$$8 = /*#__PURE__*/template(`<div>`),
  _tmpl$2$8 = /*#__PURE__*/template(`<div class=sheet__options>`),
  _tmpl$3$6 = /*#__PURE__*/template(`<button class=sheet__back><svg width=16 height=16 viewBox="0 0 24 24"fill=currentColor><path d="M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z">`),
  _tmpl$4$5 = /*#__PURE__*/template(`<div class=sheet__custom><input class=sheet__custom-input type=text><button class=sheet__custom-confirm><svg width=20 height=20 viewBox="0 0 24 24"fill=currentColor><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z">`),
  _tmpl$5$4 = /*#__PURE__*/template(`<div><div class=sheet__handle></div><div class=sheet__title>`),
  _tmpl$6$4 = /*#__PURE__*/template(`<div class=sheet__option-icon>`),
  _tmpl$7$4 = /*#__PURE__*/template(`<div class=sheet__option-desc>`),
  _tmpl$8$4 = /*#__PURE__*/template(`<button><div class=sheet__option-content><div class=sheet__option-label></div></div><div><svg viewBox="0 0 24 24"fill=none stroke=currentColor stroke-width=3 stroke-linecap=round stroke-linejoin=round><polyline points="20 6 9 17 4 12">`);
function BottomSheet(props) {
  const [visible, setVisible] = createSignal(false);
  const [animating, setAnimating] = createSignal(false);
  const [customMode, setCustomMode] = createSignal(false);
  createEffect(() => {
    if (props.open) {
      setCustomMode(false);
      setVisible(true);
      requestAnimationFrame(() => setAnimating(true));
      document.body.style.overflow = 'hidden';
      onCleanup(() => {
        document.body.style.overflow = '';
      });
    } else {
      setAnimating(false);
      const timer = setTimeout(() => setVisible(false), 320);
      document.body.style.overflow = '';
      onCleanup(() => clearTimeout(timer));
    }
  });
  const handleSelect = value => {
    if (value === 'custom') {
      setCustomMode(true);
      props.onChange(value);
      return;
    }
    setCustomMode(false);
    props.onChange(value);
    props.onClose();
  };
  const isCustomActive = () => customMode() || props.value === 'custom' || props.customInput && !props.options.some(o => o.value === props.value && o.value !== 'custom');
  return createComponent(Show, {
    get when() {
      return visible();
    },
    get children() {
      return createComponent(Portal, {
        get children() {
          return [(() => {
            var _el$ = _tmpl$$8();
            addEventListener(_el$, "click", props.onClose, true);
            createRenderEffect(() => className(_el$, `sheet-backdrop${animating() ? ' sheet-backdrop--visible' : ''}`));
            return _el$;
          })(), (() => {
            var _el$2 = _tmpl$5$4(),
              _el$3 = _el$2.firstChild,
              _el$4 = _el$3.nextSibling;
            insert(_el$4, () => props.title);
            insert(_el$2, createComponent(Show, {
              get when() {
                return !isCustomActive();
              },
              get children() {
                var _el$5 = _tmpl$2$8();
                insert(_el$5, createComponent(For, {
                  get each() {
                    return props.options;
                  },
                  children: option => {
                    const selected = () => option.value === 'custom' ? false : props.value === option.value;
                    return (() => {
                      var _el$1 = _tmpl$8$4(),
                        _el$11 = _el$1.firstChild,
                        _el$12 = _el$11.firstChild,
                        _el$14 = _el$11.nextSibling;
                      _el$1.$$click = () => !option.disabled && handleSelect(option.value);
                      insert(_el$1, createComponent(Show, {
                        get when() {
                          return option.icon;
                        },
                        get children() {
                          var _el$10 = _tmpl$6$4();
                          insert(_el$10, () => option.icon);
                          return _el$10;
                        }
                      }), _el$11);
                      insert(_el$12, () => option.label);
                      insert(_el$11, createComponent(Show, {
                        get when() {
                          return option.description;
                        },
                        get children() {
                          var _el$13 = _tmpl$7$4();
                          insert(_el$13, () => option.description);
                          return _el$13;
                        }
                      }), null);
                      createRenderEffect(_p$ => {
                        var _v$3 = `sheet__option${selected() ? ' sheet__option--selected' : ''}${option.disabled ? ' sheet__option--disabled' : ''}`,
                          _v$4 = option.disabled,
                          _v$5 = `sheet__option-check${selected() ? ' sheet__option-check--visible' : ''}`;
                        _v$3 !== _p$.e && className(_el$1, _p$.e = _v$3);
                        _v$4 !== _p$.t && (_el$1.disabled = _p$.t = _v$4);
                        _v$5 !== _p$.a && className(_el$14, _p$.a = _v$5);
                        return _p$;
                      }, {
                        e: undefined,
                        t: undefined,
                        a: undefined
                      });
                      return _el$1;
                    })();
                  }
                }));
                return _el$5;
              }
            }), null);
            insert(_el$2, createComponent(Show, {
              get when() {
                return memo(() => !!props.customInput)() && isCustomActive();
              },
              get children() {
                return [(() => {
                  var _el$6 = _tmpl$3$6();
                    _el$6.firstChild;
                  _el$6.$$click = () => setCustomMode(false);
                  insert(_el$6, () => t('ui.backToOptions'), null);
                  return _el$6;
                })(), (() => {
                  var _el$8 = _tmpl$4$5(),
                    _el$9 = _el$8.firstChild,
                    _el$0 = _el$9.nextSibling;
                  _el$9.$$keydown = e => {
                    if (e.key === 'Enter' && props.customInput.value.trim()) {
                      props.customInput.onConfirm(props.customInput.value.trim());
                      props.onClose();
                    }
                  };
                  _el$9.$$input = e => props.customInput.onInput(e.currentTarget.value);
                  use(el => setTimeout(() => el.focus(), 100), _el$9);
                  _el$0.$$click = () => {
                    if (props.customInput.value.trim()) {
                      props.customInput.onConfirm(props.customInput.value.trim());
                      props.onClose();
                    }
                  };
                  createRenderEffect(_p$ => {
                    var _v$ = props.customInput.placeholder,
                      _v$2 = !props.customInput.value.trim();
                    _v$ !== _p$.e && setAttribute(_el$9, "placeholder", _p$.e = _v$);
                    _v$2 !== _p$.t && (_el$0.disabled = _p$.t = _v$2);
                    return _p$;
                  }, {
                    e: undefined,
                    t: undefined
                  });
                  createRenderEffect(() => _el$9.value = props.customInput.value);
                  return _el$8;
                })()];
              }
            }), null);
            createRenderEffect(() => className(_el$2, `sheet${animating() ? ' sheet--visible' : ''}${isCustomActive() ? ' sheet--input-mode' : ''}`));
            return _el$2;
          })()];
        }
      });
    }
  });
}
delegateEvents(["click", "input", "keydown"]);

var _tmpl$$7 = /*#__PURE__*/template(`<h3 class=settings__section-title><svg class=settings__section-icon viewBox="0 0 24 24"fill=currentColor><path d="M12 3c-4.97 0-9 4.03-9 9s4.03 9 9 9c.83 0 1.5-.67 1.5-1.5 0-.39-.15-.74-.39-1.01-.23-.26-.38-.61-.38-.99 0-.83.67-1.5 1.5-1.5H16c2.76 0 5-2.24 5-5 0-4.42-4.03-8-9-8zm-5.5 9c-.83 0-1.5-.67-1.5-1.5S5.67 9 6.5 9 8 9.67 8 10.5 7.33 12 6.5 12zm3-4C8.67 8 8 7.33 8 6.5S8.67 5 9.5 5s1.5.67 1.5 1.5S10.33 8 9.5 8zm5 0c-.83 0-1.5-.67-1.5-1.5S13.67 5 14.5 5s1.5.67 1.5 1.5S15.33 8 14.5 8zm3 4c-.83 0-1.5-.67-1.5-1.5S16.67 9 17.5 9s1.5.67 1.5 1.5-.67 1.5-1.5 1.5z">`),
  _tmpl$2$7 = /*#__PURE__*/template(`<div class=settings__group><div class=settings__label></div><div class=settings__themes><button><div class=settings__theme-icon><svg width=24 height=24 viewBox="0 0 24 24"><path d="M12.43 2.3c-2.38-.59-4.68-.27-6.63.64-.35.16-.41.64-.1.86C8.3 5.6 10 8.6 10 12c0 3.4-1.7 6.4-4.3 8.2-.32.22-.26.7.09.86 1.28.6 2.71.94 4.21.94 6.05 0 10.85-5.38 9.87-11.6-.61-3.92-3.59-7.16-7.44-8.1z"></path></svg></div><div></div></button><button><div class=settings__theme-icon><svg width=24 height=24 viewBox="0 0 24 24"><path d="M6.76 4.84l-1.8-1.79-1.41 1.41 1.79 1.79 1.42-1.41zM4 10.5H1v2h3v-2zm9-9.95h-2V3.5h2V.55zm7.45 3.91l-1.41-1.41-1.79 1.79 1.41 1.41 1.79-1.79zm-3.21 13.7l1.79 1.8 1.41-1.41-1.8-1.79-1.4 1.4zM20 10.5v2h3v-2h-3zm-8-5c-3.31 0-6 2.69-6 6s2.69 6 6 6 6-2.69 6-6-2.69-6-6-6zm-1 16.95h2V19.5h-2v2.95zm-7.45-3.91l1.41 1.41 1.79-1.8-1.41-1.41-1.79 1.8z"></path></svg></div><div></div></button><button><div class=settings__theme-icon><svg width=24 height=24 viewBox="0 0 24 24"><path d="M12 4V2A10 10 0 0 0 2 12h2a8 8 0 0 1 8-8zm0 16a8 8 0 0 1-8-8H2a10 10 0 0 0 10 10v-2zm8-8a8 8 0 0 1-8 8v2a10 10 0 0 0 10-10h-2zm-8-8a8 8 0 0 1 8 8h2A10 10 0 0 0 12 2v2z"></path></svg></div><div></div></button><button><div class=settings__theme-icon><svg width=24 height=24 viewBox="0 0 24 24"><circle cx=12 cy=12 r=10></circle></svg></div><div>`),
  _tmpl$3$5 = /*#__PURE__*/template(`<div class=settings__group><div class=settings__label></div><button class=settings__select-trigger><span></span><svg width=24 height=24 viewBox="0 0 24 24"fill=currentColor><path d="M7 10l5 5 5-5z">`),
  _tmpl$4$4 = /*#__PURE__*/template(`<div><div class=settings__label></div><div class=settings__colors>`),
  _tmpl$5$3 = /*#__PURE__*/template(`<div class=settings__item><div class=settings__item-content><div class=settings__item-label></div><div class=settings__item-desc>`),
  _tmpl$6$3 = /*#__PURE__*/template(`<div class=settings__glass-row><div class=settings__item-content><div class=settings__item-label></div><div class=settings__item-desc></div></div><div class=settings__glass-badge><span>%</span><svg width=24 height=24 viewBox="0 0 24 24"fill=currentColor><path d="M7 10l5 5 5-5z">`),
  _tmpl$7$3 = /*#__PURE__*/template(`<div class=settings__glass-slider><input type=range class=settings__slider min=0 max=100>`),
  _tmpl$8$3 = /*#__PURE__*/template(`<button>`);
const accentColors = [{
  name: 'Emerald',
  color: '#00D68F'
}, {
  name: 'Beige',
  color: '#D4A574'
}, {
  name: 'Amethyst',
  color: '#A855F7'
}, {
  name: 'Fuchsia',
  color: '#D946EF'
}, {
  name: 'Indigo',
  color: '#6366F1'
}, {
  name: 'Coral',
  color: '#FF6B6B'
}];
function AppearanceSection() {
  const [glassOpen, setGlassOpen] = createSignal(false);
  const [showLangSheet, setShowLangSheet] = createSignal(false);
  const selectedAccent = () => store.settings.accentColor;
  const isThemeActive = themeName => store.settings.theme === themeName;
  const currentLangName = () => LANGUAGES.find(l => l.code === locale())?.name ?? 'English';
  const handleThemeChange = newTheme => {
    store.updateSettings({
      theme: newTheme
    });
  };
  return createComponent(Card, {
    get children() {
      return [(() => {
        var _el$ = _tmpl$$7();
          _el$.firstChild;
        insert(_el$, () => t('appearance.title'), null);
        return _el$;
      })(), (() => {
        var _el$3 = _tmpl$2$7(),
          _el$4 = _el$3.firstChild,
          _el$5 = _el$4.nextSibling,
          _el$6 = _el$5.firstChild,
          _el$7 = _el$6.firstChild,
          _el$8 = _el$7.firstChild,
          _el$9 = _el$7.nextSibling,
          _el$0 = _el$6.nextSibling,
          _el$1 = _el$0.firstChild,
          _el$10 = _el$1.firstChild,
          _el$11 = _el$1.nextSibling,
          _el$12 = _el$0.nextSibling,
          _el$13 = _el$12.firstChild,
          _el$14 = _el$13.firstChild,
          _el$15 = _el$13.nextSibling,
          _el$16 = _el$12.nextSibling,
          _el$17 = _el$16.firstChild,
          _el$18 = _el$17.firstChild,
          _el$19 = _el$17.nextSibling;
        insert(_el$4, () => t('appearance.theme'));
        _el$6.$$click = () => handleThemeChange('dark');
        insert(_el$9, () => t('appearance.dark'));
        _el$0.$$click = () => handleThemeChange('light');
        insert(_el$11, () => t('appearance.light'));
        _el$12.$$click = () => handleThemeChange('auto');
        insert(_el$15, () => t('appearance.auto'));
        _el$16.$$click = () => handleThemeChange('amoled');
        insert(_el$19, () => t('appearance.amoled'));
        createRenderEffect(_p$ => {
          var _v$ = `settings__theme ${isThemeActive('dark') ? 'settings__theme--active' : ''}`,
            _v$2 = isThemeActive('dark') ? 'var(--text-accent)' : 'var(--text-secondary)',
            _v$3 = `settings__theme-label ${isThemeActive('dark') ? 'settings__theme-label--active' : ''}`,
            _v$4 = `settings__theme ${isThemeActive('light') ? 'settings__theme--active' : ''}`,
            _v$5 = isThemeActive('light') ? 'var(--text-accent)' : 'var(--text-secondary)',
            _v$6 = `settings__theme-label ${isThemeActive('light') ? 'settings__theme-label--active' : ''}`,
            _v$7 = `settings__theme ${isThemeActive('auto') ? 'settings__theme--active' : ''}`,
            _v$8 = isThemeActive('auto') ? 'var(--text-accent)' : 'var(--text-secondary)',
            _v$9 = `settings__theme-label ${isThemeActive('auto') ? 'settings__theme-label--active' : ''}`,
            _v$0 = `settings__theme ${isThemeActive('amoled') ? 'settings__theme--active' : ''}`,
            _v$1 = isThemeActive('amoled') ? 'var(--text-accent)' : 'var(--text-secondary)',
            _v$10 = `settings__theme-label ${isThemeActive('amoled') ? 'settings__theme-label--active' : ''}`;
          _v$ !== _p$.e && className(_el$6, _p$.e = _v$);
          _v$2 !== _p$.t && setAttribute(_el$8, "fill", _p$.t = _v$2);
          _v$3 !== _p$.a && className(_el$9, _p$.a = _v$3);
          _v$4 !== _p$.o && className(_el$0, _p$.o = _v$4);
          _v$5 !== _p$.i && setAttribute(_el$10, "fill", _p$.i = _v$5);
          _v$6 !== _p$.n && className(_el$11, _p$.n = _v$6);
          _v$7 !== _p$.s && className(_el$12, _p$.s = _v$7);
          _v$8 !== _p$.h && setAttribute(_el$14, "fill", _p$.h = _v$8);
          _v$9 !== _p$.r && className(_el$15, _p$.r = _v$9);
          _v$0 !== _p$.d && className(_el$16, _p$.d = _v$0);
          _v$1 !== _p$.l && setAttribute(_el$18, "fill", _p$.l = _v$1);
          _v$10 !== _p$.u && className(_el$19, _p$.u = _v$10);
          return _p$;
        }, {
          e: undefined,
          t: undefined,
          a: undefined,
          o: undefined,
          i: undefined,
          n: undefined,
          s: undefined,
          h: undefined,
          r: undefined,
          d: undefined,
          l: undefined,
          u: undefined
        });
        return _el$3;
      })(), (() => {
        var _el$20 = _tmpl$3$5(),
          _el$21 = _el$20.firstChild,
          _el$22 = _el$21.nextSibling,
          _el$23 = _el$22.firstChild;
        insert(_el$21, () => t('appearance.language'));
        _el$22.$$click = () => setShowLangSheet(true);
        insert(_el$23, currentLangName);
        return _el$20;
      })(), createComponent(BottomSheet, {
        get open() {
          return showLangSheet();
        },
        onClose: () => setShowLangSheet(false),
        get title() {
          return t('appearance.language');
        },
        get options() {
          return LANGUAGES.map(l => ({
            value: l.code,
            label: l.name
          }));
        },
        get value() {
          return locale();
        },
        onChange: code => {
          store.setLanguage(code);
          setShowLangSheet(false);
        }
      }), (() => {
        var _el$24 = _tmpl$4$4(),
          _el$25 = _el$24.firstChild,
          _el$26 = _el$25.nextSibling;
        insert(_el$25, () => t('appearance.accentColor'));
        insert(_el$26, createComponent(For, {
          each: accentColors,
          children: accent => (() => {
            var _el$45 = _tmpl$8$3();
            _el$45.$$click = () => {
              if (!store.settings.autoAccentColor) {
                store.updateSettings({
                  accentColor: accent.color
                });
              }
            };
            createRenderEffect(_p$ => {
              var _v$11 = `settings__color ${selectedAccent() === accent.color ? 'settings__color--active' : ''} ${store.settings.autoAccentColor ? 'settings__color--disabled' : ''}`,
                _v$12 = store.settings.autoAccentColor,
                _v$13 = accent.color,
                _v$14 = selectedAccent() === accent.color ? `0 0 0 3px ${accent.color}40` : 'none';
              _v$11 !== _p$.e && className(_el$45, _p$.e = _v$11);
              _v$12 !== _p$.t && (_el$45.disabled = _p$.t = _v$12);
              _v$13 !== _p$.a && setStyleProperty(_el$45, "background", _p$.a = _v$13);
              _v$14 !== _p$.o && setStyleProperty(_el$45, "box-shadow", _p$.o = _v$14);
              return _p$;
            }, {
              e: undefined,
              t: undefined,
              a: undefined,
              o: undefined
            });
            return _el$45;
          })()
        }));
        createRenderEffect(() => className(_el$24, `settings__group ${store.settings.autoAccentColor ? 'settings__group--disabled' : ''}`));
        return _el$24;
      })(), (() => {
        var _el$27 = _tmpl$5$3(),
          _el$28 = _el$27.firstChild,
          _el$29 = _el$28.firstChild,
          _el$30 = _el$29.nextSibling;
        insert(_el$29, () => t('appearance.randomAccent'));
        insert(_el$30, () => t('appearance.randomAccentDesc'));
        insert(_el$27, createComponent(Toggle, {
          get checked() {
            return store.settings.autoAccentColor;
          },
          onChange: async checked => {
            store.updateSettings({
              autoAccentColor: checked
            });
            if (checked) {
              await store.fetchSystemColor();
            }
          }
        }), null);
        return _el$27;
      })(), (() => {
        var _el$31 = _tmpl$6$3(),
          _el$32 = _el$31.firstChild,
          _el$33 = _el$32.firstChild,
          _el$34 = _el$33.nextSibling,
          _el$35 = _el$32.nextSibling,
          _el$36 = _el$35.firstChild,
          _el$37 = _el$36.firstChild,
          _el$38 = _el$36.nextSibling;
        _el$31.$$click = () => setGlassOpen(!glassOpen());
        insert(_el$33, () => t('appearance.glassIntensity'));
        insert(_el$34, () => t('appearance.glassIntensityDesc'));
        insert(_el$36, () => Math.round(store.bgOpacity() * 100), _el$37);
        createRenderEffect(() => setAttribute(_el$38, "class", `settings__glass-chevron${glassOpen() ? ' settings__glass-chevron--open' : ''}`));
        return _el$31;
      })(), createComponent(Show, {
        get when() {
          return glassOpen();
        },
        get children() {
          var _el$39 = _tmpl$7$3(),
            _el$40 = _el$39.firstChild;
          _el$40.$$input = e => store.setBgOpacity(parseInt(e.currentTarget.value) / 100);
          createRenderEffect(() => _el$40.value = Math.round(store.bgOpacity() * 100));
          return _el$39;
        }
      }), (() => {
        var _el$41 = _tmpl$5$3(),
          _el$42 = _el$41.firstChild,
          _el$43 = _el$42.firstChild,
          _el$44 = _el$43.nextSibling;
        insert(_el$43, () => t('appearance.fixBottomNav'));
        insert(_el$44, () => t('appearance.fixBottomNavDesc'));
        insert(_el$41, createComponent(Toggle, {
          get checked() {
            return store.settings.fixedNav;
          },
          onChange: checked => store.updateSettings({
            fixedNav: checked
          })
        }), null);
        return _el$41;
      })()];
    }
  });
}
delegateEvents(["click", "input"]);

var _tmpl$$6 = /*#__PURE__*/template(`<div class=chips>`),
  _tmpl$2$6 = /*#__PURE__*/template(`<button>`);
function ChipSelect(props) {
  return (() => {
    var _el$ = _tmpl$$6();
    insert(_el$, createComponent(For, {
      get each() {
        return props.options;
      },
      children: option => (() => {
        var _el$2 = _tmpl$2$6();
        _el$2.$$click = () => !option.disabled && props.onChange(option.value);
        insert(_el$2, () => option.label);
        createRenderEffect(_p$ => {
          var _v$ = `chip${props.value === option.value ? ' chip--selected' : ''}${option.disabled ? ' chip--disabled' : ''}`,
            _v$2 = option.disabled;
          _v$ !== _p$.e && className(_el$2, _p$.e = _v$);
          _v$2 !== _p$.t && (_el$2.disabled = _p$.t = _v$2);
          return _p$;
        }, {
          e: undefined,
          t: undefined
        });
        return _el$2;
      })()
    }));
    return _el$;
  })();
}
delegateEvents(["click"]);

var _tmpl$$5 = /*#__PURE__*/template(`<h3 class=settings__section-title><svg class=settings__section-icon viewBox="0 0 24 24"fill=currentColor><path d="M20 6h-8l-2-2H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2zm-6 10H6v-2h8v2zm4-4H6v-2h12v2z">`),
  _tmpl$2$5 = /*#__PURE__*/template(`<div class=settings__item-desc style=margin-top:6px;color:var(--warning)>`),
  _tmpl$3$4 = /*#__PURE__*/template(`<div class=settings__group><div class=settings__item-label></div><div class=settings__item-desc style=margin-bottom:12px></div><div class=settings__strategies><button><div style=margin-bottom:4px><svg width=24 height=24 viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"></path></svg></div><div></div><div class=settings__strategy-hint></div></button><button><div style=margin-bottom:4px><svg width=24 height=24 viewBox="0 0 24 24"><path d="M4 6H2v14c0 1.1.9 2 2 2h14v-2H4V6zm16-4H8c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm0 14H8V4h12v12z"></path></svg></div><div></div><div class=settings__strategy-hint></div></button><button><div style=margin-bottom:4px><svg width=24 height=24 viewBox="0 0 24 24"><path d="M17 1.01L7 1c-1.1 0-2 .9-2 2v18c0 1.1.9 2 2 2h10c1.1 0 2-.9 2-2V3c0-1.1-.9-1.99-2-1.99zM17 19H7V5h10v14z"></path></svg></div><div></div><div class=settings__strategy-hint></div></button></div><div class=settings__item-desc style=margin-top:8px;font-style:italic>`),
  _tmpl$4$3 = /*#__PURE__*/template(`<div class=settings__item-desc style=color:var(--warning);margin-top:8px>`),
  _tmpl$5$2 = /*#__PURE__*/template(`<div class=settings__group style=margin-top:16px><div class=settings__item-label></div><div class=settings__item-desc style=margin-bottom:10px>`),
  _tmpl$6$2 = /*#__PURE__*/template(`<div class=settings__item><div class=settings__item-content><div class=settings__item-label></div><div class=settings__item-desc>`),
  _tmpl$7$2 = /*#__PURE__*/template(`<div class=settings__item><div class=settings__item-content><div class=settings__item-label></div><div class=settings__item-desc></div></div><button class=settings__select-trigger><span></span><svg width=24 height=24 viewBox="0 0 24 24"fill=currentColor><path d="M7 10l5 5 5-5z">`),
  _tmpl$8$2 = /*#__PURE__*/template(`<div class=settings__item><div class=settings__item-content><div class=settings__item-label></div><div class=settings__item-desc></div></div><button class=settings__select-trigger><span></span><svg width=20 height=20 viewBox="0 0 24 24"fill=currentColor><path d="M7 10l5 5 5-5z">`),
  _tmpl$9$2 = /*#__PURE__*/template(`<div class=settings__item style=flex-direction:column;align-items:stretch><div class=settings__item-content><div class=settings__item-label></div><div class=settings__item-desc>`);
function MountEngineSection() {
  const [customOverlaySource, setCustomOverlaySource] = createSignal('');
  const [customMountSource, setCustomMountSource] = createSignal('');
  const [showOverlaySheet, setShowOverlaySheet] = createSignal(false);
  const [showStagingSheet, setShowStagingSheet] = createSignal(false);
  const caps = () => store.capabilities?.() || null;
  return createComponent(Card, {
    get children() {
      return [(() => {
        var _el$ = _tmpl$$5();
          _el$.firstChild;
        insert(_el$, () => t('engine.mountEngine'), null);
        return _el$;
      })(), (() => {
        var _el$3 = _tmpl$3$4(),
          _el$4 = _el$3.firstChild,
          _el$5 = _el$4.nextSibling,
          _el$6 = _el$5.nextSibling,
          _el$7 = _el$6.firstChild,
          _el$8 = _el$7.firstChild,
          _el$9 = _el$8.firstChild,
          _el$0 = _el$8.nextSibling,
          _el$1 = _el$0.nextSibling,
          _el$10 = _el$7.nextSibling,
          _el$11 = _el$10.firstChild,
          _el$12 = _el$11.firstChild,
          _el$13 = _el$11.nextSibling,
          _el$14 = _el$13.nextSibling,
          _el$15 = _el$10.nextSibling,
          _el$16 = _el$15.firstChild,
          _el$17 = _el$16.firstChild,
          _el$18 = _el$16.nextSibling,
          _el$19 = _el$18.nextSibling,
          _el$20 = _el$6.nextSibling;
        insert(_el$4, () => t('engine.mountStrategy'));
        insert(_el$5, (() => {
          var _c$ = memo(() => !!caps()?.vfs_driver);
          return () => _c$() ? t('engine.mountStrategyDescVfs') : t('engine.mountStrategyDescNoVfs');
        })());
        _el$7.$$click = () => store.setMountStrategy('Vfs');
        insert(_el$0, () => t('engine.strategyVfs'));
        insert(_el$1, () => t('engine.strategyVfsHint'));
        _el$10.$$click = () => store.setMountStrategy('Overlay');
        insert(_el$13, () => t('engine.strategyOverlay'));
        insert(_el$14, () => t('engine.strategyOverlayHint'));
        _el$15.$$click = () => store.setMountStrategy('MagicMount');
        insert(_el$18, () => t('engine.strategyMagic'));
        insert(_el$19, () => t('engine.strategyMagicHint'));
        insert(_el$20, () => t('engine.switchingRequiresReboot'));
        insert(_el$3, createComponent(Show, {
          get when() {
            return memo(() => store.effectiveStrategy() === 'MagicMount')() && !caps()?.susfs_available;
          },
          get children() {
            var _el$21 = _tmpl$2$5();
            insert(_el$21, () => t('engine.magicMountNoSusfsWarning'));
            return _el$21;
          }
        }), null);
        createRenderEffect(_p$ => {
          var _v$ = `settings__strategy${store.effectiveStrategy() === 'Vfs' ? ' settings__strategy--active' : ''}${!caps()?.vfs_driver ? ' settings__strategy--disabled' : ''}`,
            _v$2 = !caps()?.vfs_driver,
            _v$3 = !caps()?.vfs_driver ? t('engine.titleVfsUnavailable') : t('engine.titleVfsAuto'),
            _v$4 = store.effectiveStrategy() === 'Vfs' ? 'var(--text-accent)' : 'var(--text-secondary)',
            _v$5 = `settings__strategy-label${store.effectiveStrategy() === 'Vfs' ? ' settings__strategy-label--active' : ''}`,
            _v$6 = `settings__strategy${store.effectiveStrategy() === 'Overlay' ? ' settings__strategy--active' : ''}${!caps()?.overlay_supported ? ' settings__strategy--disabled' : ''}`,
            _v$7 = !caps()?.overlay_supported,
            _v$8 = !caps()?.overlay_supported ? t('engine.titleOverlayUnavailable') : t('engine.titleOverlayPrefer'),
            _v$9 = store.effectiveStrategy() === 'Overlay' ? 'var(--text-accent)' : 'var(--text-secondary)',
            _v$0 = `settings__strategy-label${store.effectiveStrategy() === 'Overlay' ? ' settings__strategy-label--active' : ''}`,
            _v$1 = `settings__strategy${store.effectiveStrategy() === 'MagicMount' ? ' settings__strategy--active' : ''}`,
            _v$10 = t('engine.titleMagicMount'),
            _v$11 = store.effectiveStrategy() === 'MagicMount' ? 'var(--text-accent)' : 'var(--text-secondary)',
            _v$12 = `settings__strategy-label${store.effectiveStrategy() === 'MagicMount' ? ' settings__strategy-label--active' : ''}`;
          _v$ !== _p$.e && className(_el$7, _p$.e = _v$);
          _v$2 !== _p$.t && (_el$7.disabled = _p$.t = _v$2);
          _v$3 !== _p$.a && setAttribute(_el$7, "title", _p$.a = _v$3);
          _v$4 !== _p$.o && setAttribute(_el$9, "fill", _p$.o = _v$4);
          _v$5 !== _p$.i && className(_el$0, _p$.i = _v$5);
          _v$6 !== _p$.n && className(_el$10, _p$.n = _v$6);
          _v$7 !== _p$.s && (_el$10.disabled = _p$.s = _v$7);
          _v$8 !== _p$.h && setAttribute(_el$10, "title", _p$.h = _v$8);
          _v$9 !== _p$.r && setAttribute(_el$12, "fill", _p$.r = _v$9);
          _v$0 !== _p$.d && className(_el$13, _p$.d = _v$0);
          _v$1 !== _p$.l && className(_el$15, _p$.l = _v$1);
          _v$10 !== _p$.u && setAttribute(_el$15, "title", _p$.u = _v$10);
          _v$11 !== _p$.c && setAttribute(_el$17, "fill", _p$.c = _v$11);
          _v$12 !== _p$.w && className(_el$18, _p$.w = _v$12);
          return _p$;
        }, {
          e: undefined,
          t: undefined,
          a: undefined,
          o: undefined,
          i: undefined,
          n: undefined,
          s: undefined,
          h: undefined,
          r: undefined,
          d: undefined,
          l: undefined,
          u: undefined,
          c: undefined,
          w: undefined
        });
        return _el$3;
      })(), createComponent(Show, {
        get when() {
          return store.effectiveStrategy() !== 'Vfs';
        },
        get children() {
          return [createComponent(Show, {
            get when() {
              return store.effectiveStrategy() === 'Overlay';
            },
            get children() {
              var _el$22 = _tmpl$5$2(),
                _el$23 = _el$22.firstChild,
                _el$24 = _el$23.nextSibling;
              insert(_el$23, () => t('engine.storageBackend'));
              insert(_el$24, () => t('engine.storageBackendDesc'), null);
              insert(_el$24, (() => {
                var _c$2 = memo(() => !!caps()?.tmpfs_xattr);
                return () => _c$2() ? '' : ` (${t('engine.storageBackendNoXattr')})`;
              })(), null);
              insert(_el$22, createComponent(ChipSelect, {
                get value() {
                  return store.settings.mount.storage_mode;
                },
                onChange: v => store.setMountStorageMode(v),
                get options() {
                  return [{
                    value: 'auto',
                    label: t('engine.storageAuto')
                  }, {
                    value: 'erofs',
                    label: t('engine.storageErofs'),
                    disabled: !caps()?.erofs_supported
                  }, {
                    value: 'tmpfs',
                    label: t('engine.storageTmpfs'),
                    disabled: !caps()?.tmpfs_xattr
                  }, {
                    value: 'ext4',
                    label: t('engine.storageExt4')
                  }];
                }
              }), null);
              insert(_el$22, createComponent(Show, {
                get when() {
                  return memo(() => !!(store.resolvedStorageMode() && store.settings.mount.storage_mode !== 'auto'))() && store.resolvedStorageMode() !== store.settings.mount.storage_mode;
                },
                get children() {
                  var _el$25 = _tmpl$4$3();
                  insert(_el$25, () => t('engine.storageUnavailable', {
                    selected: store.settings.mount.storage_mode,
                    resolved: store.resolvedStorageMode()
                  }));
                  return _el$25;
                }
              }), null);
              return _el$22;
            }
          }), (() => {
            var _el$26 = _tmpl$6$2(),
              _el$27 = _el$26.firstChild,
              _el$28 = _el$27.firstChild,
              _el$29 = _el$28.nextSibling;
            insert(_el$28, () => t('engine.randomMountPaths'));
            insert(_el$29, () => t('engine.randomMountPathsDesc'));
            insert(_el$26, createComponent(Toggle, {
              get checked() {
                return store.settings.mount.random_mount_paths;
              },
              onChange: v => store.setMountToggle('random_mount_paths', v)
            }), null);
            return _el$26;
          })(), createComponent(Show, {
            get when() {
              return store.effectiveStrategy() !== 'MagicMount';
            },
            get children() {
              return [(() => {
                var _el$30 = _tmpl$7$2(),
                  _el$31 = _el$30.firstChild,
                  _el$32 = _el$31.firstChild,
                  _el$33 = _el$32.nextSibling,
                  _el$34 = _el$31.nextSibling,
                  _el$35 = _el$34.firstChild;
                insert(_el$32, () => t('engine.overlayMountSource'));
                insert(_el$33, () => t('engine.overlayMountSourceDesc'));
                _el$34.$$click = () => setShowOverlaySheet(true);
                insert(_el$35, (() => {
                  var _c$3 = memo(() => !!['auto', 'KSU', 'magisk', 'overlay'].includes(store.settings.mount.overlay_source));
                  return () => _c$3() ? store.settings.mount.overlay_source : t('engine.customLabel');
                })());
                return _el$30;
              })(), createComponent(BottomSheet, {
                get open() {
                  return showOverlaySheet();
                },
                onClose: () => setShowOverlaySheet(false),
                get title() {
                  return t('engine.overlayMountSource');
                },
                get value() {
                  return memo(() => !!['auto', 'KSU', 'magisk', 'overlay'].includes(store.settings.mount.overlay_source))() ? store.settings.mount.overlay_source : 'custom';
                },
                onChange: val => {
                  if (val !== 'custom') {
                    store.setOverlaySource(val);
                  } else {
                    setCustomOverlaySource('');
                  }
                },
                get options() {
                  return [{
                    value: 'auto',
                    label: t('engine.storageAuto'),
                    description: t('engine.overlayOptAuto')
                  }, {
                    value: 'KSU',
                    label: 'KSU',
                    description: t('engine.overlayOptKsu')
                  }, {
                    value: 'magisk',
                    label: 'magisk',
                    description: t('engine.overlayOptMagisk')
                  }, {
                    value: 'overlay',
                    label: 'overlay',
                    description: t('engine.overlayOptOverlay')
                  }, {
                    value: 'custom',
                    label: t('engine.customLabel'),
                    description: t('engine.overlayOptCustom')
                  }];
                },
                get customInput() {
                  return {
                    placeholder: t('engine.overlayPlaceholder'),
                    value: customOverlaySource(),
                    onInput: setCustomOverlaySource,
                    onConfirm: v => store.setOverlaySource(v)
                  };
                }
              })];
            }
          }), (() => {
            var _el$36 = _tmpl$8$2(),
              _el$37 = _el$36.firstChild,
              _el$38 = _el$37.firstChild,
              _el$39 = _el$38.nextSibling,
              _el$40 = _el$37.nextSibling,
              _el$41 = _el$40.firstChild;
            insert(_el$38, () => t('engine.stagingMountSource'));
            insert(_el$39, () => t('engine.stagingMountSourceDesc'));
            _el$40.$$click = () => setShowStagingSheet(true);
            insert(_el$41, (() => {
              var _c$4 = memo(() => !!['auto', 'tmpfs', 'none', 'shmem', 'shm'].includes(store.settings.mount.mount_source));
              return () => _c$4() ? store.settings.mount.mount_source : t('engine.customLabel');
            })());
            return _el$36;
          })(), createComponent(BottomSheet, {
            get open() {
              return showStagingSheet();
            },
            onClose: () => setShowStagingSheet(false),
            get title() {
              return t('engine.stagingMountSource');
            },
            get value() {
              return memo(() => !!['auto', 'tmpfs', 'none', 'shmem', 'shm'].includes(store.settings.mount.mount_source))() ? store.settings.mount.mount_source : 'custom';
            },
            onChange: val => {
              if (val !== 'custom') {
                store.setMountSource(val);
              } else {
                setCustomMountSource('');
              }
            },
            get options() {
              return [{
                value: 'auto',
                label: t('engine.storageAuto'),
                description: t('engine.stagingOptAuto')
              }, {
                value: 'tmpfs',
                label: 'tmpfs',
                description: t('engine.stagingOptTmpfs')
              }, {
                value: 'none',
                label: 'none',
                description: t('engine.stagingOptNone')
              }, {
                value: 'shmem',
                label: 'shmem',
                description: t('engine.stagingOptShmem')
              }, {
                value: 'shm',
                label: 'shm',
                description: t('engine.stagingOptShm')
              }, {
                value: 'custom',
                label: t('engine.customLabel'),
                description: t('engine.stagingOptCustom')
              }];
            },
            get customInput() {
              return {
                placeholder: t('engine.stagingPlaceholder'),
                value: customMountSource(),
                onInput: setCustomMountSource,
                onConfirm: v => store.setMountSource(v)
              };
            }
          }), createComponent(CollapsibleSubgroup, {
            get label() {
              return t('engine.advancedMounting');
            },
            get hiddenCount() {
              return store.settings.mount.storage_mode === 'ext4' ? 1 : 0;
            },
            get defaultItems() {
              return (() => {
                var _el$46 = _tmpl$6$2(),
                  _el$47 = _el$46.firstChild,
                  _el$48 = _el$47.firstChild,
                  _el$49 = _el$48.nextSibling;
                insert(_el$48, () => t('engine.restartFramework'));
                insert(_el$49, () => t('engine.restartFrameworkDesc'));
                insert(_el$46, createComponent(Toggle, {
                  get checked() {
                    return store.settings.mount.restart_framework;
                  },
                  onChange: v => store.setMountToggle('restart_framework', v)
                }), null);
                return _el$46;
              })();
            },
            get expandedItems() {
              return createComponent(Show, {
                get when() {
                  return store.settings.mount.storage_mode === 'ext4';
                },
                get children() {
                  var _el$50 = _tmpl$9$2(),
                    _el$51 = _el$50.firstChild,
                    _el$52 = _el$51.firstChild,
                    _el$53 = _el$52.nextSibling;
                  insert(_el$52, () => t('engine.ext4ImageSize'));
                  insert(_el$53, () => t('engine.ext4ImageSizeDesc'));
                  insert(_el$50, createComponent(Input, {
                    fullWidth: true,
                    type: "number",
                    get value() {
                      return String(store.settings.mount.ext4_image_size_mb);
                    },
                    onBlur: e => store.setMountField('ext4_image_size_mb', parseInt(e.currentTarget.value, 10) || 0)
                  }), null);
                  return _el$50;
                }
              });
            }
          })];
        }
      }), (() => {
        var _el$42 = _tmpl$6$2(),
          _el$43 = _el$42.firstChild,
          _el$44 = _el$43.firstChild,
          _el$45 = _el$44.nextSibling;
        insert(_el$44, () => t('engine.excludeHosts'));
        insert(_el$45, () => t('engine.excludeHostsDesc'));
        insert(_el$42, createComponent(Toggle, {
          get checked() {
            return store.settings.mount.exclude_hosts_modules;
          },
          onChange: v => store.setMountToggle('exclude_hosts_modules', v)
        }), null);
        return _el$42;
      })()];
    }
  });
}
delegateEvents(["click"]);

var _tmpl$$4 = /*#__PURE__*/template(`<div>`),
  _tmpl$2$4 = /*#__PURE__*/template(`<div class=sheet__custom style=flex-direction:column;gap:12px;margin-top:16px><div style=display:flex;flex-direction:column;gap:6px><label class=sheet__title style=margin-bottom:0;font-size:11px></label><input class=sheet__custom-input type=text placeholder=5.10.0-android12-gki></div><div style=display:flex;flex-direction:column;gap:6px><label class=sheet__title style=margin-bottom:0;font-size:11px></label><input class=sheet__custom-input type=text placeholder="#1 SMP PREEMPT">`),
  _tmpl$3$3 = /*#__PURE__*/template(`<div><div class=sheet__handle></div><div class=sheet__title></div><div class=sheet__options>`),
  _tmpl$4$2 = /*#__PURE__*/template(`<button><div class=sheet__option-content><div class=sheet__option-label></div></div><div><svg viewBox="0 0 24 24"fill=none stroke=currentColor stroke-width=3 stroke-linecap=round stroke-linejoin=round><polyline points="20 6 9 17 4 12">`);
const modeKeys = {
  disabled: 'susfs.unameModeDisabled',
  static: 'susfs.unameModeStatic',
  dynamic: 'susfs.unameModeDynamic'
};
const modeValues = ['disabled', 'static', 'dynamic'];
function UnameSheet(props) {
  const [visible, setVisible] = createSignal(false);
  const [animating, setAnimating] = createSignal(false);
  createEffect(() => {
    if (props.open) {
      setVisible(true);
      requestAnimationFrame(() => setAnimating(true));
      document.body.style.overflow = 'hidden';
      onCleanup(() => {
        document.body.style.overflow = '';
      });
    } else {
      setAnimating(false);
      const timer = setTimeout(() => setVisible(false), 320);
      document.body.style.overflow = '';
      onCleanup(() => clearTimeout(timer));
    }
  });
  return createComponent(Show, {
    get when() {
      return visible();
    },
    get children() {
      return createComponent(Portal, {
        get children() {
          return [(() => {
            var _el$ = _tmpl$$4();
            addEventListener(_el$, "click", props.onClose, true);
            createRenderEffect(() => className(_el$, `sheet-backdrop${animating() ? ' sheet-backdrop--visible' : ''}`));
            return _el$;
          })(), (() => {
            var _el$2 = _tmpl$3$3(),
              _el$3 = _el$2.firstChild,
              _el$4 = _el$3.nextSibling,
              _el$5 = _el$4.nextSibling;
            insert(_el$4, () => t('susfs.unameSpoofing'));
            insert(_el$5, () => modeValues.map(val => (() => {
              var _el$11 = _tmpl$4$2(),
                _el$12 = _el$11.firstChild,
                _el$13 = _el$12.firstChild,
                _el$14 = _el$12.nextSibling;
              _el$11.$$click = () => props.onModeChange(val);
              insert(_el$13, () => t(modeKeys[val]));
              createRenderEffect(_p$ => {
                var _v$ = `sheet__option${props.mode === val ? ' sheet__option--selected' : ''}`,
                  _v$2 = `sheet__option-check${props.mode === val ? ' sheet__option-check--visible' : ''}`;
                _v$ !== _p$.e && className(_el$11, _p$.e = _v$);
                _v$2 !== _p$.t && className(_el$14, _p$.t = _v$2);
                return _p$;
              }, {
                e: undefined,
                t: undefined
              });
              return _el$11;
            })()));
            insert(_el$2, createComponent(Show, {
              get when() {
                return props.mode !== 'disabled';
              },
              get children() {
                var _el$6 = _tmpl$2$4(),
                  _el$7 = _el$6.firstChild,
                  _el$8 = _el$7.firstChild,
                  _el$9 = _el$8.nextSibling,
                  _el$0 = _el$7.nextSibling,
                  _el$1 = _el$0.firstChild,
                  _el$10 = _el$1.nextSibling;
                insert(_el$8, () => t('uname.release'));
                _el$9.addEventListener("blur", e => props.onReleaseChange(e.currentTarget.value));
                insert(_el$1, () => t('uname.version'));
                _el$10.addEventListener("blur", e => props.onVersionChange(e.currentTarget.value));
                createRenderEffect(() => _el$9.value = props.release);
                createRenderEffect(() => _el$10.value = props.version);
                return _el$6;
              }
            }), null);
            createRenderEffect(() => className(_el$2, `sheet${animating() ? ' sheet--visible' : ''}`));
            return _el$2;
          })()];
        }
      });
    }
  });
}
delegateEvents(["click"]);

var _tmpl$$3 = /*#__PURE__*/template(`<h3 class=settings__section-title><svg class=settings__section-icon viewBox="0 0 24 24"fill=currentColor><path d="M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4zm0 10.99h7c-.53 4.12-3.28 7.79-7 8.94V12H5V6.3l7-3.11v8.8z">`),
  _tmpl$2$3 = /*#__PURE__*/template(`<div class=settings__item><div class=settings__item-content><div class=settings__item-label></div><div class=settings__item-desc>`),
  _tmpl$3$2 = /*#__PURE__*/template(`<h4 class=settings__section-title>`),
  _tmpl$4$1 = /*#__PURE__*/template(`<div><div class=settings__item-content><div class=settings__item-label></div><div class=settings__item-desc>`),
  _tmpl$5$1 = /*#__PURE__*/template(`<div class=settings__sub-toggles><div><div class=settings__item-content><div class=settings__item-label></div><div class=settings__item-desc></div></div></div><div><div class=settings__item-content><div class=settings__item-label></div><div class=settings__item-desc></div></div></div><div><div class=settings__item-content><div class=settings__item-label></div><div class=settings__item-desc></div></div></div><div><div class=settings__item-content><div class=settings__item-label></div><div class=settings__item-desc>`),
  _tmpl$6$1 = /*#__PURE__*/template(`<button><svg viewBox="0 0 24 24"fill=currentColor><path d="M7 10l5 5 5-5z"></path></svg><span></span><span class=settings__advanced-badge>20`),
  _tmpl$7$1 = /*#__PURE__*/template(`<div class=settings__advanced-content>`),
  _tmpl$8$1 = /*#__PURE__*/template(`<div class="settings__item settings__item--nested"><div class=settings__item-content><div class=settings__item-label></div><div class=settings__item-desc>`),
  _tmpl$9$1 = /*#__PURE__*/template(`<div class="settings__item settings__item--nested"style=flex-direction:column;align-items:stretch><div class=settings__item-content><div class=settings__item-label> </div><div class=settings__item-desc></div></div><div class=settings__slider-row><input type=range min=1 max=5 step=1 class=settings__slider><div class=settings__slider-labels><span>1</span><span>2</span><span>3</span><span>4</span><span>5`),
  _tmpl$0$1 = /*#__PURE__*/template(`<div class=settings__item style=cursor:pointer><div class=settings__item-content><div class=settings__item-label></div><div class=settings__item-desc></div></div><button class=settings__select-trigger><span></span><svg width=24 height=24 viewBox="0 0 24 24"fill=currentColor><path d="M7 10l5 5 5-5z">`);
function SusfsSection() {
  const [showAdvanced, setShowAdvanced] = createSignal(false);
  const [showUnameSheet, setShowUnameSheet] = createSignal(false);
  const caps = () => store.capabilities?.() || null;
  const susfsAvailable = () => caps()?.susfs_available ?? false;
  const susfsEnabled = () => susfsAvailable() && store.settings.susfs.enabled;
  const ownership = () => store.susfsOwnership();
  const susfsDisabled = () => !store.settings.brene.enabled || ownership() !== 'embedded_active';
  const externalModule = () => store.externalSusfsModule();
  const susfsItemClass = () => {
    const o = ownership();
    return o === 'disabled' ? ' settings__item--susfs-unavailable' : o === 'deferred_external' ? ' settings__item--susfs-deferred' : '';
  };
  const handleBreneToggle = (key, value) => {
    store.setBreneToggle(key, value);
  };
  const handleSusfsToggle = (key, value) => {
    store.setSusfsToggle(key, value);
  };
  return createComponent(Card, {
    get children() {
      return [(() => {
        var _el$ = _tmpl$$3();
          _el$.firstChild;
        insert(_el$, () => t('susfs.title'), null);
        return _el$;
      })(), (() => {
        var _el$3 = _tmpl$2$3(),
          _el$4 = _el$3.firstChild,
          _el$5 = _el$4.firstChild,
          _el$6 = _el$5.nextSibling;
        insert(_el$5, () => t('susfs.title'));
        insert(_el$6, (() => {
          var _c$ = memo(() => !!susfsAvailable());
          return () => _c$() ? t('susfs.integrationDescAvailable', {
            version: caps()?.susfs_version || 'unknown',
            status: susfsEnabled() ? 'active' : 'disabled (ZeroMount pausiert; andere SuSFS-Module bleiben unabhängig)'
          }) : t('susfs.integrationDescNotDetected');
        })());
        insert(_el$3, createComponent(Toggle, {
          get checked() {
            return susfsEnabled();
          },
          onChange: v => {
            handleSusfsToggle('enabled', v);
            const ext = externalModule();
            if (ext) {
              store.showToast(v ? t('susfs.toastTakingOwnership') : t('susfs.toastDeferred', {
                module: ext
              }), 'info');
            }
          },
          get disabled() {
            return !susfsAvailable();
          },
          variant: "rainbow"
        }), null);
        return _el$3;
      })(), (() => {
        const row = document.createElement('div'); row.className = 'settings__item';
        const text = document.createElement('div'); text.className = 'settings__item-content';
        const title = document.createElement('div'); title.className = 'settings__item-label'; title.textContent = 'BRENE-Funktionen freigeben';
        const hint = document.createElement('div'); hint.className = 'settings__item-desc';
        insert(hint, () => store.settings.brene.enabled
          ? 'Ein: Gespeicherte Einzeloptionen dürfen laufen. SuSFS-Funktionen benötigen zusätzlich „SUSFS Integration“ und gegebenenfalls „Path Hiding“.'
          : 'Aus: ZeroMount-BRENE-Funktionen sind pausiert, einschließlich Properties und BRENE 75. Einzeloptionen bleiben gespeichert.');
        text.append(title, hint); row.append(text);
        insert(row, createComponent(Toggle, {
          get checked() { return store.settings.brene.enabled === true; },
          onChange: v => handleBreneToggle('enabled', v), variant: 'rainbow'
        }), null);
        return row;
      })(), (() => {
        var _el$7 = _tmpl$2$3(),
          _el$8 = _el$7.firstChild,
          _el$9 = _el$8.firstChild,
          _el$0 = _el$9.nextSibling;
        insert(_el$9, () => t('susfs.storageFilter'));
        insert(_el$0, () => t('susfs.storageFilterDesc'));
        const requirements = document.createElement('div');
        requirements.className = 'settings__item-desc';
        requirements.id = 'brene66-requirements';
        requirements.setAttribute('role', 'status');
        requirements.setAttribute('aria-live', 'polite');
        requirements.style.cssText = 'margin-top:10px;color:var(--text-accent);line-height:1.5';
        insert(requirements, () => storageFilterHint({
          breneEnabled: store.settings.brene.enabled === true,
          susfsEnabled: store.settings.susfs.enabled === true,
          pathHideEnabled: store.settings.susfs.path_hide === true,
          susfsAvailable: susfsAvailable(),
          ownership: ownership()
        }));
        _el$8.append(requirements);
        insert(_el$7, createComponent(Toggle, {
          get checked() {
            return store.settings.brene.hide_nonstandard_sdcard;
          },
          onChange: v => handleBreneToggle('hide_nonstandard_sdcard', v),
          get disabled() {
            return susfsDisabled() || !store.settings.susfs.path_hide;
          }
        }), null);
        return _el$7;
      })(), (() => {
        var _el$1 = _tmpl$3$2();
        insert(_el$1, () => t('susfs.propertyGroups'));
        return _el$1;
      })(), (() => {
        var _el$10 = _tmpl$2$3(),
          _el$11 = _el$10.firstChild,
          _el$12 = _el$11.firstChild,
          _el$13 = _el$12.nextSibling;
        insert(_el$12, () => t('susfs.generalProps'));
        insert(_el$13, () => t('susfs.generalPropsDesc'));
        insert(_el$10, createComponent(Toggle, {
          get checked() {
            return store.settings.brene.prop_spoofing;
          },
          onChange: v => handleBreneToggle('prop_spoofing', v),
          get disabled() {
            return !store.settings.brene.enabled || ownership() === 'deferred_external';
          }
        }), null);
        return _el$10;
      })(), (() => {
        var _el$14 = _tmpl$2$3(),
          _el$15 = _el$14.firstChild,
          _el$16 = _el$15.firstChild,
          _el$17 = _el$16.nextSibling;
        insert(_el$16, () => t('susfs.fingerprintProps'));
        insert(_el$17, () => t('susfs.fingerprintPropsDesc'));
        insert(_el$14, createComponent(Toggle, {
          get checked() {
            return store.settings.brene.spoof_fingerprint_properties;
          },
          onChange: v => handleBreneToggle('spoof_fingerprint_properties', v),
          get disabled() {
            return !store.settings.brene.enabled || ownership() === 'deferred_external';
          }
        }), null);
        return _el$14;
      })(), (() => {
        var _el$18 = _tmpl$2$3(),
          _el$19 = _el$18.firstChild,
          _el$20 = _el$19.firstChild,
          _el$21 = _el$20.nextSibling;
        insert(_el$20, () => t('susfs.utcProps'));
        insert(_el$21, () => t('susfs.utcPropsDesc'));
        insert(_el$18, createComponent(Toggle, {
          get checked() {
            return store.settings.brene.spoof_utc_properties;
          },
          onChange: v => handleBreneToggle('spoof_utc_properties', v),
          get disabled() {
            return !store.settings.brene.enabled || ownership() === 'deferred_external';
          }
        }), null);
        return _el$18;
      })(), (() => {
        var _el$22 = _tmpl$2$3(),
          _el$23 = _el$22.firstChild,
          _el$24 = _el$23.firstChild,
          _el$25 = _el$24.nextSibling;
        insert(_el$24, () => t('susfs.dateProps'));
        insert(_el$25, () => t('susfs.datePropsDesc'));
        insert(_el$22, createComponent(Toggle, {
          get checked() {
            return store.settings.brene.spoof_date_properties;
          },
          onChange: v => handleBreneToggle('spoof_date_properties', v),
          get disabled() {
            return !store.settings.brene.enabled || ownership() === 'deferred_external';
          }
        }), null);
        return _el$22;
      })(), (() => {
        var _el$26 = _tmpl$2$3(),
          _el$27 = _el$26.firstChild,
          _el$28 = _el$27.firstChild,
          _el$29 = _el$28.nextSibling;
        insert(_el$28, () => t('susfs.repeatProps'));
        insert(_el$29, () => t('susfs.repeatPropsDesc'));
        insert(_el$26, createComponent(Toggle, {
          get checked() {
            return store.settings.brene.prop_spoofing_repeat;
          },
          onChange: v => handleBreneToggle('prop_spoofing_repeat', v),
          get disabled() {
            return !store.settings.brene.enabled || ownership() === 'deferred_external';
          }
        }), null);
        return _el$26;
      })(), createComponent(Show, {
        get when() {
          return susfsAvailable();
        },
        get children() {
          return [(() => {
            var _el$30 = _tmpl$5$1(),
              _el$31 = _el$30.firstChild,
              _el$32 = _el$31.firstChild,
              _el$33 = _el$32.firstChild,
              _el$34 = _el$33.nextSibling,
              _el$39 = _el$31.nextSibling,
              _el$40 = _el$39.firstChild,
              _el$41 = _el$40.firstChild,
              _el$42 = _el$41.nextSibling,
              _el$43 = _el$39.nextSibling,
              _el$44 = _el$43.firstChild,
              _el$45 = _el$44.firstChild,
              _el$46 = _el$45.nextSibling,
              _el$47 = _el$43.nextSibling,
              _el$48 = _el$47.firstChild,
              _el$49 = _el$48.firstChild,
              _el$50 = _el$49.nextSibling;
            insert(_el$33, () => t('susfs.hideSusMounts'));
            insert(_el$34, () => t('susfs.hideSusMountsDesc'));
            insert(_el$31, createComponent(Toggle, {
              get checked() {
                return store.settings.brene.hide_sus_mounts;
              },
              onChange: v => handleBreneToggle('hide_sus_mounts', v),
              get disabled() {
                return !susfsEnabled();
              }
            }), null);
            insert(_el$30, createComponent(Show, {
              get when() {
                return store.settings.brene.hide_sus_mounts;
              },
              get children() {
                var _el$35 = _tmpl$4$1(),
                  _el$36 = _el$35.firstChild,
                  _el$37 = _el$36.firstChild,
                  _el$38 = _el$37.nextSibling;
                insert(_el$37, () => t('susfs.keepMountsAfterBoot'));
                insert(_el$38, () => t('susfs.keepMountsAfterBootDesc'));
                insert(_el$35, createComponent(Toggle, {
                  get checked() {
                    return !store.settings.brene.hide_sus_mounts_off_after_boot;
                  },
                  onChange: v => handleBreneToggle('hide_sus_mounts_off_after_boot', !v),
                  get disabled() {
                    return !susfsEnabled();
                  }
                }), null);
                createRenderEffect(() => className(_el$35, `settings__item settings__item--sub settings__item--nested${!susfsEnabled() ? ' settings__item--disabled' : ''}`));
                return _el$35;
              }
            }), _el$39);
            insert(_el$41, () => t('susfs.pathHiding'));
            insert(_el$42, () => t('susfs.pathHidingDesc'));
            insert(_el$39, createComponent(Toggle, {
              get checked() {
                return store.settings.susfs.path_hide;
              },
              onChange: v => handleSusfsToggle('path_hide', v),
              get disabled() {
                return susfsDisabled();
              }
            }), null);
            insert(_el$45, () => t('susfs.kstatSpoofing'));
            insert(_el$46, () => t('susfs.kstatSpoofingDesc'));
            insert(_el$43, createComponent(Toggle, {
              get checked() {
                return store.settings.susfs.kstat;
              },
              onChange: v => handleSusfsToggle('kstat', v),
              get disabled() {
                return susfsDisabled();
              }
            }), null);
            insert(_el$49, () => t('susfs.mapsHiding'));
            insert(_el$50, () => t('susfs.mapsHidingDesc'));
            insert(_el$47, createComponent(Toggle, {
              get checked() {
                return store.settings.susfs.maps_hide;
              },
              onChange: v => handleSusfsToggle('maps_hide', v),
              get disabled() {
                return susfsDisabled();
              }
            }), null);
            createRenderEffect(_p$ => {
              var _v$ = `settings__item settings__item--sub${susfsDisabled() ? ' settings__item--disabled' : ''}${susfsItemClass()}`,
                _v$2 = `settings__item settings__item--sub${!susfsEnabled() ? ' settings__item--disabled' : ''}`,
                _v$3 = `settings__item settings__item--sub${susfsDisabled() ? ' settings__item--disabled' : ''}${susfsItemClass()}`,
                _v$4 = `settings__item settings__item--sub${susfsDisabled() ? ' settings__item--disabled' : ''}${susfsItemClass()}`;
              _v$ !== _p$.e && className(_el$31, _p$.e = _v$);
              _v$2 !== _p$.t && className(_el$39, _p$.t = _v$2);
              _v$3 !== _p$.a && className(_el$43, _p$.a = _v$3);
              _v$4 !== _p$.o && className(_el$47, _p$.o = _v$4);
              return _p$;
            }, {
              e: undefined,
              t: undefined,
              a: undefined,
              o: undefined
            });
            return _el$30;
          })(), (() => {
            var _el$51 = _tmpl$6$1(),
              _el$52 = _el$51.firstChild,
              _el$53 = _el$52.nextSibling;
            _el$51.$$click = () => setShowAdvanced(!showAdvanced());
            insert(_el$53, () => t('susfs.advancedSettings'));
            createRenderEffect(_p$ => {
              var _v$5 = `settings__advanced-toggle${showAdvanced() ? ' settings__advanced-toggle--open' : ''}`,
                _v$6 = `settings__advanced-chevron${showAdvanced() ? ' settings__advanced-chevron--open' : ''}`;
              _v$5 !== _p$.e && className(_el$51, _p$.e = _v$5);
              _v$6 !== _p$.t && setAttribute(_el$52, "class", _p$.t = _v$6);
              return _p$;
            }, {
              e: undefined,
              t: undefined
            });
            return _el$51;
          })(), createComponent(Show, {
            get when() {
              return showAdvanced();
            },
            get children() {
              var _el$54 = _tmpl$7$1();
              insert(_el$54, createComponent(CollapsibleSubgroup, {
                get label() {
                  return t('susfs.controlLabel');
                },
                hiddenCount: 5,
                get defaultItems() {
                  return [(() => {
                    var _el$55 = _tmpl$2$3(),
                      _el$56 = _el$55.firstChild,
                      _el$57 = _el$56.firstChild,
                      _el$58 = _el$57.nextSibling;
                    insert(_el$57, () => t('susfs.emulateVoldAppData'));
                    insert(_el$58, () => t('susfs.emulateVoldAppDataDesc'));
                    insert(_el$55, createComponent(Toggle, {
                      get checked() {
                        return store.settings.brene.emulate_vold_app_data;
                      },
                      onChange: v => handleBreneToggle('emulate_vold_app_data', v)
                    }), null);
                    return _el$55;
                  })(), createComponent(Show, {
                    get when() {
                      return store.settings.brene.emulate_vold_app_data;
                    },
                    get children() {
                      var _el$59 = _tmpl$8$1(),
                        _el$60 = _el$59.firstChild,
                        _el$61 = _el$60.firstChild,
                        _el$62 = _el$61.nextSibling;
                      insert(_el$61, () => t('susfs.voldUsePathLoop'));
                      insert(_el$62, () => t('susfs.voldUsePathLoopDesc'));
                      insert(_el$59, createComponent(Toggle, {
                        get checked() {
                          return store.settings.brene.vold_use_path_loop;
                        },
                        onChange: v => handleBreneToggle('vold_use_path_loop', v)
                      }), null);
                      return _el$59;
                    }
                  })];
                },
                get expandedItems() {
                  return [(() => {
                    var _el$63 = _tmpl$2$3(),
                      _el$64 = _el$63.firstChild,
                      _el$65 = _el$64.firstChild,
                      _el$66 = _el$65.nextSibling;
                    insert(_el$65, () => t('susfs.forceHideLsposed'));
                    insert(_el$66, () => t('susfs.forceHideLsposedDesc'));
                    insert(_el$63, createComponent(Toggle, {
                      get checked() {
                        return store.settings.brene.force_hide_lsposed;
                      },
                      onChange: v => handleBreneToggle('force_hide_lsposed', v)
                    }), null);
                    return _el$63;
                  })(), (() => {
                    var _el$67 = _tmpl$2$3(),
                      _el$68 = _el$67.firstChild,
                      _el$69 = _el$68.firstChild,
                      _el$70 = _el$69.nextSibling;
                    insert(_el$69, () => t('susfs.hideKsuLoopDevices'));
                    insert(_el$70, () => t('susfs.hideKsuLoopDevicesDesc'));
                    insert(_el$67, createComponent(Toggle, {
                      get checked() {
                        return store.settings.brene.hide_ksu_loops;
                      },
                      onChange: v => handleBreneToggle('hide_ksu_loops', v)
                    }), null);
                    return _el$67;
                  })(), (() => {
                    var _el$71 = _tmpl$2$3(),
                      _el$72 = _el$71.firstChild,
                      _el$73 = _el$72.firstChild,
                      _el$74 = _el$73.nextSibling;
                    insert(_el$73, () => t('susfs.avcLogSpoofing'));
                    insert(_el$74, () => t('susfs.avcLogSpoofingDesc'));
                    insert(_el$71, createComponent(Toggle, {
                      get checked() {
                        return store.settings.brene.avc_log_spoofing;
                      },
                      onChange: v => handleBreneToggle('avc_log_spoofing', v)
                    }), null);
                    return _el$71;
                  })(), (() => {
                    var _el$75 = _tmpl$2$3(),
                      _el$76 = _el$75.firstChild,
                      _el$77 = _el$76.firstChild,
                      _el$78 = _el$77.nextSibling;
                    insert(_el$77, () => t('susfs.spoofCmdline'));
                    insert(_el$78, () => t('susfs.spoofCmdlineDesc'));
                    insert(_el$75, createComponent(Toggle, {
                      get checked() {
                        return store.settings.brene.spoof_cmdline;
                      },
                      onChange: v => handleBreneToggle('spoof_cmdline', v)
                    }), null);
                    return _el$75;
                  })(), (() => {
                    var _el$79 = _tmpl$2$3(),
                      _el$80 = _el$79.firstChild,
                      _el$81 = _el$80.firstChild,
                      _el$82 = _el$81.nextSibling;
                    insert(_el$81, () => t('susfs.susfsDebugLog'));
                    insert(_el$82, () => t('susfs.susfsDebugLogDesc'));
                    insert(_el$79, createComponent(Toggle, {
                      get checked() {
                        return store.settings.brene.susfs_log;
                      },
                      onChange: v => handleBreneToggle('susfs_log', v)
                    }), null);
                    return _el$79;
                  })()];
                }
              }), null);
              insert(_el$54, createComponent(CollapsibleSubgroup, {
                get label() {
                  return t('susfs.autoHidingLabel');
                },
                hiddenCount: 8,
                get defaultItems() {
                  return (() => {
                    var _el$83 = _tmpl$2$3(),
                      _el$84 = _el$83.firstChild,
                      _el$85 = _el$84.firstChild,
                      _el$86 = _el$85.nextSibling;
                    insert(_el$85, () => t('susfs.hideRootedAppFolders'));
                    insert(_el$86, () => t('susfs.hideRootedAppFoldersDesc'));
                    insert(_el$83, createComponent(Toggle, {
                      get checked() {
                        return store.settings.brene.auto_hide_rooted_folders;
                      },
                      onChange: v => handleBreneToggle('auto_hide_rooted_folders', v)
                    }), null);
                    return _el$83;
                  })();
                },
                get expandedItems() {
                  return [(() => {
                    var _el$87 = _tmpl$2$3(),
                      _el$88 = _el$87.firstChild,
                      _el$89 = _el$88.firstChild,
                      _el$90 = _el$89.nextSibling;
                    insert(_el$89, () => t('susfs.hideModuleInjections'));
                    insert(_el$90, () => t('susfs.hideModuleInjectionsDesc'));
                    insert(_el$87, createComponent(Toggle, {
                      get checked() {
                        return store.settings.brene.auto_hide_injections;
                      },
                      onChange: v => handleBreneToggle('auto_hide_injections', v)
                    }), null);
                    return _el$87;
                  })(), (() => {
                    var _el$91 = _tmpl$2$3(),
                      _el$92 = _el$91.firstChild,
                      _el$93 = _el$92.firstChild,
                      _el$94 = _el$93.nextSibling;
                    insert(_el$93, () => t('susfs.hideInjectedApks'));
                    insert(_el$94, () => t('susfs.hideInjectedApksDesc'));
                    insert(_el$91, createComponent(Toggle, {
                      get checked() {
                        return store.settings.brene.auto_hide_apk;
                      },
                      onChange: v => handleBreneToggle('auto_hide_apk', v)
                    }), null);
                    return _el$91;
                  })(), (() => {
                    var _el$95 = _tmpl$2$3(),
                      _el$96 = _el$95.firstChild,
                      _el$97 = _el$96.firstChild,
                      _el$98 = _el$97.nextSibling;
                    insert(_el$97, () => t('susfs.hideZygiskMaps'));
                    insert(_el$98, () => t('susfs.hideZygiskMapsDesc'));
                    insert(_el$95, createComponent(Toggle, {
                      get checked() {
                        return store.settings.brene.auto_hide_zygisk;
                      },
                      onChange: v => handleBreneToggle('auto_hide_zygisk', v)
                    }), null);
                    return _el$95;
                  })(), (() => {
                    var _el$99 = _tmpl$2$3(),
                      _el$100 = _el$99.firstChild,
                      _el$101 = _el$100.firstChild,
                      _el$102 = _el$101.nextSibling;
                    insert(_el$101, () => t('susfs.hideFontFilesMaps'));
                    insert(_el$102, () => t('susfs.hideFontFilesMapsDesc'));
                    insert(_el$99, createComponent(Toggle, {
                      get checked() {
                        return store.settings.brene.auto_hide_fonts;
                      },
                      onChange: v => handleBreneToggle('auto_hide_fonts', v)
                    }), null);
                    return _el$99;
                  })(), (() => {
                    var _el$103 = _tmpl$2$3(),
                      _el$104 = _el$103.firstChild,
                      _el$105 = _el$104.firstChild,
                      _el$106 = _el$105.nextSibling;
                    insert(_el$105, () => t('susfs.hideRecoveryFolders'));
                    insert(_el$106, () => t('susfs.hideRecoveryFoldersDesc'));
                    insert(_el$103, createComponent(Toggle, {
                      get checked() {
                        return store.settings.brene.auto_hide_recovery;
                      },
                      onChange: v => handleBreneToggle('auto_hide_recovery', v)
                    }), null);
                    return _el$103;
                  })(), (() => {
                    var _el$107 = _tmpl$2$3(),
                      _el$108 = _el$107.firstChild,
                      _el$109 = _el$108.firstChild,
                      _el$110 = _el$109.nextSibling;
                    insert(_el$109, () => t('susfs.hideDataLocalTmp'));
                    insert(_el$110, () => t('susfs.hideDataLocalTmpDesc'));
                    insert(_el$107, createComponent(Toggle, {
                      get checked() {
                        return store.settings.brene.auto_hide_tmp;
                      },
                      onChange: v => handleBreneToggle('auto_hide_tmp', v)
                    }), null);
                    return _el$107;
                  })(), (() => {
                    var _el$111 = _tmpl$2$3(),
                      _el$112 = _el$111.firstChild,
                      _el$113 = _el$112.firstChild,
                      _el$114 = _el$113.nextSibling;
                    insert(_el$113, () => t('susfs.cleanupSusMarker'));
                    insert(_el$114, () => t('susfs.cleanupSusMarkerDesc'));
                    insert(_el$111, createComponent(Toggle, {
                      get checked() {
                        return store.settings.brene.cleanup_sus_marker;
                      },
                      onChange: v => handleBreneToggle('cleanup_sus_marker', v)
                    }), null);
                    return _el$111;
                  })(), (() => {
                    var _el$115 = _tmpl$2$3(),
                      _el$116 = _el$115.firstChild,
                      _el$117 = _el$116.firstChild,
                      _el$118 = _el$117.nextSibling;
                    insert(_el$117, () => t('susfs.hideNonstandardAndroid'));
                    insert(_el$118, () => t('susfs.hideNonstandardAndroidDesc'));
                    insert(_el$115, createComponent(Toggle, {
                      get checked() {
                        return store.settings.brene.hide_nonstandard_android;
                      },
                      onChange: v => handleBreneToggle('hide_nonstandard_android', v)
                    }), null);
                    return _el$115;
                  })(), (() => {
                    var _el$119 = _tmpl$2$3(),
                      _el$120 = _el$119.firstChild,
                      _el$121 = _el$120.firstChild,
                      _el$122 = _el$121.nextSibling;
                    insert(_el$121, () => t('susfs.kernelUmount'));
                    insert(_el$122, () => t('susfs.kernelUmountDesc'));
                    insert(_el$119, createComponent(Toggle, {
                      get checked() {
                        return store.settings.brene.kernel_umount;
                      },
                      onChange: v => handleBreneToggle('kernel_umount', v)
                    }), null);
                    return _el$119;
                  })(), (() => {
                    var _el$123 = _tmpl$2$3(),
                      _el$124 = _el$123.firstChild,
                      _el$125 = _el$124.firstChild,
                      _el$126 = _el$125.nextSibling;
                    insert(_el$125, () => t('susfs.syncSuCompat'));
                    insert(_el$126, () => t('susfs.syncSuCompatDesc'));
                    insert(_el$123, createComponent(Toggle, {
                      get checked() {
                        return store.settings.brene.sync_su_compat;
                      },
                      onChange: v => handleBreneToggle('sync_su_compat', v)
                    }), null);
                    return _el$123;
                  })(), (() => {
                    var _el$127 = _tmpl$2$3(),
                      _el$128 = _el$127.firstChild,
                      _el$129 = _el$128.firstChild,
                      _el$130 = _el$129.nextSibling;
                    insert(_el$129, () => t('susfs.syncSelinuxHide'));
                    insert(_el$130, () => t('susfs.syncSelinuxHideDesc'));
                    insert(_el$127, createComponent(Toggle, {
                      get checked() {
                        return store.settings.brene.sync_selinux_hide;
                      },
                      onChange: v => handleBreneToggle('sync_selinux_hide', v)
                    }), null);
                    return _el$127;
                  })(), (() => {
                    var _el$131 = _tmpl$2$3(),
                      _el$132 = _el$131.firstChild,
                      _el$133 = _el$132.firstChild,
                      _el$134 = _el$133.nextSibling;
                    insert(_el$133, () => t('susfs.autoTryUmount'));
                    insert(_el$134, () => t('susfs.autoTryUmountDesc'));
                    insert(_el$131, createComponent(Toggle, {
                      get checked() {
                        return store.settings.brene.try_umount;
                      },
                      onChange: v => handleBreneToggle('try_umount', v)
                    }), null);
                    return _el$131;
                  })(), createComponent(Show, {
                    get when() {
                      return store.settings.brene.try_umount;
                    },
                    get children() {
                      var _el$135 = _tmpl$8$1(),
                        _el$136 = _el$135.firstChild,
                        _el$137 = _el$136.firstChild,
                        _el$138 = _el$137.nextSibling;
                      insert(_el$137, () => t('susfs.skipLegitMounts'));
                      insert(_el$138, () => t('susfs.skipLegitMountsDesc'));
                      insert(_el$135, createComponent(Toggle, {
                        get checked() {
                          return store.settings.brene.skip_legit_mounts;
                        },
                        onChange: v => handleBreneToggle('skip_legit_mounts', v)
                      }), null);
                      return _el$135;
                    }
                  })];
                }
              }), null);
              insert(_el$54, createComponent(CollapsibleSubgroup, {
                get label() {
                  return t('susfs.customRomLabel');
                },
                hiddenCount: 0,
                get defaultItems() {
                  return [(() => {
                    var _el$139 = _tmpl$2$3(),
                      _el$140 = _el$139.firstChild,
                      _el$141 = _el$140.firstChild,
                      _el$142 = _el$141.nextSibling;
                    insert(_el$141, () => t('susfs.hideCusrom'));
                    insert(_el$142, () => t('susfs.hideCusromDesc'));
                    insert(_el$139, createComponent(Toggle, {
                      get checked() {
                        return store.settings.brene.hide_cusrom > 0;
                      },
                      onChange: v => store.setBreneNumeric('hide_cusrom', v ? 1 : 0)
                    }), null);
                    return _el$139;
                  })(), createComponent(Show, {
                    get when() {
                      return store.settings.brene.hide_cusrom > 0;
                    },
                    get children() {
                      var _el$143 = _tmpl$9$1(),
                        _el$144 = _el$143.firstChild,
                        _el$145 = _el$144.firstChild,
                        _el$146 = _el$145.firstChild,
                        _el$147 = _el$145.nextSibling,
                        _el$148 = _el$144.nextSibling,
                        _el$149 = _el$148.firstChild;
                      insert(_el$145, () => t('susfs.hideCusromLevel'), _el$146);
                      insert(_el$145, () => store.settings.brene.hide_cusrom, null);
                      insert(_el$147, (() => {
                        var _c$2 = memo(() => store.settings.brene.hide_cusrom === 1);
                        return () => _c$2() ? t('susfs.hideCusromLevel1') : memo(() => store.settings.brene.hide_cusrom === 2)() ? t('susfs.hideCusromLevel2') : memo(() => store.settings.brene.hide_cusrom === 3)() ? t('susfs.hideCusromLevel3') : memo(() => store.settings.brene.hide_cusrom === 4)() ? t('susfs.hideCusromLevel4') : t('susfs.hideCusromLevel5');
                      })());
                      _el$149.$$input = e => store.setBreneNumeric('hide_cusrom', parseInt(e.currentTarget.value));
                      createRenderEffect(() => _el$149.value = store.settings.brene.hide_cusrom);
                      return _el$143;
                    }
                  })];
                }
              }), null);
              insert(_el$54, createComponent(CollapsibleSubgroup, {
                get label() {
                  return t('susfs.spoofingLabel');
                },
                hiddenCount: 0,
                get defaultItems() {
                  return (() => {
                    var _el$150 = _tmpl$0$1(),
                      _el$151 = _el$150.firstChild,
                      _el$152 = _el$151.firstChild,
                      _el$153 = _el$152.nextSibling,
                      _el$154 = _el$151.nextSibling,
                      _el$155 = _el$154.firstChild;
                    _el$150.$$click = () => setShowUnameSheet(true);
                    insert(_el$152, () => t('susfs.unameSpoofing'));
                    insert(_el$153, () => t('susfs.unameSpoofingDesc'));
                    insert(_el$155, (() => {
                      var _c$3 = memo(() => store.settings.uname.mode === 'disabled');
                      return () => _c$3() ? t('susfs.unameModeDisabled') : memo(() => store.settings.uname.mode === 'static')() ? t('susfs.unameModeStatic') : t('susfs.unameModeDynamic');
                    })());
                    return _el$150;
                  })();
                }
              }), null);
              return _el$54;
            }
          })];
        }
      }), createComponent(UnameSheet, {
        get open() {
          return showUnameSheet();
        },
        onClose: () => setShowUnameSheet(false),
        get mode() {
          return store.settings.uname.mode;
        },
        get release() {
          return store.settings.uname.release;
        },
        get version() {
          return store.settings.uname.version;
        },
        onModeChange: m => store.setUnameMode(m),
        onReleaseChange: v => store.setUnameField('release', v),
        onVersionChange: v => store.setUnameField('version', v)
      })];
    }
  });
}
delegateEvents(["click", "input"]);

var _tmpl$$2 = /*#__PURE__*/template(`<h3 class=settings__section-title>Runtime Doctor`),
  _tmpl$2$2 = /*#__PURE__*/template(`<p class=settings__item-desc>Kernel, PSI, ZRAM, SELinux, Komponenten und Cache-Alter prüfen. Liest nur; ändert keine Einstellungen. Boot-Wert-Zuständigkeit, geänderte Modulskripte und Speicherfilter-Vorschau enthalten.`),
  _tmpl$3$1 = /*#__PURE__*/template(`<pre style=white-space:pre-wrap;overflow-wrap:anywhere;max-height:30rem;overflow:auto>`);
function DoctorSection() {
  const [busy, setBusy] = createSignal(false);
  const [result, setResult] = createSignal('');
  const inspect = async () => {
    setBusy(true);
    try {
      const response = await runShell(`${escapeShellArg(PATHS.BINARY)} doctor`);
      if (response.errno !== 0) throw new Error(response.stderr || 'Diagnostic failed');
      setResult(JSON.stringify(JSON.parse(response.stdout), null, 2));
    } catch (error) {
      setResult(String(error));
    } finally {
      setBusy(false);
    }
  };
  return createComponent(Card, {
    get children() {
      return [_tmpl$$2(), _tmpl$2$2(), createComponent(Button, {
        get disabled() {
          return busy();
        },
        onClick: inspect,
        get children() {
          return busy() ? 'Prüfung läuft…' : 'Jetzt prüfen (nur lesen)';
        }
      }), createComponent(Show, {
        get when() {
          return result();
        },
        get children() {
          var _el$3 = _tmpl$3$1();
          insert(_el$3, result);
          return _el$3;
        }
      })];
    }
  });
}

var _tmpl$$1 = /*#__PURE__*/template(`<h3 class=settings__section-title><svg class=settings__section-icon viewBox="0 0 24 24"fill=currentColor><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z">`),
  _tmpl$2$1 = /*#__PURE__*/template(`<div class=settings__about><div class=logo-container><div class=logo-ring></div><div class=logo-inner><svg width=56 height=56 viewBox="0 0 24 24"fill=url(#shieldGradient)><defs><linearGradient id=shieldGradient x1=0% y1=0% x2=100% y2=100%><stop offset=0% style=stop-color:#FF6B6B></stop><stop offset=50% style=stop-color:#FF8E53></stop><stop offset=100% style=stop-color:#FFC107></stop></linearGradient></defs><path d="M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4zm0 10.99h7c-.53 4.12-3.28 7.79-7 8.94V12H5V6.3l7-3.11v8.8z"></path></svg></div></div><div class=settings__about-title></div><div class=settings__about-badge></div><button class=settings__repo-btn><svg class=settings__repo-icon viewBox="0 0 24 24"fill=currentColor><path d="M12 0c-6.626 0-12 5.373-12 12 0 5.302 3.438 9.8 8.207 11.387.599.111.793-.261.793-.577v-2.234c-3.338.726-4.033-1.416-4.033-1.416-.546-1.387-1.333-1.756-1.333-1.756-1.089-.745.083-.729.083-.729 1.205.084 1.839 1.237 1.839 1.237 1.07 1.834 2.807 1.304 3.492.997.107-.775.418-1.305.762-1.604-2.665-.305-5.467-1.334-5.467-5.931 0-1.311.469-2.381 1.236-3.221-.124-.303-.535-1.524.117-3.176 0 0 1.008-.322 3.301 1.23.957-.266 1.983-.399 3.003-.404 1.02.005 2.047.138 3.006.404 2.291-1.552 3.297-1.23 3.297-1.23.653 1.653.242 2.874.118 3.176.77.84 1.235 1.911 1.235 3.221 0 4.609-2.807 5.624-5.479 5.921.43.372.823 1.102.823 2.222v3.293c0 .319.192.694.801.576 4.765-1.589 8.199-6.086 8.199-11.386 0-6.627-5.373-12-12-12z"></path></svg></button><div class=settings__actions></div><div class=settings__footer> <span class=gradient-text></span> <!> <span class=gradient-text>`);
function AboutSection() {
  const copyDebugInfo = async () => {
    try {
      const {
        errno,
        stdout
      } = await runShell(`${PATHS.BINARY} log dump`);
      if (errno === 0) {
        const parsed = JSON.parse(stdout);
        store.showToast(t('toast.logsSaved', {
          path: parsed.zip
        }), 'success');
      } else {
        store.showToast(t('toast.failedDumpLogs'), 'error');
      }
    } catch {
      store.showToast(t('toast.failedDumpLogs'), 'error');
    }
  };
  const exportConfig = async () => {
    try {
      const {
        errno,
        stdout
      } = await runShell('cat /data/adb/zeromount/config.toml');
      if (errno !== 0 || !stdout) {
        store.showToast(t('toast.failedReadConfig'), 'error');
        return;
      }
      const backup = JSON.stringify({
        version: 1,
        backend: stdout,
        webui: {
          theme: localStorage.getItem('zeromount-theme'),
          accentColor: localStorage.getItem('zeromount-accent'),
          autoAccentColor: localStorage.getItem('zeromount-autoAccent'),
          fixedNav: localStorage.getItem('zeromount-fixedNav'),
          bgOpacity: localStorage.getItem('zeromount-bgOpacity')
        }
      }, null, 2);
      const {
        errno: writeErr
      } = await ksuWriteFile(backup, '/sdcard/Download/zeromount-backup.json');
      if (writeErr === 0) {
        store.showToast(t('toast.configExported'), 'success');
      } else {
        store.showToast(t('toast.failedExportConfig'), 'error');
      }
    } catch {
      store.showToast(t('toast.failedExportConfig'), 'error');
    }
  };
  const importConfig = () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '*/*';
    input.onchange = async () => {
      const file = input.files?.[0];
      if (!file) return;
      try {
        const content = await file.text();
        if (!content.trim()) {
          store.showToast(t('toast.emptyFile'), 'error');
          return;
        }
        let backendConfig = content;
        let webuiSettings = null;
        try {
          const parsed = JSON.parse(content);
          if (parsed.version && parsed.backend) {
            backendConfig = parsed.backend;
            webuiSettings = parsed.webui || null;
          }
        } catch {
          // Not JSON — treat as raw TOML config
        }
        const {
          errno
        } = await ksuWriteFile(backendConfig, '/data/adb/zeromount/config.toml');
        if (errno !== 0) {
          store.showToast(t('toast.failedWriteConfig'), 'error');
          return;
        }
        if (webuiSettings) {
          const keyMap = {
            theme: 'zeromount-theme',
            accentColor: 'zeromount-accent',
            autoAccentColor: 'zeromount-autoAccent',
            fixedNav: 'zeromount-fixedNav',
            bgOpacity: 'zeromount-bgOpacity'
          };
          for (const [key, storageKey] of Object.entries(keyMap)) {
            const val = webuiSettings[key];
            if (val != null) localStorage.setItem(storageKey, val);
          }
          const uiUpdates = {};
          if (webuiSettings.theme) uiUpdates.theme = webuiSettings.theme;
          if (webuiSettings.accentColor) uiUpdates.accentColor = webuiSettings.accentColor;
          if (webuiSettings.autoAccentColor != null) uiUpdates.autoAccentColor = webuiSettings.autoAccentColor === 'true';
          if (webuiSettings.fixedNav != null) uiUpdates.fixedNav = webuiSettings.fixedNav === 'true';
          if (Object.keys(uiUpdates).length) store.updateSettings(uiUpdates);
          if (webuiSettings.bgOpacity != null) store.setBgOpacity(parseFloat(webuiSettings.bgOpacity));
        }
        invalidateCache();
        await store.loadInitialData();
        store.showToast(t('toast.importedConfig', {
          filename: file.name
        }), 'success');
      } catch {
        store.showToast(t('toast.failedImportConfig'), 'error');
      }
    };
    input.click();
  };
  return createComponent(Card, {
    get children() {
      return [(() => {
        var _el$ = _tmpl$$1();
          _el$.firstChild;
        insert(_el$, () => t('about.title'), null);
        return _el$;
      })(), (() => {
        var _el$3 = _tmpl$2$1(),
          _el$4 = _el$3.firstChild,
          _el$5 = _el$4.nextSibling,
          _el$6 = _el$5.nextSibling,
          _el$7 = _el$6.nextSibling;
          _el$7.firstChild;
          var _el$9 = _el$7.nextSibling,
          _el$0 = _el$9.nextSibling,
          _el$1 = _el$0.firstChild,
          _el$10 = _el$1.nextSibling,
          _el$11 = _el$10.nextSibling,
          _el$14 = _el$11.nextSibling,
          _el$12 = _el$14.nextSibling,
          _el$13 = _el$12.nextSibling;
        insert(_el$5, () => t('about.appName'));
        insert(_el$6, () => t('about.badge'));
        _el$7.$$click = () => runShell(`am start -a android.intent.action.VIEW -d '${GITHUB_URL}'`);
        insert(_el$7, () => t('about.repository'), null);
        insert(_el$9, createComponent(Button, {
          variant: "secondary",
          size: "small",
          onClick: copyDebugInfo,
          get children() {
            return t('about.copyDebugInfo');
          }
        }), null);
        insert(_el$9, createComponent(Button, {
          variant: "secondary",
          size: "small",
          onClick: exportConfig,
          get children() {
            return t('about.exportConfig');
          }
        }), null);
        insert(_el$9, createComponent(Button, {
          variant: "secondary",
          size: "small",
          onClick: importConfig,
          get children() {
            return t('about.importConfig');
          }
        }), null);
        insert(_el$0, () => t('about.footerMadeWith'), _el$1);
        insert(_el$10, () => t('about.footerPassion'));
        insert(_el$0, () => t('about.footerForThe'), _el$14);
        insert(_el$13, () => t('about.footerCommunity'));
        return _el$3;
      })()];
    }
  });
}
delegateEvents(["click"]);

var _tmpl$ = /*#__PURE__*/template(`<h3 class=settings__section-title><svg class=settings__section-icon viewBox="0 0 24 24"fill=currentColor><path d="M19.14 12.94c.04-.31.06-.63.06-.94 0-.31-.02-.63-.06-.94l2.03-1.58c.18-.14.23-.41.12-.61l-1.92-3.32c-.12-.22-.37-.29-.59-.22l-2.39.96c-.5-.38-1.03-.7-1.62-.94l-.36-2.54c-.04-.24-.24-.41-.48-.41h-3.84c-.24 0-.43.17-.47.41l-.36 2.54c-.59.24-1.13.57-1.62.94l-2.39-.96c-.22-.08-.47 0-.59.22L2.74 8.87c-.12.21-.08.47.12.61l2.03 1.58c-.04.31-.06.63-.06.94s.02.63.06.94l-2.03 1.58c-.18.14-.23.41-.12.61l1.92 3.32c.12.22.37.29.59.22l2.39-.96c.5.38 1.03.7 1.62.94l.36 2.54c.05.24.24.41.48.41h3.84c.24 0 .44-.17.47-.41l.36-2.54c.59-.24 1.13-.56 1.62-.94l2.39.96c.22.08.47 0 .59-.22l1.92-3.32c.12-.22.07-.47-.12-.61l-2.01-1.58zM12 15.6c-1.98 0-3.6-1.62-3.6-3.6s1.62-3.6 3.6-3.6 3.6 1.62 3.6 3.6-1.62 3.6-3.6 3.6z">`),
  _tmpl$2 = /*#__PURE__*/template(`<div class=settings__engine-controls><div class=settings__item><div class=settings__item-content><div class=settings__item-label></div><div class=settings__item-desc>`),
  _tmpl$3 = /*#__PURE__*/template(`<h3 class=settings__section-title><svg class=settings__section-icon viewBox="0 0 24 24"fill=currentColor><path d="M14 2H6c-1.1 0-1.99.9-1.99 2L4 20c0 1.1.89 2 1.99 2H18c1.1 0 2-.9 2-2V8l-6-6zm2 16H8v-2h8v2zm0-4H8v-2h8v2zM13 9V3.5L18.5 9H13z">`),
  _tmpl$4 = /*#__PURE__*/template(`<div class="settings__item-desc settings__prop-note color-text-tertiary">`),
  _tmpl$5 = /*#__PURE__*/template(`<div class=settings__item><div class=settings__item-content><div class=settings__item-label></div><div class=settings__item-desc>`),
  _tmpl$6 = /*#__PURE__*/template(`<div class=settings__modal-content><p class=settings__modal-text></p><div class=settings__modal-actions>`),
  _tmpl$7 = /*#__PURE__*/template(`<div class=settings>`),
  _tmpl$8 = /*#__PURE__*/template(`<div class="settings__item-desc color-text-tertiary">`),
  _tmpl$9 = /*#__PURE__*/template(`<h3 class=settings__section-title><svg class=settings__section-icon viewBox="0 0 24 24"fill=currentColor><path d="M20.38 8.57l-1.23 1.85a8 8 0 0 1-.22 7.58H5.07A8 8 0 0 1 15.58 6.85l1.85-1.23A10 10 0 0 0 3.35 19a2 2 0 0 0 1.72 1h13.85a2 2 0 0 0 1.74-1 10 10 0 0 0-.27-10.44z"></path><path d="M10.59 15.41a2 2 0 0 0 2.83 0l5.66-8.49-8.49 5.66a2 2 0 0 0 0 2.83z">`),
  _tmpl$0 = /*#__PURE__*/template(`<h3 class=settings__section-title><svg class=settings__section-icon viewBox="0 0 24 24"fill=currentColor><circle cx=8.5 cy=9.5 r=1.5></circle><circle cx=15.5 cy=9.5 r=1.5></circle><path d="M12 18c-3.31 0-6-2.69-6-6h1.5c0 2.76 2.24 5 4.5 5s4.5-2.24 4.5-5H18c0 3.31-2.69 6-6 6z"></path><path d="M11.99 2C6.47 2 2 6.48 2 12s4.47 10 9.99 10C17.52 22 22 17.52 22 12S17.52 2 11.99 2zM12 20c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8z">`),
  _tmpl$1 = /*#__PURE__*/template(`<div><div class=settings__item-content><div class=settings__item-label></div><div class=settings__item-desc>`);
function SettingsTab() {
  const [showClearConfirm, setShowClearConfirm] = createSignal(false);
  const caps = () => store.capabilities?.() || null;
  const handleClearAll = async () => {
    await store.clearAllRules();
    setShowClearConfirm(false);
  };
  const handleBreneToggle = (key, value) => {
    store.setBreneToggle(key, value);
  };
  return (() => {
    var _el$ = _tmpl$7();
    insert(_el$, createComponent(AppearanceSection, {}), null);
    insert(_el$, createComponent(DoctorSection, {}), null);
    insert(_el$, createComponent(Card, {
      get children() {
        return [(() => {
          var _el$2 = _tmpl$();
            _el$2.firstChild;
          insert(_el$2, () => t('settings.engine'), null);
          return _el$2;
        })(), (() => {
          var _el$4 = _tmpl$2(),
            _el$5 = _el$4.firstChild,
            _el$6 = _el$5.firstChild,
            _el$7 = _el$6.firstChild,
            _el$8 = _el$7.nextSibling;
          insert(_el$7, () => t('settings.verboseLogging'));
          insert(_el$8, () => t('settings.verboseLoggingDesc'));
          insert(_el$5, createComponent(Toggle, {
            get checked() {
              return store.settings.verboseLogging;
            },
            onChange: async checked => {
              await store.setVerboseLogging(checked);
            }
          }), null);
          insert(_el$4, (() => {
            var _c$ = memo(() => !!store.settings.verboseLogging);
            return () => _c$() && (() => {
              var _el$17 = _tmpl$8();
              insert(_el$17, (() => {
                var _c$2 = memo(() => !!store.verboseDumpPath());
                return () => _c$2() ? t('settings.verboseLogsAt', {
                  path: store.verboseDumpPath()
                }) : t('settings.verboseModeActive');
              })());
              return _el$17;
            })();
          })(), null);
          insert(_el$4, createComponent(Button, {
            variant: "danger",
            fullWidth: true,
            get disabled() {
              return !caps()?.vfs_driver;
            },
            onClick: () => setShowClearConfirm(true),
            get children() {
              return memo(() => !!caps()?.vfs_driver)() ? t('settings.clearAllRules') : t('settings.vfsUnavailable');
            }
          }), null);
          return _el$4;
        })()];
      }
    }), null);
    insert(_el$, createComponent(MountEngineSection, {}), null);
    insert(_el$, createComponent(SusfsSection, {}), null);
    insert(_el$, createComponent(Card, {
      get children() {
        return [(() => {
          var _el$9 = _tmpl$3();
            _el$9.firstChild;
          insert(_el$9, () => t('settings.propertySpoofing'), null);
          return _el$9;
        })(), (() => {
          var _el$1 = _tmpl$4();
          insert(_el$1, () => t('settings.propNote'));
          return _el$1;
        })(), (() => {
          var _el$10 = _tmpl$5(),
            _el$11 = _el$10.firstChild,
            _el$12 = _el$11.firstChild,
            _el$13 = _el$12.nextSibling;
          insert(_el$12, () => t('settings.buildProperties'));
          insert(_el$13, () => t('settings.buildPropertiesDesc'));
          insert(_el$10, createComponent(Toggle, {
            get checked() {
              return store.settings.brene.prop_spoofing;
            },
            onChange: v => handleBreneToggle('prop_spoofing', v)
          }), null);
          return _el$10;
        })(), createComponent(CollapsibleSubgroup, {
          get label() {
            return t('settings.androidSettings');
          },
          hiddenCount: 2,
          defaultItems: [],
          get expandedItems() {
            return [(() => {
              var _el$18 = _tmpl$5(),
                _el$19 = _el$18.firstChild,
                _el$20 = _el$19.firstChild,
                _el$21 = _el$20.nextSibling;
              insert(_el$20, () => t('settings.developerOptions'));
              insert(_el$21, () => t('settings.developerOptionsDesc'));
              insert(_el$18, createComponent(Toggle, {
                get checked() {
                  return store.settings.adb.developer_options;
                },
                onChange: async v => {
                  store.setAdbToggle('developer_options', v);
                  await runShell(`settings put global development_settings_enabled ${v ? 1 : 0}`);
                }
              }), null);
              return _el$18;
            })(), (() => {
              var _el$22 = _tmpl$5(),
                _el$23 = _el$22.firstChild,
                _el$24 = _el$23.firstChild,
                _el$25 = _el$24.nextSibling;
              insert(_el$24, () => t('settings.usbDebugging'));
              insert(_el$25, () => t('settings.developerOptionsDesc'));
              insert(_el$22, createComponent(Toggle, {
                get checked() {
                  return store.settings.adb.usb_debugging;
                },
                onChange: async v => {
                  store.setAdbToggle('usb_debugging', v);
                  await runShell(`settings put global adb_enabled ${v ? 1 : 0}`);
                }
              }), null);
              return _el$22;
            })()];
          }
        })];
      }
    }), null);
    insert(_el$, createComponent(CollapsibleSubgroup, {
      get label() {
        return t('settings.more');
      },
      hiddenCount: 2,
      defaultItems: [],
      get expandedItems() {
        return [createComponent(Card, {
          get children() {
            return [(() => {
              var _el$26 = _tmpl$9();
                _el$26.firstChild;
              insert(_el$26, () => t('settings.performance'), null);
              return _el$26;
            })(), (() => {
              var _el$28 = _tmpl$5(),
                _el$29 = _el$28.firstChild,
                _el$30 = _el$29.firstChild,
                _el$31 = _el$30.nextSibling;
              insert(_el$30, () => t('settings.perfTweak'));
              insert(_el$31, () => t('settings.perfTweakDesc'));
              insert(_el$28, createComponent(Toggle, {
                get checked() {
                  return store.settings.perf.enabled;
                },
                onChange: v => store.setPerfToggle('enabled', v)
              }), null);
              return _el$28;
            })()];
          }
        }), createComponent(Card, {
          get children() {
            return [(() => {
              var _el$32 = _tmpl$0();
                _el$32.firstChild;
              insert(_el$32, () => t('settings.emoji'), null);
              return _el$32;
            })(), (() => {
              var _el$34 = _tmpl$1(),
                _el$35 = _el$34.firstChild,
                _el$36 = _el$35.firstChild,
                _el$37 = _el$36.nextSibling;
              insert(_el$36, () => t('settings.facebookEmojis'));
              insert(_el$37, (() => {
                var _c$3 = memo(() => !!store.emojiConflict());
                return () => _c$3() ? t('settings.emojiConflict', {
                  module: store.emojiConflict()
                }) : t('settings.facebookEmojisDesc');
              })());
              insert(_el$34, createComponent(Toggle, {
                get checked() {
                  return store.settings.emoji.enabled;
                },
                onChange: v => store.setEmojiToggle('enabled', v),
                get disabled() {
                  return !!store.emojiConflict();
                }
              }), null);
              createRenderEffect(() => className(_el$34, `settings__item${store.emojiConflict() ? ' settings__item--disabled' : ''}`));
              return _el$34;
            })()];
          }
        })];
      }
    }), null);
    insert(_el$, createComponent(AboutSection, {}), null);
    insert(_el$, createComponent(Modal, {
      get open() {
        return showClearConfirm();
      },
      onClose: () => setShowClearConfirm(false),
      get title() {
        return t('modal.clearAllRulesTitle');
      },
      get children() {
        var _el$14 = _tmpl$6(),
          _el$15 = _el$14.firstChild,
          _el$16 = _el$15.nextSibling;
        insert(_el$15, () => t('modal.clearAllRulesText', {
          count: store.stats.activeRules
        }));
        insert(_el$16, createComponent(Button, {
          variant: "ghost",
          onClick: () => setShowClearConfirm(false),
          get children() {
            return t('modal.cancel');
          }
        }), null);
        insert(_el$16, createComponent(Button, {
          variant: "danger",
          onClick: handleClearAll,
          get loading() {
            return store.loading.rules;
          },
          get children() {
            return t('modal.clearAll');
          }
        }), null);
        return _el$14;
      }
    }), null);
    return _el$;
  })();
}

export { SettingsTab };
