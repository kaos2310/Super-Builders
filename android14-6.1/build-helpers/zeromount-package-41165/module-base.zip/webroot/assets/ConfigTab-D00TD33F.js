import { c as createSignal, o as onMount, s as store, j as createEffect, k as onCleanup, a as createMemo, i as insert, b as createComponent, t, e as createRenderEffect, g as setAttribute, d as Show, F as For, B as Button, m as memo, C as Card, T as Toggle, S as Skeleton, h as template, u as use, f as className, l as delegateEvents } from './index-G610StableDS.js';
import { I as Input } from './Input-BCVrpK5n.js';
import { B as Badge } from './Badge-2OSksFSs.js';

var _tmpl$ = /*#__PURE__*/template(`<div><img class=config__icon-img><svg viewBox="0 0 24 24"class=config__icon-fallback><path d="M17 1.01L7 1c-1.1 0-2 .9-2 2v18c0 1.1.9 2 2 2h10c1.1 0 2-.9 2-2V3c0-1.1-.9-1.99-2-1.99zM17 19H7V5h10v14z">`),
  _tmpl$2 = /*#__PURE__*/template(`<div class="config__section-header config__section-header--clickable"><h3 class=config__section-title><svg width=18 height=18 viewBox="0 0 24 24"><path d="M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4z"></path></svg></h3><div class=config__section-right><svg width=24 height=24 viewBox="0 0 24 24"fill=currentColor><path d="M7 10l5 5 5-5z">`),
  _tmpl$3 = /*#__PURE__*/template(`<p class=config__section-desc>`),
  _tmpl$4 = /*#__PURE__*/template(`<div class=config__apps>`),
  _tmpl$5 = /*#__PURE__*/template(`<div class=config__section-header><h3 class=config__section-title><svg width=18 height=18 viewBox="0 0 24 24"><path d="M4 8h4V4H4v4zm6 12h4v-4h-4v4zm-6 0h4v-4H4v4zm0-6h4v-4H4v4zm6 0h4v-4h-4v4zm6-10v4h4V4h-4zm-6 4h4V4h-4v4zm6 6h4v-4h-4v4zm0 6h4v-4h-4v4z">`),
  _tmpl$6 = /*#__PURE__*/template(`<div class=config__system-toggle><span class=config__system-label>`),
  _tmpl$7 = /*#__PURE__*/template(`<div class="config__apps config__apps--scrollable">`),
  _tmpl$8 = /*#__PURE__*/template(`<div class=config><div class=config__toolbar><div class=config__search><svg width=20 height=20 viewBox="0 0 24 24"class=config__search-icon><path d="M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z">`),
  _tmpl$9 = /*#__PURE__*/template(`<div class=config__empty>`),
  _tmpl$0 = /*#__PURE__*/template(`<div class="config__app config__app--excluded"><div class=config__app-info><div class=config__app-name></div><div class=config__app-package>`),
  _tmpl$1 = /*#__PURE__*/template(`<div class="config__app config__app--skeleton"><div class=config__skeleton-info>`),
  _tmpl$10 = /*#__PURE__*/template(`<span class=config__sys-badge>`),
  _tmpl$11 = /*#__PURE__*/template(`<div class="config__app config__app--available"><div class=config__app-info><div class="config__app-name config__app-name--with-badge"></div><div class="config__app-package config__app-package--small">`);
const theme = () => store.currentTheme();
const iconCache = new Map();
const observers = new Set();
const loadIcon = (packageName, imgEl) => {
  const showFallback = () => {
    imgEl.style.display = 'none';
    const fallback = imgEl.nextElementSibling;
    if (fallback) fallback.style.display = 'block';
  };
  if (iconCache.has(packageName)) {
    imgEl.src = iconCache.get(packageName);
    imgEl.style.opacity = '1';
    return;
  }
  if (typeof globalThis.ksu !== 'undefined') {
    const url = `ksu://icon/${packageName}`;
    iconCache.set(packageName, url);
    imgEl.src = url;
    imgEl.style.opacity = '1';
    imgEl.onerror = () => showFallback();
    return;
  }
  showFallback();
};
const setupIconObserver = (container, packageName) => {
  const imgEl = container.querySelector('img');
  if (!imgEl) return;
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        loadIcon(packageName, imgEl);
        observer.unobserve(container);
        observer.disconnect();
        observers.delete(observer);
      }
    });
  }, {
    rootMargin: '100px',
    threshold: 0.1
  });
  observers.add(observer);
  observer.observe(container);
};
const AppIcon = props => {
  const size = props.size || 40;
  const imgSize = size - 8;
  const fallbackSize = size - 12;
  const sizeClass = size === 40 ? 'config__icon--40' : 'config__icon--36';
  return (() => {
    var _el$ = _tmpl$(),
      _el$2 = _el$.firstChild,
      _el$3 = _el$2.nextSibling;
    use(el => el && setupIconObserver(el, props.packageName), _el$);
    className(_el$, `config__icon ${sizeClass}`);
    _el$2.addEventListener("error", e => {
      e.target.style.display = 'none';
      e.target.nextElementSibling?.removeAttribute('style');
    });
    setAttribute(_el$2, "width", imgSize);
    setAttribute(_el$2, "height", imgSize);
    setAttribute(_el$3, "width", fallbackSize);
    setAttribute(_el$3, "height", fallbackSize);
    createRenderEffect(() => setAttribute(_el$3, "fill", theme().textTertiary));
    return _el$;
  })();
};
function ConfigTab() {
  const [searchQuery, setSearchQuery] = createSignal('');
  const [debouncedQuery, setDebouncedQuery] = createSignal('');
  const [showSystemApps, setShowSystemApps] = createSignal(false);
  const [excludedExpanded, setExcludedExpanded] = createSignal(false);
  let debounceTimer;
  onMount(() => {
    store.loadInstalledApps();
  });
  createEffect(() => {
    const query = searchQuery();
    clearTimeout(debounceTimer);
    debounceTimer = window.setTimeout(() => {
      setDebouncedQuery(query);
    }, 300);
  });
  onCleanup(() => {
    if (debounceTimer) clearTimeout(debounceTimer);
    store.stopPolling();
    observers.forEach(obs => obs.disconnect());
    observers.clear();
  });
  const excludedUidSet = createMemo(() => new Set(store.excludedUids().map(e => e.uid)));
  const filteredExcluded = createMemo(() => {
    const query = debouncedQuery().toLowerCase();
    const excluded = store.excludedUids();
    if (!query) return excluded;
    return excluded.filter(item => item.appName.toLowerCase().includes(query) || item.packageName.toLowerCase().includes(query) || item.uid.toString().includes(query));
  });
  const filteredApps = createMemo(() => {
    const query = debouncedQuery().toLowerCase();
    const excluded = excludedUidSet();
    let apps = store.installedApps().filter(app => !excluded.has(app.uid));
    if (!showSystemApps()) {
      apps = apps.filter(app => !app.isSystemApp);
    }
    if (query) {
      apps = apps.filter(app => app.appName.toLowerCase().includes(query) || app.packageName.toLowerCase().includes(query) || app.uid.toString().includes(query));
    }
    return apps.sort((a, b) => a.appName.localeCompare(b.appName));
  });
  const handleExcludeApp = async app => {
    await store.excludeUid(app.uid, app.packageName, app.appName);
  };
  return (() => {
    var _el$4 = _tmpl$8(),
      _el$5 = _el$4.firstChild,
      _el$6 = _el$5.firstChild,
      _el$7 = _el$6.firstChild;
    insert(_el$6, createComponent(Input, {
      get placeholder() {
        return t('config.searchPlaceholder');
      },
      get value() {
        return searchQuery();
      },
      onInput: e => setSearchQuery(e.currentTarget.value),
      fullWidth: true
    }), _el$7);
    insert(_el$4, createComponent(Card, {
      get children() {
        return [(() => {
          var _el$8 = _tmpl$2(),
            _el$9 = _el$8.firstChild,
            _el$0 = _el$9.firstChild,
            _el$1 = _el$9.nextSibling,
            _el$10 = _el$1.firstChild;
          _el$8.$$click = () => setExcludedExpanded(!excludedExpanded());
          insert(_el$9, () => t('config.excludedApps'), null);
          insert(_el$1, createComponent(Badge, {
            variant: "error",
            size: "small",
            get children() {
              return store.excludedUids().length;
            }
          }), _el$10);
          createRenderEffect(_p$ => {
            var _v$ = theme().colorError,
              _v$2 = `config__chevron ${excludedExpanded() ? 'config__chevron--expanded' : ''}`;
            _v$ !== _p$.e && setAttribute(_el$0, "fill", _p$.e = _v$);
            _v$2 !== _p$.t && setAttribute(_el$10, "class", _p$.t = _v$2);
            return _p$;
          }, {
            e: undefined,
            t: undefined
          });
          return _el$8;
        })(), createComponent(Show, {
          get when() {
            return excludedExpanded();
          },
          get children() {
            return [(() => {
              var _el$11 = _tmpl$3();
              insert(_el$11, () => t('config.excludedDesc'));
              return _el$11;
            })(), createComponent(Show, {
              get when() {
                return filteredExcluded().length > 0;
              },
              get fallback() {
                return (() => {
                  var _el$19 = _tmpl$9();
                  insert(_el$19, (() => {
                    var _c$2 = memo(() => !!debouncedQuery());
                    return () => _c$2() ? t('config.excludedNoMatches') : t('config.excludedNone');
                  })());
                  return _el$19;
                })();
              },
              get children() {
                var _el$12 = _tmpl$4();
                insert(_el$12, createComponent(For, {
                  get each() {
                    return filteredExcluded();
                  },
                  children: item => (() => {
                    var _el$20 = _tmpl$0(),
                      _el$21 = _el$20.firstChild,
                      _el$22 = _el$21.firstChild,
                      _el$23 = _el$22.nextSibling;
                    insert(_el$20, createComponent(AppIcon, {
                      get packageName() {
                        return item.packageName;
                      },
                      size: 40
                    }), _el$21);
                    insert(_el$22, () => item.appName);
                    insert(_el$23, () => item.packageName);
                    insert(_el$20, createComponent(Button, {
                      variant: "ghost",
                      size: "small",
                      onClick: e => {
                        e.stopPropagation();
                        store.includeUid(item.uid);
                      },
                      get style() {
                        return `color: ${theme().colorError}; padding: 6px 10px;`;
                      },
                      get children() {
                        return t('config.remove');
                      }
                    }), null);
                    return _el$20;
                  })()
                }));
                return _el$12;
              }
            })];
          }
        })];
      }
    }), null);
    insert(_el$4, createComponent(Card, {
      get children() {
        return [(() => {
          var _el$13 = _tmpl$5(),
            _el$14 = _el$13.firstChild,
            _el$15 = _el$14.firstChild;
          insert(_el$14, (() => {
            var _c$ = memo(() => !!showSystemApps());
            return () => _c$() ? t('config.allApps') : t('config.userApps');
          })(), null);
          insert(_el$13, createComponent(Badge, {
            variant: "info",
            size: "small",
            get children() {
              return filteredApps().length;
            }
          }), null);
          createRenderEffect(() => setAttribute(_el$15, "fill", theme().textAccent));
          return _el$13;
        })(), (() => {
          var _el$16 = _tmpl$6(),
            _el$17 = _el$16.firstChild;
          insert(_el$17, () => t('config.systemApps'));
          insert(_el$16, createComponent(Toggle, {
            get checked() {
              return showSystemApps();
            },
            onChange: setShowSystemApps
          }), null);
          return _el$16;
        })(), createComponent(Show, {
          get when() {
            return !store.loading.apps;
          },
          get fallback() {
            return (() => {
              var _el$24 = _tmpl$4();
              insert(_el$24, createComponent(For, {
                each: [1, 2, 3, 4, 5],
                children: () => (() => {
                  var _el$25 = _tmpl$1(),
                    _el$26 = _el$25.firstChild;
                  insert(_el$25, createComponent(Skeleton, {
                    width: "36px",
                    height: "36px",
                    borderRadius: "10px"
                  }), _el$26);
                  insert(_el$26, createComponent(Skeleton, {
                    width: "120px",
                    height: "16px",
                    borderRadius: "6px"
                  }), null);
                  insert(_el$26, createComponent(Skeleton, {
                    width: "180px",
                    height: "12px",
                    borderRadius: "4px"
                  }), null);
                  insert(_el$25, createComponent(Skeleton, {
                    width: "64px",
                    height: "28px",
                    borderRadius: "14px"
                  }), null);
                  return _el$25;
                })()
              }));
              return _el$24;
            })();
          },
          get children() {
            return createComponent(Show, {
              get when() {
                return filteredApps().length > 0;
              },
              get fallback() {
                return (() => {
                  var _el$27 = _tmpl$9();
                  insert(_el$27, (() => {
                    var _c$3 = memo(() => !!debouncedQuery());
                    return () => _c$3() ? t('config.appsNoMatches') : memo(() => !!showSystemApps())() ? t('config.appsNoAll') : t('config.appsNoUser');
                  })());
                  return _el$27;
                })();
              },
              get children() {
                var _el$18 = _tmpl$7();
                insert(_el$18, createComponent(For, {
                  get each() {
                    return filteredApps();
                  },
                  children: app => (() => {
                    var _el$28 = _tmpl$11(),
                      _el$29 = _el$28.firstChild,
                      _el$30 = _el$29.firstChild,
                      _el$32 = _el$30.nextSibling;
                    insert(_el$28, createComponent(AppIcon, {
                      get packageName() {
                        return app.packageName;
                      },
                      size: 36
                    }), _el$29);
                    insert(_el$30, () => app.appName, null);
                    insert(_el$30, createComponent(Show, {
                      get when() {
                        return app.isSystemApp;
                      },
                      get children() {
                        var _el$31 = _tmpl$10();
                        insert(_el$31, () => t('config.sysBadge'));
                        return _el$31;
                      }
                    }), null);
                    insert(_el$32, () => app.packageName);
                    insert(_el$28, createComponent(Button, {
                      variant: "ghost",
                      size: "small",
                      onClick: () => handleExcludeApp(app),
                      style: "padding: 6px 10px;",
                      get children() {
                        return t('config.exclude');
                      }
                    }), null);
                    return _el$28;
                  })()
                }));
                return _el$18;
              }
            });
          }
        })];
      }
    }), null);
    createRenderEffect(() => setAttribute(_el$7, "fill", theme().textTertiary));
    return _el$4;
  })();
}
delegateEvents(["click"]);

export { ConfigTab };
