const BIN='/data/adb/modules/meta-zeromount/bin/zm';
export const KINDS=['path','path-loop','map','kstat-static','kstat-clone','kstat-redirect'];
export const STAT_FIELDS=['ino','dev','nlink','size','atime_sec','atime_nsec','mtime_sec','mtime_nsec','ctime_sec','ctime_nsec','blksize','blocks'];
export const quote=value=>`'${String(value).replaceAll("'", "'\"'\"'")}'`;
export function assertSafeNumbers(value) {
  if(typeof value==='number' && !Number.isSafeInteger(value)) throw new Error('Ganzzahl außerhalb des sicheren Browserbereichs. Mit der CLI bearbeiten.');
  if(value && typeof value==='object') for(const item of Object.values(value)) assertSafeNumbers(item);
}
export function command(action,document) {
  if(!['status','preview','save','apply'].includes(action)) throw new Error('Ungültige Aktion');
  if(action==='status'||action==='apply') return `${BIN} susfs-rules ${action}`;
  assertSafeNumbers(document);
  if(document?.schema!==1||!Number.isSafeInteger(document.revision)||document.revision<0||!Array.isArray(document.rules)) throw new Error('Ungültiges Regeldokument');
  const text=JSON.stringify(document); if(new TextEncoder().encode(text).length>65536) throw new Error('Maximal 64 KiB');
  return `${BIN} susfs-rules ${action} ${quote(text)}${action==='save'?` --expected-revision ${document.revision}`:''}`;
}
export function makeRule({id,enabled,target,kind,reference,values={}}) {
  if(!KINDS.includes(kind)||!id.match(/^[A-Za-z0-9_-]{1,48}$/)) throw new Error('Ungültige Kennung oder Funktion');
  const path=p=>{if(!p.startsWith('/')||p.length<2||new TextEncoder().encode(p).length>=256||/[\x00-\x1f\x7f]/.test(p)||p.slice(1).split('/').some(x=>!x||x==='.'||x==='..')) throw new Error('Absoluter, normalisierter Pfad mit höchstens 255 Bytes erforderlich');};
  path(target); const operation={kind};
  if(kind==='kstat-clone'||kind==='kstat-redirect') {path(reference);if(target===reference) throw new Error('Ziel und Referenz müssen sich unterscheiden');operation.reference=reference;}
  if(kind==='kstat-static') {
    operation.values={};
    for(const field of STAT_FIELDS) {
      const raw=values[field]; if(raw===undefined||raw===null||raw==='') continue;
      if(!/^-?\d+$/.test(String(raw))) throw new Error(`Ganzzahl erforderlich: ${field}`);
      const n=Number(raw); if(!Number.isSafeInteger(n)) throw new Error(`Wert zu groß für den Browser: ${field}`);
      if(!field.endsWith('_sec')&&n<0) throw new Error(`Negativer Wert: ${field}`);
      if(field.endsWith('_nsec')&&n>=1e9) throw new Error('Nanosekunden müssen unter 1000000000 liegen');
      if(field==='nlink'&&n>4294967295) throw new Error('nlink überschreitet 32 Bit');
      operation.values[field]=n;
    }
  }
  return {id,enabled:!!enabled,target,operation};
}
let serial=0;
export function exec(command,scope=globalThis) {
  return new Promise((resolve,reject)=>{
    if(typeof scope.ksu?.exec!=='function') return reject(new Error('Im Root-Manager öffnen'));
    const name=`zm_rules_${Date.now()}_${serial++}`;
    const cleanup=()=>{clearTimeout(timer);delete scope[name];};
    const timer=setTimeout(()=>{cleanup();reject(new Error('Zeitlimit. Status erneut laden, bevor weitere Änderungen erfolgen.'));},30000);
    scope[name]=(code,stdout,stderr)=>{cleanup();Number(code)===0?resolve(String(stdout)):reject(new Error(String(stderr||stdout||`Exit ${code}`)));};
    try{scope.ksu.exec(command,'{}',name);}catch(e){cleanup();reject(e);}
  });
}
export function start(doc,scope=globalThis,run=exec) {
  const $=id=>doc.getElementById(id); let draft=null,busy=false,known=false,editing=null;
  const buttons=['refresh','preview','save','apply','add','clear'];
  const message=t=>{$('message').textContent=t;};
  function controls() {for(const id of buttons) $(id).disabled=busy||(id!=='refresh'&&!known);}
  function report(r) {
    const c=r.compatibility??{};
    $('kernel').textContent=`SUSFS: ${c.kernel_reported_version??'nicht verfügbar'}\nABI geprüft: ${c.abi_supported?'ja':'nein'}\n${(c.features??[]).join('\n')}`;
    $('reboot').hidden=!r.reboot_required;
    $('reboot').textContent='Eine bereits versuchte Regel wurde geändert, entfernt oder nicht sicher abgeschlossen. Zur vollständigen Übernahme ist ein Neustart erforderlich.';
    $('checks').textContent=(r.checks??[]).map(x=>`${x.id}: ${!x.enabled?'deaktiviert':x.ready?'Voraussetzungen erfüllt':'ausstehend'}${x.error?' — '+x.error:''}${x.last_attempt?'\nLetzter Versuch: '+x.last_attempt.state+' — '+x.last_attempt.detail:''}`).join('\n\n');
  }
  function fields() {$('reference-label').hidden=!['kstat-clone','kstat-redirect'].includes($('kind').value);$('stat-fields').hidden=$('kind').value!=='kstat-static';}
  function reset() {editing=null;$('rule-id').value='';$('target').value='';$('reference').value='';$('kind').value='path';$('enabled').checked=true;for(const key of STAT_FIELDS) $(`stat-${key}`).value='';fields();}
  function render() {
    $('rules').replaceChildren();
    if(!draft.rules.length) {$('rules').textContent='Noch keine eigenen Regeln.';return;}
    for(const rule of draft.rules) {
      const row=doc.createElement('div');row.className='rule';const title=doc.createElement('strong');title.textContent=`${rule.id} · ${rule.operation.kind} · ${rule.enabled?'aktiviert':'aus'}`;
      const path=doc.createElement('div');path.textContent=rule.target+(rule.operation.reference?' ← '+rule.operation.reference:'');
      const edit=doc.createElement('button');edit.textContent='Bearbeiten';edit.onclick=()=>{if(busy)return;editing=rule.id;$('rule-id').value=rule.id;$('kind').value=rule.operation.kind;$('target').value=rule.target;$('reference').value=rule.operation.reference??'';$('enabled').checked=rule.enabled;for(const key of STAT_FIELDS) $(`stat-${key}`).value=rule.operation.values?.[key]??'';fields();};
      const remove=doc.createElement('button');remove.textContent='Aus Entwurf entfernen';remove.onclick=()=>{if(busy)return;draft.rules=draft.rules.filter(x=>x.id!==rule.id);if(editing===rule.id)reset();render();message('Entwurf geändert. Aktive Kernel-Regeln bleiben bis zum Neustart bestehen.');};
      row.append(title,path,edit,remove);$('rules').append(row);
    }
  }
  async function refresh() {
    if(busy)return;busy=true;known=false;controls();
    try {const r=JSON.parse(await run(command('status'),scope));assertSafeNumbers(r.document);command('preview',r.document);draft=r.document;report(r);known=true;render();reset();message('Gespeicherten Stand gelesen.');}
    catch(e){message(`Fehler: ${e.message}`);}finally{busy=false;controls();}
  }
  async function action(kind) {
    if(busy||!known)return;
    if(kind==='apply'&&!scope.confirm('Gespeicherte Regeln jetzt an den Kernel senden? Aktive Regeln lassen sich erst durch einen Neustart vollständig entfernen. Ungespeicherte Entwürfe werden nicht angewandt.'))return;
    busy=true;controls();
    try {
      if(kind==='preview') {report(JSON.parse(await run(command('preview',draft),scope)));message('Entwurf geprüft. Nichts gespeichert oder angewandt.');}
      else if(kind==='save') {const r=JSON.parse(await run(command('save',draft),scope));assertSafeNumbers(r.document);draft=r.document;const verify=JSON.parse(await run(command('status'),scope));if(JSON.stringify(verify.document)!==JSON.stringify(draft))throw new Error('Gespeicherter Stand hat sich geändert; bitte neu laden');report(verify);render();message('Gespeichert und zurückgelesen. Anwendung beim nächsten Boot oder über „Jetzt anwenden“.');}
      else {const r=JSON.parse(await run(command('apply'),scope));const status=JSON.parse(await run(command('status'),scope));report(status);message(JSON.stringify(r.results));}
    } catch(e){known=false;message(`Vorgang nicht bestätigt: ${e.message}. Gespeicherten Stand neu laden.`);}
    finally{busy=false;controls();}
  }
  for(const key of STAT_FIELDS) {const label=doc.createElement('label');label.textContent=key;const input=doc.createElement('input');input.id=`stat-${key}`;input.inputMode='numeric';label.append(input);$('stat-inputs').append(label);}
  $('editor').addEventListener('submit',event=>{event.preventDefault();if(busy||!known)return;try{const values=Object.fromEntries(STAT_FIELDS.map(k=>[k,$(`stat-${k}`).value]));const rule=makeRule({id:$('rule-id').value,enabled:$('enabled').checked,target:$('target').value,kind:$('kind').value,reference:$('reference').value,values});if(draft.rules.some(r=>r.id===rule.id&&r.id!==editing))throw new Error('Kennung schon vorhanden');draft.rules=draft.rules.filter(r=>r.id!==editing);draft.rules.push(rule);render();reset();message('Entwurf geändert; noch nicht gespeichert.');}catch(e){message(e.message);}});
  $('kind').addEventListener('change',fields);$('clear').onclick=reset;$('refresh').onclick=refresh;
  for(const kind of ['preview','save','apply']) $(kind).onclick=()=>action(kind);
  return refresh();
}
if(typeof document!=='undefined') start(document);
