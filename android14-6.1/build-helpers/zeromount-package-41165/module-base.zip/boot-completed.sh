#!/system/bin/sh
MODDIR="${0%/*}"

. "$MODDIR/common.sh"

# Synchronize the native BRENE stage with both user-controlled master switches.
"$MODDIR/bin/zm-susfs-owner" prepare || { echo "ZeroMount SuSFS profile validation failed" >&2; exit 1; }
rm -f /data/adb/zeromount/.bootcount /data/adb/zeromount/.bootguard-bootid /data/adb/zeromount/.bootguard-success /data/adb/zeromount/.bootguard-retry
[ -z "$ABI" ] && exit 0
[ -x "$BIN" ] || exit 0

if ! "$MODDIR/bin/zm" boot-values > /data/adb/zeromount/.boot-values.log 2>&1; then
    echo "zeromount: boot-value owner failed; see Runtime Doctor" > /dev/kmsg 2>/dev/null
fi

"$MODDIR/bin/zm" prop-watch 2>/dev/null || true

# Guard6.3: retry only rules that were still pending during post-fs-data.
if [ -x "$MODDIR/bin/zm-open-redirect" ]; then
    "$MODDIR/bin/zm-susfs-owner" run susfs open-redirect-late "$MODDIR/bin/zm-open-redirect" apply late > /data/adb/zeromount/.open-redirect-late.log 2>&1 || \
        echo "zeromount: late OPEN_REDIRECT replay had failures; see .open-redirect-late.log" > /dev/kmsg 2>/dev/null
fi

# Guard6.6: retry the managed Droidspaces VFS bridge after Android boot if its source
# was not ready during post-fs-data, or confirm that the early rule is still active.
if [ -x "$MODDIR/bin/zm-droidspaces-vfs" ]; then
    "$MODDIR/bin/zm-droidspaces-vfs" apply late > /data/adb/zeromount/.droidspaces-vfs-late.log 2>&1 || \
        echo "zeromount: late Droidspaces VFS bridge pending/failed; see .droidspaces-vfs-late.log" > /dev/kmsg 2>/dev/null
fi

if ! "$BIN" hide-paths 2>/dev/null; then
    echo "zeromount: deferred hide-paths failed" > /dev/kmsg 2>/dev/null
fi


# Guard6.13: explicit user rules; empty by default, acknowledged rules deduplicated per boot.
if ! "$MODDIR/bin/zm-susfs-owner" run susfs guard-rules "$BIN" susfs-rules apply > /data/adb/zeromount/.susfs-rules-late.log 2>&1; then
    echo "zeromount: SUSFS user rules pending/failed; inspect SUSFS Rules" > /dev/kmsg 2>/dev/null
fi

"$BIN" emoji apply-apps 2>/dev/null || true

if [ "$("$BIN" config get brene.try_umount 2>/dev/null)" = "true" ]; then
    "$BIN" try-umount 2>/dev/null || true
fi

if [ "$("$BIN" config get brene.emulate_vold_app_data 2>/dev/null)" = "true" ]; then
    _waited=0
    until [ -d "/sdcard/Android/data" ] || [ $_waited -ge 180 ]; do
        sleep 1
        _waited=$((_waited + 1))
    done
    [ $_waited -ge 180 ] && echo "zeromount: vold-app-data skipped, /sdcard/Android/data not ready after 180s" > /dev/kmsg 2>/dev/null
    [ -d "/sdcard/Android/data" ] && "$BIN" vold-app-data 2>/dev/null || true
fi

start logd
echo "zeromount: logd health check (start)" > /dev/kmsg 2>/dev/null

# Refresh UI cache after native deferred counters have been persisted.
_cache=$("$BIN" webui-init 2>/dev/null)
case "$_cache" in
    \{*)
        printf '%s\n' "$_cache" > "$MODDIR/webroot/cache.json"
        # Native JSON is serialized; an external script file has no HTML-script boundary.
        printf 'window.__ZM_CACHE__=%s;\n' "$_cache" > "$MODDIR/webroot/zm-init.js"
        ;;
esac

# BRENE71 optional features share the existing late boot callback.
"$MODDIR/bin/zm" brene75 late > /data/adb/zeromount/.brene75-late.log 2>&1 || echo "zeromount: BRENE71 feature pending/failed; inspect .brene75-late.log" > /dev/kmsg 2>/dev/null
