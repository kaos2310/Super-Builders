#!/system/bin/sh
MODDIR="${0%/*}"
# Release ownership first. Peer guards immediately resume their original behavior.
rm -f "$MODDIR/boot-values-owner"
. "$MODDIR/common.sh"
if [ -x "$BIN" ]; then
    "$BIN" writer-adapters --restore > /data/adb/zeromount/.writer-restore.log 2>&1 || true
fi
# Remove skip_mount flags we created
if [ -f /data/adb/zeromount/.skipped_modules ]; then
    while IFS= read -r mod_id; do
        rm -f "/data/adb/modules/${mod_id}/skip_mount"
    done < /data/adb/zeromount/.skipped_modules
fi

ZM_DATA="/data/adb/zeromount"
STASH="$ZM_DATA/.stash"

mkdir -p "$STASH"
cp "$ZM_DATA/config.toml" "$STASH/config.toml" 2>/dev/null
cp "$ZM_DATA/config.toml.bak" "$STASH/config.toml.bak" 2>/dev/null

# Keep original peer scripts even when a newer peer version prevents automatic restore.
find "$ZM_DATA" -mindepth 1 -not -path "$STASH" -not -path "$STASH/*" \
    -not -path "$ZM_DATA/writer-backups" -not -path "$ZM_DATA/writer-backups/*" \
    -not -path "$ZM_DATA/.writer-restore.log" -exec rm -rf {} + 2>/dev/null

# Guard6.6 managed Droidspaces bridge state is ZeroMount-owned only.
rm -f /data/adb/zeromount/droidspaces_vfs.status /data/adb/zeromount/droidspaces_vfs.log \
      /data/adb/zeromount/.droidspaces-vfs-early.log /data/adb/zeromount/.droidspaces-vfs-late.log 2>/dev/null || true
rm -rf "$MODDIR/.vfs-stage" 2>/dev/null || true
