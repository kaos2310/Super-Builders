# ZeroMount Guard6.13 r3.2 BootGuard1

This ZIP is derived from the supplied r3.1.uidgate2 ARM64 ZIP. Its native
ZeroMount binary (SHA256 `1a0b25246a54746ebe89fb210ffbc8217f6227d9f5a04e964630e50228bea036`)
and the existing UIDGate boot-values wrapper retain their original behavior.
BRENE 69, SUSFS rules, OPEN_REDIRECT, Droidspaces, WebUI and peer adapters
remain in the package.

The new `bin/zm-bootguard` wraps only the `mount` entry point. It records
the kernel boot ID before the native mount, clears a pending native boot
counter for a second mount in the **same** boot, and preserves the counter
when an earlier boot did not complete. Once `sys.boot_completed=1`, a
manual mount cannot leave a counter that disables the next boot.
`metamount.sh`, the Magisk fallback and the existing `bin/zm` front
wrapper call it. On boot completion, both markers are cleared. A deliberate
reinstallation clears a stale recovery lockout and the disable marker while
retaining the activity log.

The original native 100-second boot watchdog and Zygote monitor can still
disable the module after a real or perceived boot failure. Without logs from
the affected phone, the precise trigger cannot be proven. This ZIP has
passed archive integrity and simulated shell guard cases; it has not been
installed or boot-tested on the phone. Check `/data/adb/zeromount/activity.log`
and `/data/adb/modules/meta-zeromount/disable` if it disables again.

The 35204 kernel CI is a separate build. Install only after reviewing its
successful artifact and using a matching BakaSU manager.
