# ZeroMount r3.3 — BakaSU 35215 compatibility

Target:
- BakaSU 35215
- commit `1bfed00f597e65700d70fee0feb1d424fc21a2e5`
- UAPI5
- Samsung SM-S928B / S928BXXU6ZZI4 / EUX
- SUSFS v2.3.0 `24743360ea08d98f6ad72b856851abed8de5854f`

Preserved from the supplied r3.3 package:
- Guard6.13 native core
- BRENE 68/69 integration
- UIDGate2
- BootGuard2 bounded retry
- Droidspaces VFS bridge
- OPEN_REDIRECT persistence
- writer adapters
- SUSFS rules editor
- boot-values owner normalization

The native Guard6.13 ELF core is intentionally unchanged.
BakaSU 35215 retains the `BAKASU=true` module-script marker and UAPI5 used by the successful 35212 baseline.
The companion 35215 kernel CI result was not yet known when this ZIP was produced.
