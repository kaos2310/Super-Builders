#!/system/bin/sh
# KSU/APatch metamodule mount hook (post-fs-data phase).
# Runs the full mount pipeline BEFORE notify-module-mounted so all
# overlays/bind mounts are established before Zygote starts.
MODDIR="${0%/*}"
LOG="zeromount"

# Single-instance lock -- KSU metamodule mode can double-fire.
# noclobber makes the redirect use O_CREAT|O_EXCL, which is atomic.
LOCKFILE="/dev/zeromount_metamount_lock"
( set -o noclobber; > "$LOCKFILE" ) 2>/dev/null || { ksud kernel notify-module-mounted 2>/dev/null; exit 0; }

echo "$LOG: metamount.sh entered (post-fs-data)" > /dev/kmsg 2>/dev/null

. "$MODDIR/common.sh"

# Synchronize the native BRENE stage with both user-controlled master switches.
"$MODDIR/bin/zm-susfs-owner" prepare || { echo "ZeroMount SuSFS profile validation failed" >&2; exit 1; }

mkdir -p /data/adb/zeromount/flags

# Reconcile external SUSFS module config changes made outside zeromount
EXTERNAL=$(cat /data/adb/zeromount/flags/external_susfs 2>/dev/null || echo none)
if [ "$EXTERNAL" != "none" ] && [ -n "$ABI" ] && [ -x "$BIN" ]; then
    "$BIN" bridge reconcile "$EXTERNAL" 2>/dev/null
fi

if [ -n "$ABI" ] && [ -x "$BIN" ]; then
    echo "$LOG: starting mount pipeline (pre-zygote)" > /dev/kmsg 2>/dev/null
    timeout 60 "$MODDIR/bin/zm-bootguard" mount
    RET=$?
    if [ "$RET" -eq 124 ]; then
        echo "$LOG: mount pipeline hung after 60s, forced termination" > /dev/kmsg 2>/dev/null
    fi
    echo "$LOG: mount pipeline exited (rc=$RET)" > /dev/kmsg 2>/dev/null


# Guard6.13: explicit user rules; empty by default, acknowledged rules deduplicated per boot.
if ! "$MODDIR/bin/zm-susfs-owner" run susfs guard-rules "$BIN" susfs-rules apply > /data/adb/zeromount/.susfs-rules-post-mount.log 2>&1; then
    echo "zeromount: SUSFS user rules pending/failed; inspect SUSFS Rules" > /dev/kmsg 2>/dev/null
fi

    # Guard6.6: Droidspaces v6.5.5 no longer ships system/bin/droidspaces in its module tree.
    # Recreate the compatibility path from a ZeroMount-owned staged copy after the normal
    # pipeline has finished, so CLEAR_ALL during the pipeline cannot wipe this managed rule.
    if [ -x "$MODDIR/bin/zm-droidspaces-vfs" ]; then
        "$MODDIR/bin/zm-droidspaces-vfs" apply early > /data/adb/zeromount/.droidspaces-vfs-early.log 2>&1 || \
            echo "zeromount: early Droidspaces VFS bridge pending/failed; see .droidspaces-vfs-early.log" > /dev/kmsg 2>/dev/null
    fi

else
    echo "$LOG: binary not found (ABI=$ABI), skipping pipeline" > /dev/kmsg 2>/dev/null
fi

echo "$LOG: calling notify-module-mounted" > /dev/kmsg 2>/dev/null
ksud kernel notify-module-mounted 2>/dev/null
exit 0
