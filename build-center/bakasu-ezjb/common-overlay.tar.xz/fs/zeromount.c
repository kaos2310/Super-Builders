#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/fs.h>
#include <linux/dcache.h>
#include <linux/path.h>
#include <linux/namei.h>
#include <linux/sched.h>
#include <linux/slab.h>
#include <linux/string.h>
#include <linux/uaccess.h>
#include <linux/dirent.h>
#include <linux/miscdevice.h>
#include <linux/cred.h>
#include <linux/vmalloc.h>
#include <linux/mm.h>
#include <linux/zeromount.h>
#include <linux/kobject.h>
#include <linux/sysfs.h>
#include <linux/statfs.h>
#include <linux/file.h>
#include <linux/fs_struct.h>
#ifdef CONFIG_KSU_SUSFS
#include <linux/susfs.h>
#endif
#include <linux/reboot.h>
#include <linux/bitmap.h>

int zeromount_debug_level = 0;

DEFINE_HASHTABLE(zeromount_rules_ht, ZEROMOUNT_HASH_BITS);
DEFINE_HASHTABLE(zeromount_dirs_ht, ZEROMOUNT_HASH_BITS);
DEFINE_HASHTABLE(zeromount_uid_ht, ZEROMOUNT_HASH_BITS);
DEFINE_HASHTABLE(zeromount_ino_ht, ZEROMOUNT_HASH_BITS);
LIST_HEAD(zeromount_rules_list);
DEFINE_SPINLOCK(zeromount_lock);

atomic_t zeromount_enabled = ATOMIC_INIT(0);
static atomic_t zeromount_dirs_count = ATOMIC_INIT(0);
static atomic_t zeromount_rule_count = ATOMIC_INIT(0);
static DECLARE_BITMAP(zm_bloom, ZM_BLOOM_BITS);
#define ZEROMOUNT_DISABLED() (atomic_read(&zeromount_enabled) == 0)

static inline void zm_bloom_add(u32 hash)
{
	set_bit(hash & ZM_BLOOM_MASK, zm_bloom);
	set_bit((hash >> 10) & ZM_BLOOM_MASK, zm_bloom);
	set_bit((hash >> 20) & ZM_BLOOM_MASK, zm_bloom);
}

static inline bool zm_bloom_test(u32 hash)
{
	return test_bit(hash & ZM_BLOOM_MASK, zm_bloom) &&
	       test_bit((hash >> 10) & ZM_BLOOM_MASK, zm_bloom) &&
	       test_bit((hash >> 20) & ZM_BLOOM_MASK, zm_bloom);
}

static void zm_bloom_rebuild(void)
{
	struct zeromount_rule *rule;
	int count = 0;

	bitmap_zero(zm_bloom, ZM_BLOOM_BITS);
	list_for_each_entry(rule, &zeromount_rules_list, list) {
		u32 h = full_name_hash(NULL, rule->virtual_path, rule->vp_len);
		zm_bloom_add(h);
		count++;
	}
	ZM_DBG("bloom: rebuilt (%d rules)\n", count);
}

struct linux_dirent {
	unsigned long	d_ino;
	unsigned long	d_off;
	unsigned short	d_reclen;
	char		d_name[];
};

static unsigned long zm_ino_adb = 0;
static unsigned long zm_ino_modules = 0;

static inline bool zeromount_is_critical_process(void)
{
	const char *comm = current->comm;

	switch (comm[0]) {
	case 'i': if (comm[1] == 'n' && comm[2] == 'i') return true; break;
	case 'u': if (comm[1] == 'e' && comm[2] == 'v') return true; break;
	case 'v': if (comm[1] == 'o' && comm[2] == 'l') return true; break;
	}
	if (current->flags & PF_KTHREAD)
		return true;
	return false;
}

bool zeromount_should_skip(void)
{
	if (ZEROMOUNT_DISABLED())
		return true;
	if (zm_is_recursive())
		return true;
	if (unlikely(in_interrupt() || in_nmi() || oops_in_progress))
		return true;
	if (!current || !current->mm)
		return true;
	if (current->flags & PF_EXITING)
		return true;
	if (zeromount_is_critical_process())
		return true;
#ifdef CONFIG_KSU_SUSFS
	if (susfs_is_current_proc_umounted())
		return true;
#endif
	return false;
}
EXPORT_SYMBOL(zeromount_should_skip);

bool zeromount_is_uid_blocked(uid_t uid)
{
	struct zeromount_uid_node *entry;

	if (ZEROMOUNT_DISABLED())
		return false;
#ifdef CONFIG_KSU_SUSFS
	if (susfs_is_current_proc_umounted()) return true;
#endif

	rcu_read_lock();
	hash_for_each_possible_rcu(zeromount_uid_ht, entry, node, uid) {
		if (entry->uid == uid) {
			rcu_read_unlock();
			return true;
		}
	}
	rcu_read_unlock();
	return false;
}
EXPORT_SYMBOL(zeromount_is_uid_blocked);

bool zeromount_match_path(const char *input_path, const char *rule_path)
{
	if (!input_path || !rule_path)
		return false;
	if (strcmp(input_path, rule_path) == 0)
		return true;
	if (strncmp(input_path, "/system", 7) == 0) {
		if (strcmp(input_path + 7, rule_path) == 0)
			return true;
	}
	return false;
}

/* Zero-alloc normalize: compute adjusted base and length in-place */
static inline void zeromount_normalize_inline(const char *path,
					      const char **out_p,
					      size_t *out_len)
{
	const char *p = path;
	size_t len;

	if (strncmp(path, "/system/", 8) == 0)
		p = path + 7;

	len = strlen(p);
	while (len > 1 && p[len - 1] == '/')
		len--;

	*out_p = p;
	*out_len = len;
}

/* Alloc variant for callers that need a persistent copy */
static char *zeromount_normalize_path(const char *path)
{
	const char *p;
	size_t len;
	char *normalized;

	if (!path)
		return NULL;

	zeromount_normalize_inline(path, &p, &len);

	normalized = kmalloc(len + 1, GFP_KERNEL);
	if (!normalized)
		return NULL;

	memcpy(normalized, p, len);
	normalized[len] = '\0';
	return normalized;
}

static void zeromount_free_rule_rcu(struct rcu_head *head)
{
	struct zeromount_rule *rule = container_of(head, struct zeromount_rule, rcu);

	kfree(rule->virtual_path);
	kfree(rule->real_path);
	kfree(rule);
}

static void zeromount_free_child_rcu(struct rcu_head *head)
{
	struct zeromount_child_name *child =
		container_of(head, struct zeromount_child_name, rcu);

	kfree(child->name);
	kfree(child);
}

static void zeromount_free_dir_node_rcu(struct rcu_head *head)
{
	struct zeromount_dir_node *node =
		container_of(head, struct zeromount_dir_node, rcu);

	kfree(node->dir_path);
	kfree(node);
}

static void zeromount_flush_parent(const char *full_path)
{
	char *path_copy, *last_slash, *parent_str, *child_name;
	struct path parent;

	path_copy = kstrdup(full_path, GFP_KERNEL);
	if (!path_copy)
		return;

	last_slash = strrchr(path_copy, '/');
	if (!last_slash || last_slash == path_copy) {
		kfree(path_copy);
		return;
	}

	*last_slash = '\0';
	parent_str = path_copy;
	child_name = last_slash + 1;

	if (*child_name == '\0') {
		kfree(path_copy);
		return;
	}

	if (kern_path(parent_str, LOOKUP_FOLLOW, &parent) == 0) {
		struct dentry *child;

		inode_lock(parent.dentry->d_inode);
		child = lookup_one_len(child_name, parent.dentry,
				       strlen(child_name));
		if (!IS_ERR(child)) {
			d_invalidate(child);
			d_drop(child);
			dput(child);
		}
		inode_unlock(parent.dentry->d_inode);
		path_put(&parent);
	}

	kfree(path_copy);
}

static void zeromount_flush_dcache(const char *path_name)
{
	struct path path;
	int err;

	zm_enter();
	err = kern_path(path_name, LOOKUP_FOLLOW, &path);
	if (!err) {
		d_invalidate(path.dentry);
		d_drop(path.dentry);
		path_put(&path);
	} else if (err == -ENOENT) {
		zeromount_flush_parent(path_name);
	}
	zm_exit();
}

static void zeromount_force_refresh_all(void)
{
	struct zeromount_rule *rule;
	char **paths = NULL;
	int count = 0, i = 0;

	spin_lock(&zeromount_lock);
	list_for_each_entry(rule, &zeromount_rules_list, list)
		count++;
	spin_unlock(&zeromount_lock);

	if (count == 0)
		return;

	paths = kvmalloc_array(count, sizeof(char *), GFP_KERNEL);
	if (!paths)
		return;

	spin_lock(&zeromount_lock);
	list_for_each_entry(rule, &zeromount_rules_list, list) {
		if (i >= count)
			break;
		paths[i] = kstrdup(rule->virtual_path, GFP_ATOMIC);
		if (!paths[i])
			break;
		i++;
	}
	spin_unlock(&zeromount_lock);

	for (count = i, i = 0; i < count; i++) {
		zeromount_flush_dcache(paths[i]);
		kfree(paths[i]);
	}
	kvfree(paths);
}

static unsigned long zeromount_generate_ino(const char *dir, const char *name)
{
	u32 h1 = full_name_hash(NULL, dir, strlen(dir));
	u32 h2 = full_name_hash(NULL, name, strlen(name));

	return (unsigned long)(h1 ^ h2);
}

char *zeromount_get_virtual_path_for_inode(struct inode *inode)
{
	struct zeromount_rule *rule;
	unsigned long key;
	char *found_path = NULL;

	if (!inode || !inode->i_sb || zeromount_should_skip())
		return NULL;
	if (zeromount_is_uid_blocked(current_uid().val))
		return NULL;
#ifdef CONFIG_KSU_SUSFS
	if (susfs_is_current_proc_umounted())
		return NULL;
#endif

	key = inode->i_ino ^ inode->i_sb->s_dev;

	if (atomic_read(&zeromount_rule_count) == 0)
		return NULL;

	rcu_read_lock();
	hash_for_each_possible_rcu(zeromount_ino_ht, rule, ino_node, key) {
		if (rule->real_ino == inode->i_ino &&
		    rule->real_dev == inode->i_sb->s_dev) {
			if (READ_ONCE(rule->is_new))
				found_path = kstrdup(rule->virtual_path,
						     GFP_ATOMIC);
			break;
		}
	}
	rcu_read_unlock();
	return found_path;
}
EXPORT_SYMBOL(zeromount_get_virtual_path_for_inode);

/* Returns kstrdup'd copy; caller must kfree. GFP_ATOMIC safe from any context. */
char *zeromount_get_static_vpath(struct inode *inode)
{
	struct zeromount_rule *rule;
	unsigned long key;
	char *copy = NULL;

	if (unlikely(!inode || !inode->i_sb))
		return NULL;

	key = inode->i_ino ^ inode->i_sb->s_dev;

	rcu_read_lock();
	hash_for_each_possible_rcu(zeromount_ino_ht, rule, ino_node, key) {
		if (rule->real_ino == inode->i_ino &&
		    rule->real_dev == inode->i_sb->s_dev &&
		    (rule->flags & ZM_FLAG_ACTIVE)) {
			copy = kstrdup(rule->virtual_path, GFP_ATOMIC);
			break;
		}
	}
	rcu_read_unlock();
	return copy;
}
EXPORT_SYMBOL(zeromount_get_static_vpath);

/* Spoof dev/ino in /proc/PID/maps for redirected mmap'd files */
void zeromount_spoof_mmap_metadata(struct inode *inode, dev_t *dev,
				   unsigned long *ino)
{
	struct zeromount_rule *rule;
	unsigned long key;

	if (unlikely(!inode || !dev || !ino))
		return;
	if (zeromount_should_skip())
		return;

	key = inode->i_ino ^ inode->i_sb->s_dev;

	rcu_read_lock();
	hash_for_each_possible_rcu(zeromount_ino_ht, rule, ino_node, key) {
		if (rule->real_ino == inode->i_ino &&
		    rule->real_dev == inode->i_sb->s_dev &&
		    (rule->flags & ZM_FLAG_ACTIVE)) {
			*dev = READ_ONCE(rule->v_dev);
			*ino = READ_ONCE(rule->v_ino);
			break;
		}
	}
	rcu_read_unlock();
}
EXPORT_SYMBOL(zeromount_spoof_mmap_metadata);

static unsigned long zeromount_get_inode_by_path(const char *path_str)
{
	struct path path;
	struct inode *inode;
	unsigned long ino = 0;

	if (kern_path(path_str, LOOKUP_FOLLOW, &path) == 0) {
		inode = d_backing_inode(path.dentry);
		if (inode)
			ino = inode->i_ino;
		path_put(&path);
	}
	return ino;
}

static void zeromount_refresh_critical_inodes(void)
{
	if (READ_ONCE(zm_ino_adb) == 0) {
		unsigned long ino = zeromount_get_inode_by_path("/data/adb");
		if (ino != 0)
			WRITE_ONCE(zm_ino_adb, ino);
	}
	if (READ_ONCE(zm_ino_modules) == 0) {
		unsigned long ino = zeromount_get_inode_by_path("/data/adb/modules");
		if (ino != 0)
			WRITE_ONCE(zm_ino_modules, ino);
	}
}

bool zeromount_is_traversal_allowed(struct inode *inode, int mask)
{
	if (!inode || zeromount_should_skip() ||
	    zeromount_is_uid_blocked(current_uid().val))
		return false;
#ifdef CONFIG_KSU_SUSFS
	if (susfs_is_current_proc_umounted()) return false;
#endif
	if (!(mask & MAY_EXEC))
		return false;

	if ((READ_ONCE(zm_ino_adb) != 0 &&
	     inode->i_ino == READ_ONCE(zm_ino_adb)) ||
	    (READ_ONCE(zm_ino_modules) != 0 &&
	     inode->i_ino == READ_ONCE(zm_ino_modules)))
		return true;

	return false;
}
EXPORT_SYMBOL(zeromount_is_traversal_allowed);

bool zeromount_is_injected_file(struct inode *inode)
{
	struct zeromount_rule *rule;
	unsigned long key;

	if (!inode || !inode->i_sb || zeromount_should_skip())
		return false;
#ifdef CONFIG_KSU_SUSFS
	if (susfs_is_current_proc_umounted())
		return false;
#endif

	key = inode->i_ino ^ inode->i_sb->s_dev;

	if (atomic_read(&zeromount_rule_count) == 0)
		return false;

	rcu_read_lock();
	hash_for_each_possible_rcu(zeromount_ino_ht, rule, ino_node, key) {
		if (rule->real_ino == inode->i_ino &&
		    rule->real_dev == inode->i_sb->s_dev) {
			rcu_read_unlock();
			return true;
		}
	}
	rcu_read_unlock();
	return false;
}
EXPORT_SYMBOL(zeromount_is_injected_file);

char *zeromount_resolve_path(const char *pathname)
{
	struct zeromount_rule *rule;
	char *target = NULL;
	const char *normalized;
	size_t norm_len;
	u32 hash;

	if (zeromount_is_critical_process())
		return NULL;
#ifdef CONFIG_KSU_SUSFS
	if (susfs_is_current_proc_umounted())
		return NULL;
#endif
	if (ZEROMOUNT_DISABLED() ||
	    zeromount_is_uid_blocked(current_uid().val) || !pathname)
		return NULL;

	zeromount_normalize_inline(pathname, &normalized, &norm_len);
	hash = full_name_hash(NULL, normalized, norm_len);

	if (atomic_read(&zeromount_rule_count) == 0)
		return NULL;

	if (!zm_bloom_test(hash)) {
		ZM_TRACE("bloom: reject hash=0x%08x path=%.*s\n", hash, (int)norm_len, normalized);
		return NULL;
	}
	ZM_DBG("bloom: pass hash=0x%08x path=%.*s\n", hash, (int)norm_len, normalized);

	rcu_read_lock();
	hash_for_each_possible_rcu(zeromount_rules_ht, rule, node, hash) {
		if (rule->vp_len == norm_len &&
		    memcmp(normalized, rule->virtual_path, norm_len) == 0) {
			if (rule->flags & ZM_FLAG_ACTIVE) {
				target = kstrdup(rule->real_path, GFP_ATOMIC);
				break;
			}
		}
	}
	rcu_read_unlock();
	return target;
}
EXPORT_SYMBOL(zeromount_resolve_path);

static char *zeromount_resolve_dirfd_path(int dfd, char *buf, int buflen)
{
	struct fd f;
	char *path;

	if (dfd == AT_FDCWD) {
		struct path pwd;

		if (unlikely(!current->fs))
			return ERR_PTR(-ENOENT);
		get_fs_pwd(current->fs, &pwd);
		path = d_path(&pwd, buf, buflen);
		path_put(&pwd);
		return path;
	}

	f = fdget(dfd);
	if (!f.file)
		return ERR_PTR(-EBADF);

	path = d_path(&f.file->f_path, buf, buflen);
	fdput(f);
	return path;
}

char *zeromount_build_absolute_path(int dfd, const char *name)
{
	char *page_buf, *dir_path, *abs_path;
	size_t dir_len, name_len;

	if (!name || name[0] == '/' || *name == '\0')
		return NULL;
	if (zeromount_should_skip() ||
	    zeromount_is_uid_blocked(current_uid().val))
		return NULL;

	page_buf = __getname();
	if (!page_buf)
		return NULL;

	dir_path = zeromount_resolve_dirfd_path(dfd, page_buf, PATH_MAX);
	if (IS_ERR(dir_path)) {
		__putname(page_buf);
		return NULL;
	}

	dir_len = strlen(dir_path);
	name_len = strlen(name);

	if (dir_len > PATH_MAX || name_len > NAME_MAX ||
	    dir_len + name_len + 2 > PATH_MAX) {
		__putname(page_buf);
		return NULL;
	}

	abs_path = kmalloc(dir_len + 1 + name_len + 1, GFP_KERNEL);
	if (abs_path) {
		memcpy(abs_path, dir_path, dir_len);
		abs_path[dir_len] = '/';
		memcpy(abs_path + dir_len + 1, name, name_len + 1);
	}

	__putname(page_buf);
	return abs_path;
}
EXPORT_SYMBOL(zeromount_build_absolute_path);

struct filename *zeromount_getname_hook(struct filename *name)
{
	char *target_path;
	struct filename *new_name;

	if (zeromount_should_skip() ||
	    zeromount_is_uid_blocked(current_uid().val) ||
	    !name || name->name[0] != '/')
		return name;
#ifdef CONFIG_KSU_SUSFS
	if (susfs_is_current_proc_umounted())
		return name;
#endif

	zm_enter();

	target_path = zeromount_resolve_path(name->name);
	if (!target_path) {
		zm_exit();
		return name;
	}

	new_name = getname_kernel(target_path);
	kfree(target_path);

	if (IS_ERR(new_name)) {
		zm_exit();
		return name;
	}

	putname(name);
	zm_exit();
	return new_name;
}

/* Merged readdir injection: compat=0 for dirent64, compat=1 for dirent */
void zeromount_inject_dents_common(struct file *file, void __user **dirent,
				   int *count, loff_t *pos, int compat)
{
	char *page_buf, *dir_path;
	unsigned long v_index;

	if (zeromount_should_skip() ||
	    zeromount_is_uid_blocked(current_uid().val))
		return;
#ifdef CONFIG_KSU_SUSFS
	if (susfs_is_current_proc_umounted()) return;
#endif

	if (atomic_read(&zeromount_dirs_count) == 0 &&
	    *pos < ZEROMOUNT_MAGIC_POS)
		return;

	page_buf = __getname();
	if (!page_buf)
		return;

	dir_path = d_path(&file->f_path, page_buf, PAGE_SIZE);
	if (IS_ERR(dir_path)) {
		__putname(page_buf);
		return;
	}

	/* Skip if this directory is itself redirected */
	{
		const char *norm_p;
		size_t norm_len;
		u32 dir_hash;
		bool is_redirected = false;

		zeromount_normalize_inline(dir_path, &norm_p, &norm_len);
		dir_hash = full_name_hash(NULL, norm_p, norm_len);

		rcu_read_lock();
		{
			struct zeromount_rule *rule;

			hash_for_each_possible_rcu(zeromount_rules_ht, rule,
						   node, dir_hash) {
				if (rule->vp_len == norm_len &&
				    memcmp(norm_p, rule->virtual_path,
					   norm_len) == 0 &&
				    (rule->flags & ZM_FLAG_ACTIVE)) {
					is_redirected = true;
					break;
				}
			}
		}
		rcu_read_unlock();

		if (is_redirected) {
			__putname(page_buf);
			return;
		}
	}

	if (*pos >= ZEROMOUNT_MAGIC_POS) {
		v_index = *pos - ZEROMOUNT_MAGIC_POS;
	} else {
		v_index = 0;
	}

	{
		struct zeromount_dir_node *zm_dir;
		struct zeromount_child_name *zm_child;
		const char *normalized;
		size_t normalized_len;
		u32 zm_hash;
		unsigned long cur_idx = 0;

		zeromount_normalize_inline(dir_path, &normalized,
					  &normalized_len);
		zm_hash = full_name_hash(NULL, normalized, normalized_len);

		rcu_read_lock();
		hash_for_each_possible_rcu(zeromount_dirs_ht, zm_dir,
					   node, zm_hash) {
			if (strlen(zm_dir->dir_path) != normalized_len ||
			    memcmp(normalized, zm_dir->dir_path,
				   normalized_len) != 0)
				continue;

			if (*pos < ZEROMOUNT_MAGIC_POS)
				*pos = ZEROMOUNT_MAGIC_POS;

			list_for_each_entry_rcu(zm_child,
						&zm_dir->children_names,
						list) {
				char name_local[256];
				unsigned char type_local;
				int name_len, reclen;
				unsigned long fake_ino;

				if (cur_idx++ < v_index)
					continue;

				strscpy(name_local, zm_child->name,
					sizeof(name_local));
				type_local = zm_child->d_type;
				name_len = strlen(name_local);

				if (compat) {
					struct linux_dirent __user *de;

					reclen = ALIGN(offsetof(struct linux_dirent, d_name) + name_len + 2, 4);
					if (*count < reclen)
						break;
					de = (struct linux_dirent __user *)*dirent;
					fake_ino = zeromount_generate_ino(dir_path, name_local);
					if (put_user(fake_ino, &de->d_ino) ||
					    put_user(ZEROMOUNT_MAGIC_POS + v_index + 1, &de->d_off) ||
					    put_user(reclen, &de->d_reclen) ||
					    copy_to_user(de->d_name, name_local, name_len) ||
					    put_user(0, de->d_name + name_len) ||
					    put_user(type_local, ((char __user *)de) + reclen - 1))
						break;
				} else {
					struct linux_dirent64 __user *de64;

					reclen = ALIGN(offsetof(struct linux_dirent64, d_name) + name_len + 1, sizeof(u64));
					if (*count < reclen)
						break;
					de64 = (struct linux_dirent64 __user *)*dirent;
					fake_ino = zeromount_generate_ino(dir_path, name_local);
					if (put_user(fake_ino, &de64->d_ino) ||
					    put_user(ZEROMOUNT_MAGIC_POS + v_index + 1, &de64->d_off) ||
					    put_user(reclen, &de64->d_reclen) ||
					    put_user(type_local, &de64->d_type) ||
					    copy_to_user(de64->d_name, name_local, name_len) ||
					    put_user(0, de64->d_name + name_len))
						break;
				}

				*dirent = (void __user *)((char __user *)*dirent + reclen);
				*count -= reclen;
				v_index++;
				*pos = ZEROMOUNT_MAGIC_POS + v_index;
			}
			break;
		}
		rcu_read_unlock();
	}

	__putname(page_buf);
}

void zeromount_inject_dents64(struct file *file, void __user **dirent,
			      int *count, loff_t *pos)
{
	zeromount_inject_dents_common(file, dirent, count, pos, 0);
}

void zeromount_inject_dents(struct file *file, void __user **dirent,
			    int *count, loff_t *pos)
{
	zeromount_inject_dents_common(file, dirent, count, pos, 1);
}

#define EROFS_SUPER_MAGIC 0xE0F5E1E2
#define EXT4_SUPER_MAGIC  0xEF53
#define F2FS_SUPER_MAGIC  0xF2F52010

int zeromount_spoof_statfs(const char __user *pathname, struct kstatfs *buf)
{
	char *kpath;
	char *resolved;
	const char *statfs_root = NULL;
	struct path root_path;
	struct kstatfs root_stats;
	int ret = 0;

	if (zeromount_should_skip() ||
	    zeromount_is_uid_blocked(current_uid().val))
		return 0;
#ifdef CONFIG_KSU_SUSFS
	if (susfs_is_current_proc_umounted())
		return 0;
#endif

	kpath = strndup_user(pathname, PATH_MAX);
	if (IS_ERR(kpath))
		return 0;

	resolved = zeromount_resolve_path(kpath);
	if (!resolved) {
		kfree(kpath);
		return 0;
	}

	if (strncmp(kpath, "/system", 7) == 0 &&
	    (kpath[7] == '\0' || kpath[7] == '/'))
		statfs_root = "/system";
	else if (strncmp(kpath, "/vendor", 7) == 0 &&
		 (kpath[7] == '\0' || kpath[7] == '/'))
		statfs_root = "/vendor";
	else if (strncmp(kpath, "/product", 8) == 0 &&
		 (kpath[8] == '\0' || kpath[8] == '/'))
		statfs_root = "/product";
	else if (strncmp(kpath, "/odm", 4) == 0 &&
		 (kpath[4] == '\0' || kpath[4] == '/'))
		statfs_root = "/odm";

	/*
	 * A redirected path is backed by /data, so changing only f_type still
	 * leaks the backing filesystem through f_fsid, block counts and free
	 * space.  Return the complete statfs record of the virtual partition.
	 */
	if (statfs_root && !kern_path(statfs_root, LOOKUP_FOLLOW, &root_path)) {
		if (!vfs_statfs(&root_path, &root_stats)) {
			*buf = root_stats;
			ret = 1;
		}
		path_put(&root_path);
	}

	kfree(kpath);
	kfree(resolved);
	return ret;
}
EXPORT_SYMBOL(zeromount_spoof_statfs);

static const char *zeromount_get_selinux_context(const char *vpath)
{
	if (!vpath)
		return NULL;

	if (strncmp(vpath, "/lib64", 6) == 0 ||
	    strncmp(vpath, "/lib", 4) == 0)
		return "u:object_r:system_lib_file:s0";

	if (strncmp(vpath, "/bin", 4) == 0)
		return "u:object_r:system_file:s0";

	if (strncmp(vpath, "/fonts", 6) == 0)
		return "u:object_r:system_file:s0";

	if (strncmp(vpath, "/framework", 10) == 0)
		return "u:object_r:system_file:s0";

	if (strncmp(vpath, "/etc", 4) == 0)
		return "u:object_r:system_file:s0";

	if (strncmp(vpath, "/vendor", 7) == 0)
		return "u:object_r:vendor_file:s0";

	if (strncmp(vpath, "/product", 8) == 0)
		return "u:object_r:system_file:s0";

	if (vpath[0] == '/')
		return "u:object_r:system_file:s0";

	return NULL;
}

ssize_t zeromount_spoof_xattr(struct dentry *dentry, const char *name,
			      void *value, size_t size)
{
	struct inode *inode;
	char *vpath;
	const char *context;
	size_t ctx_len;

	if (zeromount_should_skip() ||
	    zeromount_is_uid_blocked(current_uid().val))
		return -EOPNOTSUPP;
#ifdef CONFIG_KSU_SUSFS
	if (susfs_is_current_proc_umounted())
		return -EOPNOTSUPP;
#endif

	if (!dentry || !name)
		return -EOPNOTSUPP;

	if (strcmp(name, "security.selinux") != 0)
		return -EOPNOTSUPP;

	inode = d_backing_inode(dentry);
	if (!inode)
		return -EOPNOTSUPP;

	vpath = zeromount_get_virtual_path_for_inode(inode);
	if (!vpath)
		return -EOPNOTSUPP;

	context = zeromount_get_selinux_context(vpath);
	kfree(vpath);

	if (!context)
		return -EOPNOTSUPP;

	ctx_len = strlen(context) + 1;

	if (size == 0)
		return ctx_len;
	if (size < ctx_len)
		return -ERANGE;

	memcpy(value, context, ctx_len);
	return ctx_len;
}
EXPORT_SYMBOL(zeromount_spoof_xattr);

static void zeromount_auto_inject_parent(const char *v_path,
					 unsigned char type, int depth)
{
	char *parent_path, *name, *path_copy, *last_slash;
	struct zeromount_dir_node *dir_node = NULL, *curr;
	struct zeromount_child_name *child;
	u32 hash;
	bool child_exists = false;

	if (depth > 20)
		return;

	/* Existing path on real fs means all ancestors exist too */
	{
		struct path check;
		if (kern_path(v_path, LOOKUP_FOLLOW, &check) == 0) {
			path_put(&check);
			return;
		}
	}

	path_copy = kstrdup(v_path, GFP_KERNEL);
	if (!path_copy)
		return;

	last_slash = strrchr(path_copy, '/');
	if (!last_slash || last_slash == path_copy) {
		kfree(path_copy);
		return;
	}

	*last_slash = '\0';
	parent_path = path_copy;
	name = last_slash + 1;

	/* Skip if parent dir is VFS-redirected */
	{
		u32 parent_hash = full_name_hash(NULL, parent_path,
						 strlen(parent_path));
		struct zeromount_rule *parent_rule;
		bool parent_redirected = false;

		rcu_read_lock();
		hash_for_each_possible_rcu(zeromount_rules_ht, parent_rule,
					   node, parent_hash) {
			if (strcmp(parent_rule->virtual_path, parent_path) == 0 &&
			    READ_ONCE(parent_rule->is_new)) {
				parent_redirected = true;
				break;
			}
		}
		rcu_read_unlock();

		if (parent_redirected) {
			kfree(path_copy);
			return;
		}
	}

	zeromount_auto_inject_parent(parent_path, DT_DIR, depth + 1);

	hash = full_name_hash(NULL, parent_path, strlen(parent_path));

	spin_lock(&zeromount_lock);

	hash_for_each_possible(zeromount_dirs_ht, curr, node, hash) {
		if (strcmp(curr->dir_path, parent_path) == 0) {
			dir_node = curr;
			break;
		}
	}

	if (!dir_node) {
		dir_node = kzalloc(sizeof(*dir_node), GFP_ATOMIC);
		if (!dir_node)
			goto unlock_out;

		dir_node->dir_path = kstrdup(parent_path, GFP_ATOMIC);
		INIT_LIST_HEAD(&dir_node->children_names);
		hash_add_rcu(zeromount_dirs_ht, &dir_node->node, hash);
		atomic_inc(&zeromount_dirs_count);
	}

	list_for_each_entry(child, &dir_node->children_names, list) {
		if (strcmp(child->name, name) == 0) {
			child_exists = true;
			break;
		}
	}

	if (!child_exists) {
		child = kzalloc(sizeof(*child), GFP_ATOMIC);
		if (child) {
			child->name = kstrdup(name, GFP_ATOMIC);
			child->d_type = (type == DT_DIR) ? 4 : 8;
			list_add_tail_rcu(&child->list,
					  &dir_node->children_names);
		}
	}

unlock_out:
	spin_unlock(&zeromount_lock);
	kfree(path_copy);
}

static int zeromount_ioctl_add_rule(unsigned long arg)
{
	struct zeromount_ioctl_data data;
	struct zeromount_rule *rule;
	char *v_path_raw, *v_path, *r_path;
	struct path path;
	unsigned char type;
	u32 hash;

	if (copy_from_user(&data, (void __user *)arg, sizeof(data)))
		return -EFAULT;

	v_path_raw = strndup_user(data.virtual_path, PATH_MAX);
	if (IS_ERR(v_path_raw))
		return PTR_ERR(v_path_raw);

	v_path = zeromount_normalize_path(v_path_raw);
	kfree(v_path_raw);
	if (!v_path)
		return -ENOMEM;

	r_path = strndup_user(data.real_path, PATH_MAX);
	if (IS_ERR(r_path)) {
		kfree(v_path);
		return PTR_ERR(r_path);
	}

	hash = full_name_hash(NULL, v_path, strlen(v_path));
	rule = kzalloc(sizeof(*rule), GFP_KERNEL);
	if (!rule) {
		kfree(v_path);
		kfree(r_path);
		return -ENOMEM;
	}

	rule->virtual_path = v_path;
	rule->vp_len = strlen(v_path);
	rule->real_path = r_path;
	rule->flags = data.flags | ZM_FLAG_ACTIVE;
	rule->is_new = false;

	if (zm_ino_adb == 0)
		zeromount_refresh_critical_inodes();

	if (kern_path(r_path, LOOKUP_FOLLOW, &path) == 0) {
		struct inode *inode = d_backing_inode(path.dentry);

		if (inode) {
			rule->real_ino = inode->i_ino;
			rule->real_dev = inode->i_sb->s_dev;
		}
		path_put(&path);
	} else {
		rule->real_ino = 0;
		rule->real_dev = 0;
	}

	/* Capture virtual path's dev/ino for maps spoofing.
	 * Replacement rules use real inode; injected files use
	 * parent device + generated ino. */
	zm_enter();
	if (kern_path(v_path, LOOKUP_FOLLOW, &path) == 0) {
		struct inode *vinode = d_backing_inode(path.dentry);

		if (vinode) {
			rule->v_ino = vinode->i_ino;
			rule->v_dev = vinode->i_sb->s_dev;
		}
		path_put(&path);
	}
	zm_exit();

	if (rule->v_ino == 0) {
		rule->v_ino = zeromount_generate_ino(v_path, r_path);
		{
			char *parent_copy = kstrdup(v_path, GFP_KERNEL);

			if (parent_copy) {
				char *slash = strrchr(parent_copy, '/');

				if (slash && slash != parent_copy) {
					*slash = '\0';
					zm_enter();
					if (kern_path(parent_copy, LOOKUP_FOLLOW,
						      &path) == 0) {
						struct inode *pinode =
							d_backing_inode(path.dentry);
						if (pinode)
							rule->v_dev = pinode->i_sb->s_dev;
						path_put(&path);
					}
					zm_exit();
				}
				kfree(parent_copy);
			}
		}
	}

	spin_lock(&zeromount_lock);
	hash_add_rcu(zeromount_rules_ht, &rule->node, hash);
	zm_bloom_add(hash);
	ZM_DBG("bloom: add hash=0x%08x path=%s\n", hash, rule->virtual_path);
	if (rule->real_ino != 0) {
		unsigned long ino_key = rule->real_ino ^ rule->real_dev;

		hash_add_rcu(zeromount_ino_ht, &rule->ino_node, ino_key);
	}
	list_add_tail(&rule->list, &zeromount_rules_list);
	atomic_inc(&zeromount_rule_count);
	spin_unlock(&zeromount_lock);

	type = DT_REG;
	if (data.flags & ZM_FLAG_IS_DIR)
		type = DT_DIR;

	if (kern_path(rule->virtual_path, LOOKUP_FOLLOW, &path) == 0) {
		path_put(&path);
	} else {
		zeromount_auto_inject_parent(rule->virtual_path, type, 0);
		WRITE_ONCE(rule->is_new, true);
	}
	zeromount_flush_dcache(rule->virtual_path);
	return 0;
}

static void zeromount_cleanup_parent_dir(char *v_path)
{
	char *end = v_path + strlen(v_path);
	char *last_slash, *p;
	struct zeromount_dir_node *dir_node;
	struct zeromount_child_name *child, *tmp_child;
	u32 hash;
	bool pruned;

	do {
		pruned = false;
		last_slash = strrchr(v_path, '/');
		if (!last_slash || last_slash == v_path)
			break;

		*last_slash = '\0';
		hash = full_name_hash(NULL, v_path, strlen(v_path));

		hash_for_each_possible(zeromount_dirs_ht, dir_node,
				       node, hash) {
			if (strcmp(dir_node->dir_path, v_path) != 0)
				continue;

			list_for_each_entry_safe(child, tmp_child,
						 &dir_node->children_names,
						 list) {
				if (strcmp(child->name, last_slash + 1) == 0) {
					list_del_rcu(&child->list);
					call_rcu(&child->rcu,
						 zeromount_free_child_rcu);
					break;
				}
			}

			if (list_empty(&dir_node->children_names)) {
				hash_del_rcu(&dir_node->node);
				atomic_dec(&zeromount_dirs_count);
				call_rcu(&dir_node->rcu,
					 zeromount_free_dir_node_rcu);
				pruned = true;
			}
			break;
		}
	} while (pruned);

	for (p = v_path; p < end; p++)
		if (*p == '\0')
			*p = '/';
}

static int zeromount_ioctl_del_rule(unsigned long arg)
{
	struct zeromount_ioctl_data data;
	struct zeromount_rule *rule = NULL;
	struct hlist_node *tmp;
	char *v_path_raw, *v_path;
	int bkt;
	bool found = false;

	if (copy_from_user(&data, (void __user *)arg, sizeof(data)))
		return -EFAULT;

	v_path_raw = strndup_user(data.virtual_path, PATH_MAX);
	if (IS_ERR(v_path_raw))
		return PTR_ERR(v_path_raw);

	v_path = zeromount_normalize_path(v_path_raw);
	kfree(v_path_raw);
	if (!v_path)
		return -ENOMEM;

	spin_lock(&zeromount_lock);
	hash_for_each_safe(zeromount_rules_ht, bkt, tmp, rule, node) {
		if (strcmp(rule->virtual_path, v_path) == 0) {
			hash_del_rcu(&rule->node);
			if (rule->real_ino != 0)
				hash_del_rcu(&rule->ino_node);
			list_del(&rule->list);
			found = true;
			break;
		}
	}
	if (found)
		zeromount_cleanup_parent_dir(v_path);
	if (found)
		atomic_dec(&zeromount_rule_count);
	zm_bloom_rebuild();
	spin_unlock(&zeromount_lock);

	if (found && rule)
		call_rcu(&rule->rcu, zeromount_free_rule_rcu);

	kfree(v_path);
	return found ? 0 : -ENOENT;
}

static int zeromount_ioctl_clear_rules(void)
{
	struct zeromount_rule *rule;
	struct zeromount_uid_node *uid_node;
	struct hlist_node *tmp;
	int bkt;

	spin_lock(&zeromount_lock);

	hash_for_each_safe(zeromount_rules_ht, bkt, tmp, rule, node) {
		hash_del_rcu(&rule->node);
		if (rule->real_ino != 0)
			hash_del_rcu(&rule->ino_node);
		list_del(&rule->list);
		call_rcu(&rule->rcu, zeromount_free_rule_rcu);
	}

	hash_for_each_safe(zeromount_uid_ht, bkt, tmp, uid_node, node) {
		hash_del_rcu(&uid_node->node);
		kfree_rcu(uid_node, rcu);
	}

	{
		struct zeromount_dir_node *dir_node;
		struct zeromount_child_name *child, *tmp_child;
		int bkt2;
		struct hlist_node *tmp2;

		hash_for_each_safe(zeromount_dirs_ht, bkt2, tmp2,
				   dir_node, node) {
			hash_del_rcu(&dir_node->node);
			atomic_dec(&zeromount_dirs_count);
			list_for_each_entry_safe(child, tmp_child,
						 &dir_node->children_names,
						 list) {
				list_del_rcu(&child->list);
				call_rcu(&child->rcu,
					 zeromount_free_child_rcu);
			}
			call_rcu(&dir_node->rcu,
				 zeromount_free_dir_node_rcu);
		}
	}

	atomic_set(&zeromount_rule_count, 0);
	bitmap_zero(zm_bloom, ZM_BLOOM_BITS);
	spin_unlock(&zeromount_lock);
	return 0;
}

static int zeromount_ioctl_list_rules(unsigned long arg)
{
	struct zeromount_rule *rule;
	char *kbuf;
	int ret = 0;
	size_t len = 0;
	size_t remaining;
	char __user *ubuf = (char __user *)arg;

	kbuf = vmalloc(MAX_LIST_BUFFER_SIZE);
	if (!kbuf)
		return -ENOMEM;

	memset(kbuf, 0, MAX_LIST_BUFFER_SIZE);
	spin_lock(&zeromount_lock);

	list_for_each_entry(rule, &zeromount_rules_list, list) {
		remaining = MAX_LIST_BUFFER_SIZE - len;
		if (remaining <= 1) {
			ret = -ENOBUFS;
			break;
		}
		len += scnprintf(kbuf + len, remaining, "%s->%s\n",
				 rule->real_path, rule->virtual_path);
	}

	spin_unlock(&zeromount_lock);

	if (ret == -ENOBUFS) {
		vfree(kbuf);
		return ret;
	}

	if (copy_to_user(ubuf, kbuf, len))
		ret = -EFAULT;
	else
		ret = len;

	vfree(kbuf);
	return ret;
}

static int zeromount_ioctl_add_uid(unsigned long arg)
{
	unsigned int uid;
	struct zeromount_uid_node *entry;

	if (copy_from_user(&uid, (void __user *)arg, sizeof(uid)))
		return -EFAULT;
	if (zeromount_is_uid_blocked(uid))
		return -EEXIST;

	entry = kzalloc(sizeof(*entry), GFP_KERNEL);
	if (!entry)
		return -ENOMEM;

	entry->uid = uid;

	spin_lock(&zeromount_lock);
	hash_add_rcu(zeromount_uid_ht, &entry->node, uid);
	spin_unlock(&zeromount_lock);

	return 0;
}

static int zeromount_ioctl_del_uid(unsigned long arg)
{
	unsigned int uid;
	struct zeromount_uid_node *entry;
	struct hlist_node *tmp;
	int bkt;
	bool found = false;

	if (copy_from_user(&uid, (void __user *)arg, sizeof(uid)))
		return -EFAULT;

	spin_lock(&zeromount_lock);
	hash_for_each_safe(zeromount_uid_ht, bkt, tmp, entry, node) {
		if (entry->uid == uid) {
			hash_del_rcu(&entry->node);
			found = true;
			break;
		}
	}
	spin_unlock(&zeromount_lock);

	if (found && entry)
		kfree_rcu(entry, rcu);

	return found ? 0 : -ENOENT;
}

static int zeromount_ioctl_enable(void)
{
	atomic_set(&zeromount_enabled, 1);
	return 0;
}

static int zeromount_ioctl_disable(void)
{
	atomic_set(&zeromount_enabled, 0);
	return 0;
}

static long zeromount_ioctl(struct file *filp, unsigned int cmd,
			    unsigned long arg)
{
	if (_IOC_TYPE(cmd) != ZEROMOUNT_MAGIC_CODE)
		return -ENOTTY;

	if (cmd != ZEROMOUNT_IOC_GET_VERSION) {
		if (!capable(CAP_SYS_ADMIN))
			return -EPERM;
	}

	switch (cmd) {
	case ZEROMOUNT_IOC_GET_VERSION:	return ZEROMOUNT_VERSION;
	case ZEROMOUNT_IOC_ADD_RULE:	return zeromount_ioctl_add_rule(arg);
	case ZEROMOUNT_IOC_DEL_RULE:	return zeromount_ioctl_del_rule(arg);
	case ZEROMOUNT_IOC_CLEAR_ALL:	return zeromount_ioctl_clear_rules();
	case ZEROMOUNT_IOC_ADD_UID:	return zeromount_ioctl_add_uid(arg);
	case ZEROMOUNT_IOC_DEL_UID:	return zeromount_ioctl_del_uid(arg);
	case ZEROMOUNT_IOC_GET_LIST:	return zeromount_ioctl_list_rules(arg);
	case ZEROMOUNT_IOC_ENABLE:	return zeromount_ioctl_enable();
	case ZEROMOUNT_IOC_DISABLE:	return zeromount_ioctl_disable();
	case ZEROMOUNT_IOC_REFRESH:
		zeromount_force_refresh_all();
		return 0;
	case ZEROMOUNT_IOC_GET_STATUS:	return atomic_read(&zeromount_enabled);
	default:			return -EINVAL;
	}
}

static struct kobject *zeromount_kobj;

static ssize_t debug_show(struct kobject *kobj, struct kobj_attribute *attr,
			  char *buf)
{
	return sprintf(buf, "%d\n", zeromount_debug_level);
}

static ssize_t debug_store(struct kobject *kobj, struct kobj_attribute *attr,
			   const char *buf, size_t count)
{
	int val;

	if (kstrtoint(buf, 10, &val) < 0)
		return -EINVAL;
	if (val < 0 || val > 2)
		return -EINVAL;
	zeromount_debug_level = val;
	return count;
}

static struct kobj_attribute debug_attr =
	__ATTR(debug, 0600, debug_show, debug_store);

static struct attribute *zeromount_attrs[] = {
	&debug_attr.attr,
	NULL,
};

static struct attribute_group zeromount_attr_group = {
	.attrs = zeromount_attrs,
};

static int zeromount_dev_open(struct inode *inode, struct file *file)
{
	if (!uid_eq(current_euid(), GLOBAL_ROOT_UID))
		return -EPERM;
	return 0;
}

static const struct file_operations zeromount_fops = {
	.owner		= THIS_MODULE,
	.open		= zeromount_dev_open,
	.unlocked_ioctl	= zeromount_ioctl,
#ifdef CONFIG_COMPAT
	.compat_ioctl	= zeromount_ioctl,
#endif
};

static struct miscdevice zeromount_device = {
	.minor	= MISC_DYNAMIC_MINOR,
	.name	= "zeromount",
	.fops	= &zeromount_fops,
	.mode	= 0600,
};

static int zeromount_reboot_notify(struct notifier_block *nb,
				   unsigned long action, void *data)
{
	atomic_set(&zeromount_enabled, 0);
	synchronize_rcu();
	return NOTIFY_OK;
}

static struct notifier_block zeromount_reboot_nb = {
	.notifier_call = zeromount_reboot_notify,
};

static int __init __used zeromount_init(void)
{
	int ret;

	spin_lock_init(&zeromount_lock);
	register_reboot_notifier(&zeromount_reboot_nb);

	ret = misc_register(&zeromount_device);
	if (ret)
		return ret;

	zeromount_kobj = kobject_create_and_add("zeromount", kernel_kobj);
	if (zeromount_kobj) {
		ret = sysfs_create_group(zeromount_kobj,
					&zeromount_attr_group);
		if (ret)
			pr_warn("ZeroMount: sysfs group creation failed: %d\n",
				ret);
	}

	ZM_INFO("Loaded (debug=%d)\n", zeromount_debug_level);
	return 0;
}
fs_initcall(zeromount_init);

