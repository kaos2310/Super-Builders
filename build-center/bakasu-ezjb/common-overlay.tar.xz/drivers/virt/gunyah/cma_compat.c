// SPDX-License-Identifier: GPL-2.0-only
/*
 * Samsung e3q / Android 14-6.1 Gunyah bounded-extent userspace backing.
 *
 * Preserve the original request-size ABI and 8192 physical-run bound.
 * Prefer large buddy chunks, but permit smaller chunks when the remaining
 * page/extent budget allows them. This avoids rejecting a 128 MiB guest
 * solely because 32 KiB chunks are unavailable. Normal GUP and the
 * reference-safe buddy/contiguous teardown remain unchanged.
 */
#define pr_fmt(fmt) "gh_extent_compat: " fmt

#include <linux/anon_inodes.h>
#include <linux/file.h>
#include <linux/fs.h>
#include <linux/gfp.h>
#include <linux/highmem.h>
#include <linux/kernel.h>
#include <linux/mm.h>
#include <linux/module.h>
#include <linux/numa.h>
#include <linux/sched.h>
#include <linux/sizes.h>
#include <linux/slab.h>
#include <linux/uaccess.h>
#include <linux/vmalloc.h>

#include <uapi/linux/gunyah.h>

/* GH_EXTENT_ADAPTIVE_BACKING_V1: ABI bounds unchanged; order follows extent budget. */
#define GH_EXTENT_ABI_MIN_PAGES 8UL
#define GH_EXTENT_MAX_ORDER 6U
#define GH_EXTENT_LIMIT 8192UL

struct gh_extent_chunk {
	struct page *base;
	unsigned int order;
	bool contig;
};

struct gh_extent_buffer {
	struct page **pages;
	struct gh_extent_chunk *chunks;
	unsigned long nr_pages;
	unsigned long nr_chunks;
	unsigned long chunk_capacity;
	unsigned long buddy_chunks;
	unsigned long contig_chunks;
	u64 size;
};

static void gh_extent_free_one(struct gh_extent_chunk *chunk)
{
	unsigned long nr_pages;
	unsigned long i;

	if (!chunk || !chunk->base)
		return;

	nr_pages = 1UL << chunk->order;
	if (chunk->contig) {
		for (i = 0; i < nr_pages; i++)
			__free_page(nth_page(chunk->base, i));
	} else {
		__free_pages(chunk->base, chunk->order);
	}

	chunk->base = NULL;
}

static void gh_extent_free_chunks(struct gh_extent_buffer *buf)
{
	unsigned long i;

	if (!buf)
		return;

	for (i = 0; i < buf->nr_chunks; i++)
		gh_extent_free_one(&buf->chunks[i]);
	buf->nr_chunks = 0;
}

static void gh_extent_destroy(struct gh_extent_buffer *buf)
{
	if (!buf)
		return;
	gh_extent_free_chunks(buf);
	kvfree(buf->chunks);
	kvfree(buf->pages);
	kfree(buf);
}

/* The caller rejects zero slots before this calculation. */
static unsigned int gh_extent_required_order(unsigned long remaining,
                                             unsigned long slots)
{
	unsigned long pages_per_slot = DIV_ROUND_UP(remaining, slots);
	unsigned int order = 0;

	while ((1UL << order) < pages_per_slot && order < GH_EXTENT_MAX_ORDER)
		order++;
	return order;
}

static struct page *gh_extent_alloc_buddy(unsigned long remaining,
					 unsigned int min_order,
					 unsigned int *order)
{
	const gfp_t gfp = GFP_HIGHUSER_MOVABLE | __GFP_ZERO | __GFP_COMP |
			  __GFP_NOWARN | __GFP_RETRY_MAYFAIL;
	unsigned int try_order = GH_EXTENT_MAX_ORDER;
	struct page *base;

	while ((1UL << try_order) > remaining && try_order > min_order)
		try_order--;

	for (;;) {
		base = alloc_pages(gfp, try_order);
		if (base) {
			*order = try_order;
			return base;
		}
		if (try_order == min_order)
			return NULL;
		try_order--;
	}
}

static struct page *gh_extent_alloc_contig(unsigned long remaining,
					  unsigned int min_order,
					  unsigned int *order)
{
#ifdef CONFIG_CONTIG_ALLOC
	/* alloc_contig_pages() must receive a non-__GFP_COMP mask. */
	const gfp_t gfp = GFP_HIGHUSER_MOVABLE | __GFP_NOWARN |
			  __GFP_RETRY_MAYFAIL;
	unsigned int try_order = GH_EXTENT_MAX_ORDER;
	struct page *base;
	unsigned long i;

	while ((1UL << try_order) > remaining && try_order > min_order)
		try_order--;

	for (;;) {
		base = alloc_contig_pages(1UL << try_order, gfp, NUMA_NO_NODE, NULL);
		if (base) {
			/* alloc_contig_pages() does not promise zero-filled target pages. */
			for (i = 0; i < (1UL << try_order); i++)
				clear_highpage(nth_page(base, i));
			*order = try_order;
			return base;
		}
		if (try_order == min_order)
			return NULL;
		try_order--;
	}
#else
	return NULL;
#endif
}

static int gh_extent_allocate(struct gh_extent_buffer *buf)
{
	unsigned long page_index = 0;
	unsigned long remaining = buf->nr_pages;
	bool logged_contig_fallback = false;

	while (remaining) {
		struct page *base;
		unsigned long chunk_pages;
		unsigned long i;
		unsigned long slots;
		unsigned int min_order, order;
		bool contig = false;

		if (buf->nr_chunks >= buf->chunk_capacity ||
		    buf->nr_chunks >= GH_EXTENT_LIMIT)
			return -E2BIG;
		slots = buf->chunk_capacity - buf->nr_chunks;
		if (DIV_ROUND_UP(remaining, slots) > (1UL << GH_EXTENT_MAX_ORDER))
			return -E2BIG;
		min_order = gh_extent_required_order(remaining, slots);
		if ((1UL << min_order) > remaining)
			return -E2BIG;
		order = min_order;

		base = gh_extent_alloc_buddy(remaining, min_order, &order);
		if (!base) {
			if (!logged_contig_fallback) {
				pr_info("buddy exhausted; enabling alloc_contig_pages fallback remaining_pages=%lu chunks=%lu\n",
					remaining, buf->nr_chunks);
				logged_contig_fallback = true;
			}
			base = gh_extent_alloc_contig(remaining, min_order, &order);
			contig = base != NULL;
		}

		if (!base) {
			pr_err("allocation failed remaining_pages=%lu chunks=%lu buddy=%lu contig=%lu min_order=%u\n",
			       remaining, buf->nr_chunks, buf->buddy_chunks,
			       buf->contig_chunks, min_order);
			return -ENOMEM;
		}

		if (buf->nr_chunks >= buf->chunk_capacity ||
		    buf->nr_chunks >= GH_EXTENT_LIMIT) {
			struct gh_extent_chunk temporary = {
				.base = base,
				.order = order,
				.contig = contig,
			};
			gh_extent_free_one(&temporary);
			pr_err("extent limit exceeded chunks=%lu capacity=%lu limit=%lu\n",
			       buf->nr_chunks, buf->chunk_capacity, GH_EXTENT_LIMIT);
			return -E2BIG;
		}

		chunk_pages = 1UL << order;
		buf->chunks[buf->nr_chunks].base = base;
		buf->chunks[buf->nr_chunks].order = order;
		buf->chunks[buf->nr_chunks].contig = contig;
		buf->nr_chunks++;
		if (contig)
			buf->contig_chunks++;
		else
			buf->buddy_chunks++;

		for (i = 0; i < chunk_pages; i++)
			buf->pages[page_index + i] = nth_page(base, i);

		page_index += chunk_pages;
		remaining -= chunk_pages;
		cond_resched();
	}

	if (page_index != buf->nr_pages)
		return -EFAULT;

	pr_info("allocated adaptive bounded backing pages=%lu chunks=%lu buddy=%lu contig=%lu max_extents=%lu max_order=%u\n",
		buf->nr_pages, buf->nr_chunks, buf->buddy_chunks,
		buf->contig_chunks, GH_EXTENT_LIMIT,
		GH_EXTENT_MAX_ORDER);
	return 0;
}

static int gh_extent_release(struct inode *inode, struct file *file)
{
	struct gh_extent_buffer *buf = file->private_data;

	if (buf)
		pr_info("released bounded backing pages=%lu chunks=%lu buddy=%lu contig=%lu bytes=%llu\n",
			buf->nr_pages, buf->nr_chunks, buf->buddy_chunks,
			buf->contig_chunks, (unsigned long long)buf->size);
	gh_extent_destroy(buf);
	return 0;
}

static int gh_extent_mmap(struct file *file, struct vm_area_struct *vma)
{
	struct gh_extent_buffer *buf = file->private_data;
	unsigned long len = vma->vm_end - vma->vm_start;
	unsigned long nr_pages = PAGE_ALIGN(len) >> PAGE_SHIFT;
	int ret;

	if (!buf || !buf->pages)
		return -EINVAL;
	if (vma->vm_pgoff != 0)
		return -EINVAL;
	if (!len || len > buf->size || nr_pages > buf->nr_pages)
		return -EINVAL;

	file_accessed(file);
	ret = vm_map_pages_zero(vma, buf->pages, nr_pages);
	if (ret)
		pr_err("mmap failed pages=%lu chunks=%lu ret=%d\n",
		       nr_pages, buf->nr_chunks, ret);
	else
		pr_info("mapped bounded backing pages=%lu chunks=%lu buddy=%lu contig=%lu bytes=%lu\n",
			nr_pages, buf->nr_chunks, buf->buddy_chunks,
			buf->contig_chunks, len);
	return ret;
}

static const struct file_operations gh_extent_fops = {
	.owner = THIS_MODULE,
	.llseek = no_llseek,
	.mmap = gh_extent_mmap,
	.release = gh_extent_release,
};

long gh_cma_compat_create_mem_fd(unsigned long arg)
{
	struct gh_extent_buffer *buf;
	struct file *file;
	u64 size;
	unsigned long nr_pages;
	int ret;
	int fd;

	if (copy_from_user(&size, (void __user *)arg, sizeof(size)))
		return -EFAULT;
	if (!size || !PAGE_ALIGNED(size) || size > SZ_512M)
		return -EINVAL;

	nr_pages = (unsigned long)(size >> PAGE_SHIFT);
	if (!nr_pages || (nr_pages % GH_EXTENT_ABI_MIN_PAGES) != 0)
		return -EINVAL;
	if (DIV_ROUND_UP(nr_pages, GH_EXTENT_ABI_MIN_PAGES) > GH_EXTENT_LIMIT)
		return -E2BIG;

	buf = kzalloc(sizeof(*buf), GFP_KERNEL_ACCOUNT);
	if (!buf)
		return -ENOMEM;

	buf->size = size;
	buf->nr_pages = nr_pages;
	buf->chunk_capacity = min(nr_pages, GH_EXTENT_LIMIT);
	buf->pages = kvmalloc_array(nr_pages, sizeof(*buf->pages), GFP_KERNEL_ACCOUNT);
	buf->chunks = kvcalloc(buf->chunk_capacity, sizeof(*buf->chunks),
			       GFP_KERNEL_ACCOUNT);
	if (!buf->pages || !buf->chunks) {
		ret = -ENOMEM;
		goto err_destroy;
	}

	ret = gh_extent_allocate(buf);
	if (ret)
		goto err_destroy;

	fd = get_unused_fd_flags(O_CLOEXEC);
	if (fd < 0) {
		ret = fd;
		goto err_destroy;
	}

	file = anon_inode_getfile("[gunyah-bounded-extents]", &gh_extent_fops,
				  buf, O_RDWR);
	if (IS_ERR(file)) {
		ret = PTR_ERR(file);
		put_unused_fd(fd);
		goto err_destroy;
	}

	fd_install(fd, file);
	pr_info("allocated fd=%d pages=%lu chunks=%lu buddy=%lu contig=%lu bytes=%llu\n",
		fd, nr_pages, buf->nr_chunks, buf->buddy_chunks,
		buf->contig_chunks, (unsigned long long)size);
	return fd;

err_destroy:
	gh_extent_destroy(buf);
	return ret;
}
