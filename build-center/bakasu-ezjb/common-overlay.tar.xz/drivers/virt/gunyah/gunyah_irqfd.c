// SPDX-License-Identifier: GPL-2.0-only
/*
 * Copyright (c) 2022-2023 Qualcomm Innovation Center, Inc. All rights reserved.
 */

#include <linux/eventfd.h>
#include <linux/file.h>
#include <linux/fs.h>
#include <linux/gunyah.h>
#include <linux/gunyah_vm_mgr.h>
#include <linux/module.h>
#include <linux/mutex.h>
#include <linux/poll.h>
#include <linux/printk.h>

#include <uapi/linux/gunyah.h>

struct gh_irqfd_group {
	struct list_head list;
	struct list_head irqfds;
	struct gh_vm *ghvm;
	struct gh_resource *ghrsc;
	struct gh_vm_resource_ticket ticket;
	bool level;
	bool mixed;
};

struct gh_irqfd {
	struct gh_vm_function_instance *f;
	struct gh_irqfd_group *group;
	struct list_head group_list;

	bool level;

	struct eventfd_ctx *ctx;
	wait_queue_entry_t wait;
	poll_table pt;
};

static LIST_HEAD(gh_irqfd_groups);
static DEFINE_MUTEX(gh_irqfd_groups_lock);

static struct gh_irqfd_group *gh_irqfd_find_group(struct gh_vm *ghvm, u32 label)
{
	struct gh_irqfd_group *group;

	list_for_each_entry(group, &gh_irqfd_groups, list) {
		if (group->ghvm == ghvm && group->ticket.label == label)
			return group;
	}

	return NULL;
}

static int irqfd_wakeup(wait_queue_entry_t *wait, unsigned int mode, int sync, void *key)
{
	struct gh_irqfd *irqfd = container_of(wait, struct gh_irqfd, wait);
	struct gh_resource *ghrsc = READ_ONCE(irqfd->group->ghrsc);
	__poll_t flags = key_to_poll(key);
	int ret = 0;

	if (flags & EPOLLIN) {
		if (ghrsc) {
			ret = gh_hypercall_bell_send(ghrsc->capid, 1, NULL);
			if (ret)
				pr_err_ratelimited("Failed to inject interrupt %d: %d\n",
						irqfd->group->ticket.label, ret);
		} else
			pr_err_ratelimited("Premature injection of interrupt\n");
	}

	return 0;
}

static void irqfd_ptable_queue_proc(struct file *file, wait_queue_head_t *wqh, poll_table *pt)
{
	struct gh_irqfd *irq_ctx = container_of(pt, struct gh_irqfd, pt);

	add_wait_queue(wqh, &irq_ctx->wait);
}

static bool gh_irqfd_populate(struct gh_vm_resource_ticket *ticket, struct gh_resource *ghrsc)
{
	struct gh_irqfd_group *group = container_of(ticket, struct gh_irqfd_group, ticket);
	int ret;

	if (READ_ONCE(group->ghrsc)) {
		pr_warn("irqfd%d already got a Gunyah resource. Check if multiple resources with same label were configured.\n",
			group->ticket.label);
		return false;
	}

	WRITE_ONCE(group->ghrsc, ghrsc);
	pr_info("GH_DIAG irqfd populate label=%u capid=%llu level=%u mixed=%u\n",
		group->ticket.label, (unsigned long long)ghrsc->capid,
		(unsigned int)group->level, (unsigned int)group->mixed);
	if (group->level) {
		/* Configure the shared bell as level triggered only when every
		 * source registered for this label uses level semantics.
		 *
		 * A shared edge/level label must retain the default edge-compatible
		 * bell behaviour.  Enabling the automatic acknowledgement mask for
		 * such a mixed label can wedge affected Gunyah implementations while
		 * the VM resources are being populated.
		 */
		ret = gh_hypercall_bell_set_mask(ghrsc->capid, 1, 1);
		if (ret)
			pr_warn("irq %d couldn't be set as level triggered. Might cause IRQ storm if asserted\n",
				group->ticket.label);
	}

	return true;
}

static void gh_irqfd_unpopulate(struct gh_vm_resource_ticket *ticket, struct gh_resource *ghrsc)
{
	struct gh_irqfd_group *group = container_of(ticket, struct gh_irqfd_group, ticket);

	if (WARN_ON(READ_ONCE(group->ghrsc) != ghrsc))
		return;

	WRITE_ONCE(group->ghrsc, NULL);
}

static long gh_irqfd_bind(struct gh_vm_function_instance *f)
{
	struct gh_fn_irqfd_arg *args = f->argp;
	struct gh_irqfd_group *group;
	struct gh_irqfd *irqfd;
	__poll_t events;
	struct fd fd;
	long r;

	if (f->arg_size != sizeof(*args))
		return -EINVAL;

	/* All other flag bits are reserved for future use */
	if (args->flags & ~GH_IRQFD_FLAGS_LEVEL)
		return -EINVAL;

	irqfd = kzalloc(sizeof(*irqfd), GFP_KERNEL);
	if (!irqfd)
		return -ENOMEM;

	irqfd->f = f;
	f->data = irqfd;

	fd = fdget(args->fd);
	if (!fd.file) {
		kfree(irqfd);
		return -EBADF;
	}

	irqfd->ctx = eventfd_ctx_fileget(fd.file);
	if (IS_ERR(irqfd->ctx)) {
		r = PTR_ERR(irqfd->ctx);
		goto err_fdput;
	}

	irqfd->level = args->flags & GH_IRQFD_FLAGS_LEVEL;
	init_waitqueue_func_entry(&irqfd->wait, irqfd_wakeup);
	init_poll_funcptr(&irqfd->pt, irqfd_ptable_queue_proc);

	mutex_lock(&gh_irqfd_groups_lock);
	group = gh_irqfd_find_group(f->ghvm, args->label);
	if (!group) {
		group = kzalloc(sizeof(*group), GFP_KERNEL);
		if (!group) {
			r = -ENOMEM;
			goto err_unlock;
		}

		INIT_LIST_HEAD(&group->irqfds);
		group->ghvm = f->ghvm;
		group->level = irqfd->level;
		group->ticket.resource_type = GH_RESOURCE_TYPE_BELL_TX;
		group->ticket.label = args->label;
		group->ticket.owner = THIS_MODULE;
		group->ticket.populate = gh_irqfd_populate;
		group->ticket.unpopulate = gh_irqfd_unpopulate;

		r = gh_vm_add_resource_ticket(f->ghvm, &group->ticket);
		if (r) {
			kfree(group);
			goto err_unlock;
		}
		list_add(&group->list, &gh_irqfd_groups);
	} else if (!group->mixed && irqfd->level != group->level) {
		/* crosvm can share one guest IRQ between edge and level sources.
		 * Decide the common bell mode before resource population.  Changing
		 * the acknowledgement mask after assignment would be unsafe.
		 */
		if (READ_ONCE(group->ghrsc)) {
			pr_warn("Gunyah irqfd label %u cannot mix edge and level sources after resource assignment\n",
				args->label);
			r = -EBUSY;
			goto err_unlock;
		}

		group->mixed = true;
		group->level = false;
		pr_warn("Gunyah irqfd label %u is shared by edge and level sources; using edge-compatible semantics\n",
			args->label);
	}

	irqfd->group = group;
	list_add(&irqfd->group_list, &group->irqfds);
	mutex_unlock(&gh_irqfd_groups_lock);

	events = vfs_poll(fd.file, &irqfd->pt);
	if (events & EPOLLIN)
		pr_warn("Premature injection of interrupt\n");
	fdput(fd);

	return 0;

err_unlock:
	mutex_unlock(&gh_irqfd_groups_lock);
	eventfd_ctx_put(irqfd->ctx);
err_fdput:
	fdput(fd);
	kfree(irqfd);
	return r;
}

static void gh_irqfd_unbind(struct gh_vm_function_instance *f)
{
	struct gh_irqfd *irqfd = f->data;
	struct gh_irqfd_group *group = irqfd->group;
	bool free_group = false;
	u64 cnt;

	eventfd_ctx_remove_wait_queue(irqfd->ctx, &irqfd->wait, &cnt);

	mutex_lock(&gh_irqfd_groups_lock);
	list_del(&irqfd->group_list);
	if (list_empty(&group->irqfds)) {
		list_del(&group->list);
		gh_vm_remove_resource_ticket(group->ghvm, &group->ticket);
		free_group = true;
	}
	mutex_unlock(&gh_irqfd_groups_lock);

	if (free_group)
		kfree(group);
	eventfd_ctx_put(irqfd->ctx);
	kfree(irqfd);
}

static bool gh_irqfd_compare(const struct gh_vm_function_instance *f,
				const void *arg, size_t size)
{
	const struct gh_fn_irqfd_arg *instance = f->argp,
					 *other = arg;

	if (sizeof(*other) != size)
		return false;

	return instance->label == other->label;
}

DECLARE_GH_VM_FUNCTION_INIT(irqfd, GH_FN_IRQFD, 2, gh_irqfd_bind, gh_irqfd_unbind,
				gh_irqfd_compare);
MODULE_DESCRIPTION("Gunyah irqfd VM Function");
MODULE_LICENSE("GPL");
