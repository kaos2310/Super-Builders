/* E3Q_RECLAIM_V1_APPLIED */
#include "e3q_mem_reclaim.h"
// SPDX-License-Identifier: GPL-2.0-only
/*
 * Copyright (c) 2022-2023 Qualcomm Innovation Center, Inc. All rights reserved.
 */

#include <linux/module.h>
#include <linux/rwsem.h>
#include <linux/gunyah_rsc_mgr.h>

#include "rsc_mgr.h"

static const struct gh_rm_platform_ops *rm_platform_ops;
static DECLARE_RWSEM(rm_platform_ops_lock);

int gh_rm_platform_pre_mem_share(struct gh_rm *rm, struct gh_rm_mem_parcel *mem_parcel)
{
	struct module *owner;
	int ret = -EOPNOTSUPP;

	down_read(&rm_platform_ops_lock);
	/* Stock/old modules have no contract cookie. Refuse BEFORE any SCM call;
	 * a CRC-compatible module is not necessarily behavior-compatible.
	 */
	if (!rm_platform_ops ||
	    rm_platform_ops->android_backport_reserved1 != E3Q_RECLAIM_COOKIE ||
	    !rm_platform_ops->pre_mem_share || !rm_platform_ops->post_mem_reclaim)
		goto out;
	if (E3Q_STATE(mem_parcel) != E3Q_HOST_OWNED || E3Q_MODULE(mem_parcel) ||
	    E3Q_ASSIGNED(mem_parcel) || E3Q_POISON(mem_parcel)) {
		ret = -EUCLEAN;
		goto out;
	}
	/* The ops lock serializes unregister. __module_address requires RCU or
	 * preemption protection; keep a module reference for the entire parcel.
	 */
	preempt_disable();
	owner = __module_address((unsigned long)rm_platform_ops);
	ret = owner && !try_module_get(owner) ? -ENODEV : 0;
	preempt_enable();
	if (ret)
		goto out;
	E3Q_MODULE(mem_parcel) = (unsigned long)owner;
	E3Q_STATE(mem_parcel) = E3Q_PLATFORM_OWNED;
	ret = rm_platform_ops->pre_mem_share(rm, mem_parcel);
	if (E3Q_POISON(mem_parcel)) {
		gh_vm_mem_block_new();
		E3Q_STATE(mem_parcel) = E3Q_QUARANTINED;
		if (!ret)
			ret = -EUCLEAN;
	} else if (ret && !E3Q_ASSIGNED(mem_parcel)) {
		E3Q_STATE(mem_parcel) = E3Q_HOST_OWNED;
		E3Q_MODULE(mem_parcel) = 0;
		module_put(owner);
	}
out:
	up_read(&rm_platform_ops_lock);
	return ret;
}
EXPORT_SYMBOL_GPL(gh_rm_platform_pre_mem_share);

int gh_rm_platform_post_mem_reclaim(struct gh_rm *rm, struct gh_rm_mem_parcel *mem_parcel)
{
	struct module *owner;
	int ret = -EUCLEAN;

	down_read(&rm_platform_ops_lock);
	if (E3Q_POISON(mem_parcel) || E3Q_STATE(mem_parcel) != E3Q_PLATFORM_OWNED)
		goto out;
	if (!rm_platform_ops ||
	    rm_platform_ops->android_backport_reserved1 != E3Q_RECLAIM_COOKIE ||
	    !rm_platform_ops->post_mem_reclaim)
		goto out;
	ret = rm_platform_ops->post_mem_reclaim(rm, mem_parcel);
	if (!ret && !E3Q_ASSIGNED(mem_parcel) && !E3Q_POISON(mem_parcel)) {
		owner = (struct module *)(unsigned long)E3Q_MODULE(mem_parcel);
		E3Q_MODULE(mem_parcel) = 0;
		E3Q_STATE(mem_parcel) = E3Q_HOST_OWNED;
		module_put(owner);
	} else if (!ret) {
		ret = -EUCLEAN;
	}
out:
	if (ret) {
		gh_vm_mem_block_new();
		E3Q_POISON(mem_parcel) = 1;
		E3Q_STATE(mem_parcel) = E3Q_QUARANTINED;
	}
	up_read(&rm_platform_ops_lock);
	return ret;
}
EXPORT_SYMBOL_GPL(gh_rm_platform_post_mem_reclaim);

int gh_rm_register_platform_ops(const struct gh_rm_platform_ops *platform_ops)
{
	int ret = 0;

	down_write(&rm_platform_ops_lock);
	if (!rm_platform_ops)
		rm_platform_ops = platform_ops;
	else
		ret = -EEXIST;
	up_write(&rm_platform_ops_lock);
	return ret;
}
EXPORT_SYMBOL_GPL(gh_rm_register_platform_ops);

void gh_rm_unregister_platform_ops(const struct gh_rm_platform_ops *platform_ops)
{
	down_write(&rm_platform_ops_lock);
	if (rm_platform_ops == platform_ops)
		rm_platform_ops = NULL;
	up_write(&rm_platform_ops_lock);
}
EXPORT_SYMBOL_GPL(gh_rm_unregister_platform_ops);

static void _devm_gh_rm_unregister_platform_ops(void *data)
{
	gh_rm_unregister_platform_ops((const struct gh_rm_platform_ops *)data);
}

int devm_gh_rm_register_platform_ops(struct device *dev, const struct gh_rm_platform_ops *ops)
{
	int ret;

	ret = gh_rm_register_platform_ops(ops);
	if (ret)
		return ret;

	return devm_add_action(dev, _devm_gh_rm_unregister_platform_ops, (void *)ops);
}
EXPORT_SYMBOL_GPL(devm_gh_rm_register_platform_ops);

MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("Gunyah Platform Hooks");
