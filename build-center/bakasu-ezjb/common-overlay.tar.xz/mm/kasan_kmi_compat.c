// SPDX-License-Identifier: GPL-2.0
#include <linux/export.h>
#include <linux/kconfig.h>
#include <linux/static_key.h>

#if !IS_ENABLED(CONFIG_KASAN_HW_TAGS)
DEFINE_STATIC_KEY_FALSE(kasan_flag_enabled);
EXPORT_SYMBOL(kasan_flag_enabled);
#endif
